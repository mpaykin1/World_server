# START HERE — V5 MAX

Desktop AI: read `DESKTOP_AI_INSTRUCTION.md` first and follow it completely.

Main command:
`node install-pwa-self-improve.cjs "C:\Users\user\Desktop\World_server"`

Do not stop at a partial result. Continue repair/test cycles until `QUALITY_CONVERGENCE_REPORT.json.status = CLEAN`, release gate passes, deployed Chromium/WebKit checks pass, and unresolved reproducible errors are zero.
