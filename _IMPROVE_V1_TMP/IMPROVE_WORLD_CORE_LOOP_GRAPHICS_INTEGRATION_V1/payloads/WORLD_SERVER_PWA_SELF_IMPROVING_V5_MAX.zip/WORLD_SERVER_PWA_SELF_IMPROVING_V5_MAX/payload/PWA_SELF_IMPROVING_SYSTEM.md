# WORLD SERVER PWA SELF-IMPROVING V5

V5 extends V4 without replacing World Quality Autopilot.

Core loop:
PWA runtime → durable privacy-minimal telemetry → device/storage capability → learned bounded quality profile → Golden/quality checks → sandboxed candidate fixes → deployed canary → rollback on regression.

V5 resilience additions:
- bounded IndexedDB offline telemetry queue + reconnect replay;
- storage quota-pressure monitor driving bounded Service Worker cache trimming;
- BroadcastChannel/localStorage update coordination preventing multi-tab reload loops;
- permanent PWA error recurrence rules merged into existing error registry;
- promoted reusable PWA systems merged into existing Golden component registry;
- optional free native CPU asset accelerators detected but never required.

Safety invariants:
- no API/auth caching;
- no source asset deletion;
- no graphics simplification just to pass a gate;
- no quality promotion above device safety ceiling;
- no completion while convergence is unresolved;
- emulator != physical iPhone evidence;
- newer unknown server changes are preserved, never overwritten blindly.
