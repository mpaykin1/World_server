'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');const path=require('path');const os=require('os');const cp=require('child_process');
const ROOT=path.resolve(__dirname,'..');
function source(rel){return fs.readFileSync(path.join(ROOT,rel),'utf8');}
test('v5 runtime modules exist and parse',()=>{
  for(const rel of ['shared/offline-telemetry-queue.js','shared/storage-budget-runtime.js','shared/pwa-update-coordinator.js']){
    assert.ok(fs.existsSync(path.join(ROOT,rel)),rel);const r=cp.spawnSync(process.execPath,['--check',path.join(ROOT,rel)],{encoding:'utf8'});assert.equal(r.status,0,r.stderr||r.stdout);
  }
});
test('service worker v5 has bounded pressure trim and cache message API',()=>{const s=source('sw.js');assert.match(s,/world-server-pwa-v5/);assert.match(s,/TRIM_CACHES/);assert.match(s,/CACHE_URLS/);assert.match(s,/fetchWithTimeout/);assert.match(s,/aggressive/);});
test('PWA injection includes resilience modules before PWA runtime',()=>{const s=source('scripts/inject-pwa-runtime.js');for(const rel of ['offline-telemetry-queue.js','storage-budget-runtime.js','pwa-update-coordinator.js'])assert.match(s,new RegExp(rel.replaceAll('.','\\.')));assert.ok(s.indexOf('offline-telemetry-queue.js')<s.indexOf("/shared/pwa-runtime.js"));});
test('regression memory and golden sync are idempotent',()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'pwa-v5-'));fs.mkdirSync(path.join(tmp,'data'),{recursive:true});
  fs.writeFileSync(path.join(tmp,'data/error-prevention-registry.json'),JSON.stringify({knownErrors:[]}));
  fs.writeFileSync(path.join(tmp,'data/golden-components.json'),JSON.stringify({components:{controls:{canonical:'keep-me'}}}));
  for(const script of ['pwa-regression-memory.js','golden-pwa-component-sync.js']){
    const file=path.join(ROOT,'scripts',script);let r=cp.spawnSync(process.execPath,[file],{cwd:tmp,encoding:'utf8'});assert.equal(r.status,0,r.stderr||r.stdout);const once=script.startsWith('pwa-')?fs.readFileSync(path.join(tmp,'data/error-prevention-registry.json'),'utf8'):fs.readFileSync(path.join(tmp,'data/golden-components.json'),'utf8');
    r=cp.spawnSync(process.execPath,[file],{cwd:tmp,encoding:'utf8'});assert.equal(r.status,0,r.stderr||r.stdout);const twice=script.startsWith('pwa-')?fs.readFileSync(path.join(tmp,'data/error-prevention-registry.json'),'utf8'):fs.readFileSync(path.join(tmp,'data/golden-components.json'),'utf8');assert.equal(once,twice);
    r=cp.spawnSync(process.execPath,[file,'--check'],{cwd:tmp,encoding:'utf8'});assert.equal(r.status,0,r.stderr||r.stdout);
  }
  const g=JSON.parse(fs.readFileSync(path.join(tmp,'data/golden-components.json'),'utf8'));assert.equal(g.components.controls.canonical,'keep-me');assert.ok(g.components['pwa-runtime']);
});
