#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path');const ROOT=process.cwd();const CHECK=process.argv.includes('--check');const file=path.join(ROOT,'data/golden-components.json');const g=JSON.parse(fs.readFileSync(file,'utf8'));g.components=g.components||{};
const entries={
'pwa-runtime':{canonical:'shared/pwa-runtime.js',status:'golden',scope:{allWebApps:true},rules:['installable shell','offline fallback','safe service-worker update','no API/auth caching']},
'adaptive-device-quality':{canonical:'shared/device-quality-runtime.js',status:'golden',scope:{compatibleRenderers:true},rules:['capability class','thermal/power proxy','server recommendation bounded by local safety']},
'offline-quality-telemetry':{canonical:'shared/offline-telemetry-queue.js',status:'golden',scope:{allWebApps:true},rules:['bounded durable queue','privacy-minimal payload','online replay','no user identity']},
'pwa-storage-budget':{canonical:'shared/storage-budget-runtime.js',status:'golden',scope:{allWebApps:true},rules:['quota pressure','bounded caches','critical trim']},
'pwa-update-coordination':{canonical:'shared/pwa-update-coordinator.js',status:'golden',scope:{allWebApps:true},rules:['single reload','multi-tab coordination','explicit update event']}
};
const missing=Object.keys(entries).filter(k=>!g.components[k]);if(CHECK){console.log(`[GOLDEN_PWA_SYNC] check missing=${missing.length}`);if(missing.length){for(const k of missing)console.error(`[GOLDEN_PWA_SYNC] MISSING ${k}`);process.exit(74);}process.exit(0);}for(const [k,v] of Object.entries(entries)){if(!g.components[k])g.components[k]=v;else g.components[k]={...g.components[k],...v};}fs.writeFileSync(file,JSON.stringify(g,null,2)+'\n');console.log(`[GOLDEN_PWA_SYNC] components=${Object.keys(entries).length} added=${missing.length}`);
