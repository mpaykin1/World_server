'use strict';
(function(){
  if(window.__WORLD_SERVER_STORAGE_BUDGET__)return;
  window.__WORLD_SERVER_STORAGE_BUDGET__=true;
  const state={usage:null,quota:null,ratio:null,persisted:null,pressure:'unknown'};
  async function sample(){
    try{
      if(navigator.storage?.estimate){const e=await navigator.storage.estimate();state.usage=Number(e.usage||0)||0;state.quota=Number(e.quota||0)||0;state.ratio=state.quota?state.usage/state.quota:null;}
      if(navigator.storage?.persisted)state.persisted=await navigator.storage.persisted();
    }catch{}
    const r=Number(state.ratio||0);state.pressure=r>=.9?'critical':r>=.78?'high':r>=.62?'medium':'low';
    dispatchEvent(new CustomEvent('worldserver:storage-pressure',{detail:{...state}}));
    if((state.pressure==='critical'||state.pressure==='high')&&navigator.serviceWorker?.controller){navigator.serviceWorker.controller.postMessage({type:'TRIM_CACHES',aggressive:state.pressure==='critical'});}
    return {...state};
  }
  async function requestPersistence(){try{return Boolean(await navigator.storage?.persist?.());}catch{return false;}}
  setTimeout(sample,2000);setInterval(sample,5*60*1000);
  window.WorldServerStorageBudget=Object.freeze({state,sample,requestPersistence});
})();
