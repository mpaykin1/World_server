'use strict';
(function(){
  if(window.__WORLD_SERVER_TELEMETRY_QUEUE__)return;
  window.__WORLD_SERVER_TELEMETRY_QUEUE__=true;
  const DB='world-server-pwa-v5',STORE='telemetry',MAX=256,ENDPOINT='/api/quality-telemetry';
  let dbPromise=null,flushing=false;
  function open(){
    if(!('indexedDB'in window))return Promise.resolve(null);
    if(dbPromise)return dbPromise;
    dbPromise=new Promise(resolve=>{
      try{
        const r=indexedDB.open(DB,1);
        r.onupgradeneeded=()=>{const db=r.result;if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE,{keyPath:'id',autoIncrement:true});};
        r.onsuccess=()=>resolve(r.result);r.onerror=()=>resolve(null);
      }catch{resolve(null);}
    });
    return dbPromise;
  }
  async function enqueue(payload){
    const db=await open();if(!db)return false;
    return new Promise(resolve=>{
      try{
        const tx=db.transaction(STORE,'readwrite'),s=tx.objectStore(STORE);s.add({createdAt:Date.now(),payload});
        const count=s.count();count.onsuccess=()=>{const excess=Math.max(0,Number(count.result||0)-MAX);if(excess){let n=0;const c=s.openCursor();c.onsuccess=e=>{const cur=e.target.result;if(cur&&n++<excess){cur.delete();cur.continue();}};}};
        tx.oncomplete=()=>resolve(true);tx.onerror=()=>resolve(false);
      }catch{resolve(false);}
    });
  }
  async function direct(payload){
    const body=JSON.stringify(payload);
    try{
      const r=await fetch(ENDPOINT,{method:'POST',headers:{'content-type':'application/json'},body,keepalive:true,cache:'no-store'});
      return r.ok;
    }catch{return false;}
  }
  async function send(payload){
    if(navigator.onLine!==false&&await direct(payload))return true;
    return enqueue(payload);
  }
  async function flush(){
    if(flushing||navigator.onLine===false)return;flushing=true;
    try{
      const db=await open();if(!db)return;
      const records=await new Promise(resolve=>{const tx=db.transaction(STORE,'readonly'),r=tx.objectStore(STORE).getAll();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>resolve([]);});
      for(const row of records.slice(0,64)){
        if(!(await direct(row.payload)))break;
        await new Promise(resolve=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).delete(row.id);tx.oncomplete=()=>resolve();tx.onerror=()=>resolve();});
      }
    }finally{flushing=false;}
  }
  addEventListener('online',()=>flush());
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')flush();});
  setTimeout(flush,1200);setInterval(flush,60000);
  window.WorldServerTelemetryQueue=Object.freeze({send,flush,enqueue});
})();
