'use strict';
(function(){
  if(window.__WORLD_SERVER_UPDATE_COORDINATOR__)return;
  window.__WORLD_SERVER_UPDATE_COORDINATOR__=true;
  const CHANNEL='world-server-pwa-update-v5';const KEY='worldserver.pwa.reloadAt';
  const bc='BroadcastChannel'in window?new BroadcastChannel(CHANNEL):null;
  let reloading=false;
  function recentReload(){try{return Date.now()-Number(localStorage.getItem(KEY)||0)<15000;}catch{return false;}}
  function mark(){try{localStorage.setItem(KEY,String(Date.now()));}catch{}}
  function reloadOnce(){if(reloading||recentReload())return;reloading=true;mark();bc?.postMessage({type:'RELOADING',at:Date.now()});location.reload();}
  bc?.addEventListener('message',e=>{if(e.data?.type==='RELOADING')mark();});
  if('serviceWorker'in navigator){
    navigator.serviceWorker.addEventListener('controllerchange',()=>reloadOnce());
    navigator.serviceWorker.ready.then(reg=>{
      reg.addEventListener?.('updatefound',()=>{
        const w=reg.installing;if(!w)return;w.addEventListener('statechange',()=>{if(w.state==='installed'&&navigator.serviceWorker.controller){dispatchEvent(new CustomEvent('worldserver:pwa-update-ready',{detail:{registration:reg}}));}});
      });
    }).catch(()=>{});
  }
  addEventListener('worldserver:pwa-apply-update',()=>{navigator.serviceWorker?.getRegistration?.().then(reg=>reg?.waiting?.postMessage({type:'SKIP_WAITING'})).catch(()=>{});});
  window.WorldServerPWAUpdateCoordinator=Object.freeze({reloadOnce});
})();
