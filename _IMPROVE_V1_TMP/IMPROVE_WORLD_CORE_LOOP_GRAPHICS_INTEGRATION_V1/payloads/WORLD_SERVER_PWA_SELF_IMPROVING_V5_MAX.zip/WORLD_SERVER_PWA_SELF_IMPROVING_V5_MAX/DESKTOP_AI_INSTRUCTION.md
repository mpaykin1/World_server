# DESKTOP AI — WORLD_SERVER PWA SELF-IMPROVING V5 MAX

## Mission
Install/upgrade V5 in the real `World_server`, preserve every newer server subsystem, finish all compatible runtime integrations, verify a real deployed preview, and keep repairing root causes until every reproducible error/regression is gone.

## ABSOLUTE RULE
**DO NOT REPORT DONE WHILE ANY REPRODUCIBLE ERROR, FAILED GATE, UNRESOLVED INTEGRATION, REGRESSION, VISUAL DEGRADATION, STALE SERVICE WORKER, OR BROKEN MOBILE PATH REMAINS.**

`BLOCKED_UNRESOLVED` and `MAX_ROUNDS_UNRESOLVED` mean: inspect → reproduce → find root cause → repair → add regression protection → rerun affected test → rerun `quality:converge:full` → repeat until `CLEAN`.

Never fake green by lowering baselines, deleting graphics/detail, disabling tests, `|| true`, `continue-on-error`, or claiming emulator evidence as a physical iPhone.

## Safe installation
1. `git checkout master && git pull origin master`.
2. Worktree must be clean. Never work directly on `master`.
3. Read `AGENTS.md`, `DESKTOP_AI_INSTALL_AND_VERIFY.md`, this instruction, `PWA_SELF_IMPROVING_SYSTEM.md`, `WORK_IN_PROGRESS.md`.
4. Update `WORK_IN_PROGRESS.md` BEFORE editing with current SHA, current systems, risks, plan, tests, errors that must never return, deployment plan and completion evidence.
5. Run:
   `node install-pwa-self-improve.cjs "C:\Users\user\Desktop\World_server"`
6. If installer reports unknown/newer managed content: STOP destructive copy, preserve it, semantically rebase V5 onto current code, then rerun. Never force overwrite.

## Mandatory V5 persistence / reuse
Run after installation:
- `npm run pwa:regression-memory`
- `npm run pwa:golden-sync`
- `npm run pwa:regression-memory:check`
- `npm run pwa:golden-sync:check`

Verify:
- existing `data/error-prevention-registry.json` entries remain intact;
- V5 PWA regressions are `status=protected` and not duplicated;
- existing Golden components remain intact;
- PWA runtime, adaptive quality, offline telemetry, storage budget and update coordination are Golden reusable components.

Any new confirmed PWA/runtime failure fixed during this task must be added to regression memory with root cause + protection/test before completion.

## Mandatory PWA/runtime integration
Run:
- `npm run pwa:integrate-runtime`
- `npm run pwa:discover-integration`
- `npm run pwa:check`
- `npm run pwa:resilience`

For every compatible certified renderer verify adaptive DPR/quality, shader/stutter profiler, predictive streaming and rig scan integration. Preserve all working shadows, lighting, textures, animations and geometry.

V5 must also verify:
- offline telemetry queues only privacy-minimal quality records and has a bounded maximum;
- queued records flush on reconnect/foreground;
- storage pressure triggers bounded cache cleanup, not source deletion;
- multiple tabs/PWA instances do not enter Service Worker reload loops;
- `/api/*` and auth data are never cached by Service Worker;
- `sw.js` itself is served no-cache.

## CPU-only asset pipeline — no GPU and no paid service required
Run:
1. `npm run assets:toolchain`
2. inspect `ASSET_TOOLCHAIN_BOOTSTRAP_REPORT.json`;
3. `npm run assets:transcode`;
4. if candidates exist, `npm run assets:transcode:apply`;
5. verify load + visual/perceptual regression before routing derivatives to runtime.

Pinned JS tools remain correctness path. Optional native free accelerators (`gltfpack`, `basisu`, `toktx`) may be used when present and verified, but V5 must work without them. Original PNG/JPG/GLB/GLTF masters MUST remain untouched; derived KTX2/Meshopt files are compiled artifacts only.

## Telemetry-driven adaptive quality
Apply Supabase telemetry migration through the normal migration path if not already applied. Verify `/api/quality-telemetry`, `/api/quality-summary`, `/api/quality-profile` locally and deployed.

Rules:
- no email/account/user identity in quality telemetry;
- weak or thermally stressed devices may downgrade automatically;
- server learning may not exceed local device safety ceiling;
- promotion to higher quality requires strong sustained evidence and no accepted regression;
- offline periods must not silently discard PWA quality evidence when IndexedDB is available.

## Semantic rigs / weapons / shields
Run `npm run animation:check` and discovery. Every relevant character rig needs a real state provider; structural discovery is not semantic proof.

Required invariants: feet follow movement; attack follows facing; pistol stays in hand; rifle/machine gun stays two-handed; shield remains vertical/in front and covers certified torso threshold when measurable. Add a regression test for each fixed semantic failure.

## Mandatory local verification — repeat until ALL PASS
- `npm ci`
- `npm run pwa:regression-memory:check`
- `npm run pwa:golden-sync:check`
- `npm run pwa:integrate-runtime`
- `npm run assets:quality`
- `npm run assets:transcode`
- `npm run pwa:check`
- `npm run pwa:resilience`
- `npm run animation:check`
- `npm run check`
- `npm run quality:converge:full`
- `npm run release:gate`

Also run affected Golden/world/control/collision/visual tests. If ANY command fails, do not stop. Repair root cause and rerun until clean.

## Mandatory deployed verification
1. Push task branch and create immutable Vercel preview.
2. Set `PLAYWRIGHT_BASE_URL` to the exact preview URL. Localhost is not preview evidence.
3. Run Chromium + `mobile-webkit`, including iOS PWA runtime spec.
4. Verify manifest, SW scope/update, offline shell, storage pressure behavior, no update reload loop, controls/collisions/rendering, no console errors.
5. Run post-deploy smoke against preview.
6. Open PR only after all gates pass. Never direct-push `master`.
7. Production promotion only after PR/review policy. Post-production smoke failure must rollback.

## Physical iPhone truth
WebKit emulation is required but not physical-device proof. On a real iPhone verify Safari → Share → Add to Home Screen → launch from icon; touch, resume, update, offline fallback, reconnect telemetry flush, storage pressure behavior, FPS/frame pacing/input latency, no WebGL context loss.

Report evidence as one of:
- `NO_REAL_IOS_EVIDENCE`;
- `REAL_IOS_BROWSER_EVIDENCE`;
- `REAL_IOS_PWA_EVIDENCE`.
Never inflate these.

## Final evidence required before DONE
Return branch + commit + PR; exact preview; production URL if promoted; `CLEAN`; PWA gate %; V5 resilience tests; renderer/predictive/rig coverage; regression-memory and Golden-sync PASS; asset toolchain/transcode status; Chromium PASS; WebKit PASS; truthful physical-iPhone status; release gate PASS; smoke PASS; unresolved=0; regressions=0.

If external permissions prevent push/PR/deploy, leave verified local branch intact, state the exact blocker, and **do not claim production applied**.
