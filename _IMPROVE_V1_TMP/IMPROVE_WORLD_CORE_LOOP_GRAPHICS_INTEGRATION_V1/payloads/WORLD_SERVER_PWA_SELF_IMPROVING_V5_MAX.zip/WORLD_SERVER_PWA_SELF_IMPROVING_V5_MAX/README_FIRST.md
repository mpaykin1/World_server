# WORLD_SERVER PWA SELF-IMPROVING V5 MAX

Main instruction: `DESKTOP_AI_INSTRUCTION.md`.

Install/upgrade on the real repository:
`node install-pwa-self-improve.cjs "C:\Users\user\Desktop\World_server"`

Prepared against current observed `master@fa3445713f8f9f84130c2795421b9cb1ca2d6640` and preserves `quality:world:*` / World Quality Autopilot.

V5 adds on top of V4:
- durable bounded offline telemetry queue (IndexedDB when available);
- storage/quota-pressure control and aggressive safe cache trimming;
- coordinated Service Worker updates across tabs/PWA instances to prevent reload loops;
- PWA failure knowledge synchronized into existing `data/error-prevention-registry.json`;
- reusable PWA components synchronized into existing `data/golden-components.json`;
- optional detection of free native CPU accelerators `gltfpack`, `basisu`, `toktx` without making them correctness dependencies;
- V5 regression/resilience tests and convergence integration.

Completion is forbidden until:
- `QUALITY_CONVERGENCE_REPORT.json.status = CLEAN`;
- `npm run release:gate` PASS;
- exact deployed preview passes Chromium + mobile WebKit;
- post-deploy smoke PASS;
- unresolved reproducible errors = 0;
- regressions = 0.

`BLOCKED_UNRESOLVED` / `MAX_ROUNDS_UNRESOLVED` means repair and rerun, never DONE.
