# DESKTOP AI MASTER INSTRUCTION
## INSTALL → COMPARE → DEDUPE → MERGE → VERIFY → FIX UNTIL PASS

Цель: восстановить единый cumulative patch для World_server + IMPROVE WORLD из всех включённых линий, не создавая дубликатов и не ломая текущую работу других AI.

### 0. Никогда не устанавливать все ZIP поверх репозитория вслепую
Каждый архив в `PATCHES/` — источник изменений. Сначала сравни его с текущим репозиторием и другими архивами.

### 1. Перед любыми изменениями
В `C:\Users\user\Desktop\World_server`:
```powershell
git fetch --all --prune
git status --short
git branch -vv
git worktree list
git log --oneline --decorate -30
```
Проверь открытые PR/ветки/worktree/patches других AI. Не трогай конфликтующие файлы, пока другая работа не завершена. Не push напрямую в master.

### 2. Порядок приоритетов
1. Существующий код сервера и более новый проверенный PR.
2. Более новый patch той же линии.
3. Golden Components / Regression Shield / Last Known Good / существующие quality gates.
4. Semantic merge лучших совместимых частей.
5. ADD-ONLY, где возможно.

### 3. Линии патчей
Проверить по очереди:
1. `WORLD_SERVER_CUMULATIVE_V32_MAX_READINESS_SELF_HEALING.zip`
2. `WORLD_SERVER_IMPROVE_WORLD_HOME_ADD_ONLY_V8_COORDINATED_AUTOPILOT.zip`
3. `world_server_unified_eye_world_patch_v3.zip`
4. `MULTIPLAYER_HOURLY_GUARD_V3.zip`
5. `WORLD_SERVER_NAVIGATOR_ENGAGEMENT_ML_V1.zip`
6. `WORLD_SERVER_PATCH_TEAM_V4_3_GRAPHICS_MAX_2026-08-28.zip`
7. `WORLD_SERVER_GRAPHICS_SUPERSTACK_V27.zip`
8. `DARK_VOXEL_CINEMATIC_100_PATCH_v3.zip`
9. `IMPROVE_WORLD_EXE_AUTOUPDATE_PATCH_v7.zip`
10. `World_server_production_quality_evidence_patch_v1.zip`

Это НЕ означает «перезаписать в таком порядке». Это порядок анализа/интеграции.

### 4. Hard invariants
- Один непрерывный `world=main`, а не отдельные миры по chunks/regions.
- Realtime multiplayer + authoritative persistence/resync.
- Navigator переиспользуется, не создаётся второй backend/UI.
- Supabase Realtime / PostHog / Sentry / Playwright переиспользуются.
- Не ухудшать принятую графику ради FPS.
- CPU-first; server GPU необязателен.
- Не отключать quality/release gates ради PASS.
- Не считать blocked/skipped live test PASS.
- Не создавать новый quality/control plane, если эквивалент уже есть.
- Все root causes и fixes сохранять в существующую knowledge/incident систему.

### 5. Для каждого патча
1. Распаковать во временную папку вне репозитория.
2. Составить список файлов.
3. Сравнить с текущим World_server (`git diff --no-index` или эквивалент).
4. Определить:
   - уже внедрено;
   - новее на сервере;
   - полезно и совместимо;
   - конфликтует;
   - устарело/дубликат.
5. Перенести только полезные совместимые изменения.
6. Если обнаружен баг:
   `symptom/trace → root cause → minimal safe fix → regression test → rerun failed test → full check/live`.

### 6. Обязательные проверки после объединения
Используй существующие scripts текущего package.json. Если команда отсутствует — сначала найди актуальный эквивалент, а не создавай дубликат.

Минимум:
```powershell
npm run check
npm run release:gate
```
Если доступны:
```powershell
npm run quality:world
npm run quality:production
npm run multiplayer:verify
npm run multiplayer:live
```

Также:
- desktop + mobile Playwright;
- canonical public URL;
- Create/Join;
- Navigator → World Diff;
- world persistence/compaction;
- controls/collisions/jump/stairs;
- broken assets/links;
- console/WebGL errors;
- graphics/light/animation/physics/textures/sound;
- FPS/adaptive quality;
- two independent clients for multiplayer;
- disconnect/reconnect/resync;
- latency/jitter;
- load ladder 4→10→25→50 только после PASS предыдущего уровня.

### 7. EXE / Native
EXE/autoupdate должен быть вторым клиентом той же игры и той же shared brain/world state, а не отдельной логикой. Web и Native должны использовать одинаковые seeds/specs/replays/evidence там, где это возможно.

### 8. Graphics
Использовать существующие:
LOD, culling, streaming, batching, cache, adaptive quality, procedural/frame-timeline animation.
Не удалять hero detail/lighting/shadows/textures ради performance. Оптимизировать невидимое/дальнее/повторяющееся.

### 9. Что скачать
Сначала inventory. Не скачивать то, что уже есть.
Добавлять только бесплатные open-source инструменты с понятной лицензией и измеримым выигрышем.
Не делать GPU-only зависимость обязательной.

### 10. Финальный cumulative результат
После успешного semantic merge:
- создать ОДНУ новую AI-owned ветку;
- прогнать все применимые gates до PASS;
- создать один новый cumulative patch;
- включить полный код, tests, configs/migrations, regression guards;
- обновить эту Desktop AI instruction;
- записать exact PASS/FAIL/BLOCKED evidence;
- не auto-merge в master.

### 11. Проверка целостности источников
`PATCH_INDEX.json` содержит SHA-256 и результат ZIP integrity check каждого включённого архива.
Если `zip_valid=false`, не использовать этот источник.
