# WORLD_SERVER + IMPROVE WORLD — ALL TASKS MASTER BUNDLE

Это восстановленный единый пакет из последних найденных версий патчей, связанных с запланированными задачами World_server / IMPROVE WORLD.

## Включено
- IMPROVE WORLD EXE / autoupdate — v7
- Unified Eye World — v3
- IMPROVE WORLD Home coordinated add-only autopilot — V8
- Multiplayer Hourly Guard — V3
- World Server cumulative self-healing/readiness — V32
- Production quality evidence guard — v1
- Graphics Patch Team — V4.3
- Graphics Superstack — V27
- Navigator Engagement ML — V1
- Dark Voxel Cinematic — v3

Старые версии той же линии намеренно НЕ добавлены, чтобы не плодить дубли.

## Важно
Архивы сохранены внутри `PATCHES/` как независимые исходные патчи. Это безопаснее, чем слепо смешивать одноимённые файлы разных веток: Desktop AI должен сравнить их с текущим World_server, выбрать последние совместимые изменения и сделать semantic merge без перезаписи параллельной работы.

Сначала читать `DESKTOP_AI_MASTER_INSTRUCTION.md`.
