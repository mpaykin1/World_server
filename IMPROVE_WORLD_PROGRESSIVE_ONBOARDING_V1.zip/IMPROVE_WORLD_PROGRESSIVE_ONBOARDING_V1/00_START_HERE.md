# 00_START_HERE — IMPROVE WORLD Progressive Onboarding V1

## Цель
Убрать ощущение длинной анкеты и дать пользователю первую визуальную награду максимум после **3 коротких ответов**.

Новый обязательный цикл:
**3 ответа → живой первый слепок → войти / уточнить / соединить → глубокие вопросы постепенно внутри опыта.**

Старые вопросы **НЕ удаляются**. Они становятся вторым слоем (`deep profiling`) и должны появляться только после первой визуальной награды.

## Что находится в этой папке
- `install-progressive-onboarding.cjs` — безопасная установка с backup и автообнаружением главной.
- `payload/shared/progressive-onboarding.runtime.js` — runtime новой механики.
- `payload/shared/progressive-onboarding.css` — UI.
- `payload/data/onboarding-policy.json` — постоянный стандарт сервера.
- `payload/scripts/verify-progressive-onboarding.cjs` — статическая проверка интеграции.
- `payload/e2e/progressive-onboarding.spec.js` — Playwright regression test.
- `demo/` — автономная демо-страница для проверки механики.
- `ROLLBACK.md` — откат.
- `PATCH_STATUS.md` — честный статус готовности.

---

# ИНСТРУКЦИЯ DESKTOP AI — выполнять полностью

Рабочий репозиторий обычно:
`C:\Users\user\Desktop\World_server`

Но **не предполагай**, что текущая главная лежит именно в `World_server/master`.
Сначала найди реальный source проекта, который обслуживает текущую главную IMPROVE WORLD.

## 1. Сначала защити существующее
1. `git status`
2. Не уничтожай незакоммиченные изменения и чужие worktree.
3. Создай отдельную ветку/worktree для патча.
4. Проверь `AGENTS.md`, существующие golden/quality/regression правила.
5. Найди реальный frontend главной по текстам:
   - `IMPROVE WORLD`
   - `Создать`
   - `Присоединиться`
   - `Зачем это`
   - существующие вопросы анкеты
6. Если главная находится в другом repo/project — устанавливай патч туда, а policy/regression при необходимости синхронизируй с `World_server`.

## 2. Установка
Из корня РЕАЛЬНОГО repo главной:

```bash
node "<PATH_TO_PATCH>\install-progressive-onboarding.cjs"
```

Если автообнаружение вернуло несколько кандидатов, **самостоятельно** выбери истинную главную по коду/production deployment и запусти:

```bash
node "<PATH_TO_PATCH>\install-progressive-onboarding.cjs" --target path/to/index.html
```

Не спрашивай пользователя, если можешь определить target из repo/Vercel/deployment.

## 3. Что должно быть внедрено
Обязательно:
- не более 3 стартовых вопросов;
- первый визуальный seed/snapshot сразу после них;
- `Пропустить` на каждом вопросе;
- голосовой ввод при наличии API браузера, graceful fallback без него;
- текст НЕ обязателен, если пользователь выбирает/пропускает;
- индикатор **«Мир проявился на N%»**, а не «вопрос 3 из 19»;
- каждый ответ немедленно меняет визуальный seed;
- старый длинный опрос остаётся доступен через **«Уточнить мир»** и постепенно;
- кнопка **«Войти сейчас»** не должна требовать пройти глубокий опрос;
- **«Соединить с другим миром»** остаётся доступным после первого seed;
- никакой обязательной регистрации ДО первого visual reward;
- mobile portrait/landscape и desktop;
- `prefers-reduced-motion`;
- runtime не должен ломать существующие клики и маршруты.

## 4. Интеграция с настоящим генератором мира
Runtime отправляет события:

```js
window.addEventListener("improveworld:onboarding-answer", (event) => {
  // event.detail = { flow, questionId, value, skipped, answers, completion }
});

window.addEventListener("improveworld:first-snapshot-ready", (event) => {
  // Передай event.detail.answers в существующую систему мира.
});
```

Если у существующей системы есть API/оркестратор генерации, подключи его к этим событиям.
НЕ создавай второй параллельный генератор, если уже есть рабочий.

Для AI inference можно определить:

```js
window.IMPROVE_WORLD_INFER = async ({ flow, answers, currentQuestion }) => {
  // вернуть { suggestions: ["..."], inferred: {...} }
};
```

Используй существующий AI backend/оркестратор. Не добавляй новую Vercel Function только ради этого, если можно переиспользовать существующую — сервер уже чувствителен к количеству functions.

## 5. Проверки — не останавливаться на первой ошибке
Запусти:

```bash
npm run onboarding:verify
npm test
npm run onboarding:e2e
```

Затем существующие release/golden/integration gates repo (названия брать из `package.json`, не выдумывать).

Обязательные E2E сценарии:
1. Desktop Chromium: Создать → 3 ответа/skip → snapshot.
2. Mobile 390x844: все кнопки нажимаются пальцем.
3. Join flow.
4. Голосовая кнопка скрывается/отключается корректно при отсутствии SpeechRecognition.
5. `Уточнить мир` возвращает существующий deep flow.
6. `Войти сейчас` доступно без длинной анкеты.
7. Нет обязательного auth до snapshot.
8. Back/refresh не уничтожает первые ответы (sessionStorage).
9. Existing homepage navigation не сломана.
10. Console: 0 uncaught errors.

## 6. Проверка production
После preview deployment:
- открыть реальный preview как анонимный пользователь;
- проверить iPhone/Safari-equivalent viewport и desktop;
- проверить с чистым storage/incognito;
- проверить две разные сессии;
- убедиться, что функциональность одинаковая;
- только после PASS разрешить production.

## 7. Regression lock
Если тест обнаружил новый повторяемый класс ошибки:
- исправить первопричину;
- добавить regression test;
- добавить запись в существующий error-prevention/autofix registry;
- распространять успешное решение на другие onboarding/world interfaces, где применимо.

## Definition of Done
Патч считается установленным только когда:
- первая визуальная награда ≤ 3 стартовых вопросов;
- старые вопросы сохранены, но не блокируют reward;
- mobile + desktop PASS;
- существующие release gates не ухудшены;
- production smoke PASS;
- нет ложного заявления «100%», если реальный prod не проверен.
