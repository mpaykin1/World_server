# ROLLBACK

Installer сохраняет изменённые файлы в:

`.patch-backups/IMPROVE_WORLD_PROGRESSIVE_ONBOARDING_V1-<timestamp>/`

Для отката Desktop AI должен:
1. определить последний backup;
2. восстановить из него `index.html`, `package.json`, `AGENTS.md` и заменённые payload-файлы;
3. если payload-файлов до патча не существовало — удалить только файлы этого патча:
   - `shared/progressive-onboarding.runtime.js`
   - `shared/progressive-onboarding.css`
   - `data/onboarding-policy.json`
   - `scripts/verify-progressive-onboarding.cjs`
   - `e2e/progressive-onboarding.spec.js`
4. прогнать прежние release/golden tests.
5. Не откатывать чужие изменения через `git reset --hard`.
