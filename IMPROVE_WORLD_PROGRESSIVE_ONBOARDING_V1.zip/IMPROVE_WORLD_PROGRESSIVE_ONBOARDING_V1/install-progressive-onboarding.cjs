#!/usr/bin/env node
"use strict";
const fs=require("fs");
const path=require("path");

const patchRoot=__dirname;
const repo=process.cwd();
const args=process.argv.slice(2);
const targetArg=args.includes("--target") ? args[args.indexOf("--target")+1] : null;
const DRY=args.includes("--dry-run");
const marker="IMPROVE_WORLD_PROGRESSIVE_ONBOARDING_V1";
const backupDir=path.join(repo,".patch-backups",marker+"-"+new Date().toISOString().replace(/[:.]/g,"-"));

function copyFile(srcRel,dstRel){
  const src=path.join(patchRoot,"payload",srcRel), dst=path.join(repo,dstRel);
  fs.mkdirSync(path.dirname(dst),{recursive:true});
  if(fs.existsSync(dst)){
    const b=path.join(backupDir,dstRel); fs.mkdirSync(path.dirname(b),{recursive:true});
    fs.copyFileSync(dst,b);
  }
  if(!DRY) fs.copyFileSync(src,dst);
  console.log("COPY",dstRel);
}
function walk(dir,depth=0,out=[]){
  if(depth>6 || !fs.existsSync(dir)) return out;
  for(const e of fs.readdirSync(dir,{withFileTypes:true})){
    if(["node_modules",".git",".next","dist","build",".vercel",".patch-backups"].includes(e.name)) continue;
    const p=path.join(dir,e.name);
    if(e.isDirectory()) walk(p,depth+1,out);
    else if(e.name.toLowerCase()==="index.html") out.push(p);
  }
  return out;
}
function score(file){
  let s=0, text="";
  try{text=fs.readFileSync(file,"utf8")}catch(_){return -1}
  const markers=[
    [/IMPROVE\s*WORLD/i,8],
    [/Присоедин/i,5],
    [/Созда(ть|й)/i,5],
    [/Зачем это/i,3],
    [/персонаж/i,2],
    [/истори/i,2],
    [/мир/i,1]
  ];
  for(const [re,n] of markers) if(re.test(text)) s+=n;
  return s;
}
function relativeAssetPath(htmlFile,dest){
  const rel=path.relative(path.dirname(htmlFile),path.join(repo,dest)).replace(/\\/g,"/");
  return rel.startsWith(".")?rel:"./"+rel;
}
function inject(htmlFile){
  let html=fs.readFileSync(htmlFile,"utf8");
  if(html.includes("progressive-onboarding.runtime.js")) {console.log("ALREADY integrated",path.relative(repo,htmlFile)); return;}
  const rel=path.relative(repo,htmlFile);
  const b=path.join(backupDir,rel); fs.mkdirSync(path.dirname(b),{recursive:true}); fs.copyFileSync(htmlFile,b);
  const css=relativeAssetPath(htmlFile,"shared/progressive-onboarding.css");
  const js=relativeAssetPath(htmlFile,"shared/progressive-onboarding.runtime.js");
  const block=`\n<!-- ${marker} -->\n<link rel="stylesheet" href="${css}">\n<script defer src="${js}"></script>\n`;
  if(/<\/head>/i.test(html)) html=html.replace(/<\/head>/i,block+"</head>");
  else html=block+html;
  if(!DRY) fs.writeFileSync(htmlFile,html,"utf8");
  console.log("INJECT",rel);
}
function updatePackage(){
  const f=path.join(repo,"package.json"); if(!fs.existsSync(f)) return;
  const original=fs.readFileSync(f,"utf8"); const pkg=JSON.parse(original);
  pkg.scripts=pkg.scripts||{};
  pkg.scripts["onboarding:verify"]="node scripts/verify-progressive-onboarding.cjs";
  if(pkg.devDependencies?.["@playwright/test"] || pkg.dependencies?.["@playwright/test"])
    pkg.scripts["onboarding:e2e"]="playwright test e2e/progressive-onboarding.spec.js";
  const b=path.join(backupDir,"package.json"); fs.mkdirSync(path.dirname(b),{recursive:true}); fs.writeFileSync(b,original);
  if(!DRY) fs.writeFileSync(f,JSON.stringify(pkg,null,2)+"\n");
  console.log("PATCH package.json scripts");
}
function updateAgents(){
  const f=path.join(repo,"AGENTS.md"); if(!fs.existsSync(f)) return;
  let s=fs.readFileSync(f,"utf8");
  if(s.includes(marker)) return;
  const add=`\n\n## ${marker}\n- User-facing world creation MUST show a first visual reward after no more than 3 initial questions.\n- Existing deep questions are preserved but may not block first reward or entry.\n- Every onboarding question must be skippable; auth may not block the first visual seed.\n- Prefer progressive profiling inside the living world over a long pre-world questionnaire.\n- Regression tests must protect mobile touch, anonymous first reward, and the <=3-question contract.\n`;
  const b=path.join(backupDir,"AGENTS.md"); fs.mkdirSync(path.dirname(b),{recursive:true}); fs.writeFileSync(b,s);
  if(!DRY) fs.writeFileSync(f,s+add,"utf8");
  console.log("PATCH AGENTS.md policy");
}

console.log(marker, DRY?"DRY RUN":"INSTALL");
for(const pair of [
  ["shared/progressive-onboarding.runtime.js","shared/progressive-onboarding.runtime.js"],
  ["shared/progressive-onboarding.css","shared/progressive-onboarding.css"],
  ["data/onboarding-policy.json","data/onboarding-policy.json"],
  ["scripts/verify-progressive-onboarding.cjs","scripts/verify-progressive-onboarding.cjs"],
  ["e2e/progressive-onboarding.spec.js","e2e/progressive-onboarding.spec.js"]
]) copyFile(pair[0],pair[1]);

let target=null;
if(targetArg){
  target=path.resolve(repo,targetArg);
  if(!fs.existsSync(target)) throw new Error("Target not found: "+target);
}else{
  const ranked=walk(repo).map(f=>({f,s:score(f)})).sort((a,b)=>b.s-a.s);
  console.log("TOP HOMEPAGE CANDIDATES");
  ranked.slice(0,8).forEach(x=>console.log(String(x.s).padStart(2),path.relative(repo,x.f)));
  const best=ranked[0], second=ranked[1];
  if(best && best.s>=8 && (!second || best.s>=second.s+3)) target=best.f;
}
if(!target){
  const report=walk(repo).map(f=>({path:path.relative(repo,f),score:score(f)})).sort((a,b)=>b.score-a.score);
  fs.writeFileSync(path.join(repo,"ONBOARDING_TARGET_DISCOVERY.json"),JSON.stringify(report,null,2));
  console.error("AMBIGUOUS_OR_MISSING_HOMEPAGE: wrote ONBOARDING_TARGET_DISCOVERY.json");
  console.error("Desktop AI: identify the real production homepage and rerun with --target path/to/index.html");
  process.exitCode=2;
}else{
  inject(target);
  updatePackage();
  updateAgents();
  console.log("BACKUP",backupDir);
  console.log("NEXT: npm run onboarding:verify && npm test && npm run onboarding:e2e (if available)");
}
