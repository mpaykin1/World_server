# World_server cumulative V28 — Critical Coverage Ledger

Single-folder cumulative self-healing patch.
Includes Desktop AI instructions, root-cause fixes, Consumer Drift protection,
critical CI coverage ledger, Supabase safeguards, and regression rules.

This archive itself does not modify Production, Supabase, Vercel aliases, or active AI branches.
