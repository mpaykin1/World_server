#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path');
const repo=path.resolve(process.argv[2]||process.cwd());
const must=(v,m)=>{if(!v)throw new Error(m)};
const backup=p=>{if(fs.existsSync(p)&&!fs.existsSync(p+'.v28-backup'))fs.copyFileSync(p,p+'.v28-backup')};

function fixPolicy(){
 const p=path.join(repo,'scripts','check-ai3d-delivery-policy.js');
 must(fs.existsSync(p),'policy checker missing');
 let s=fs.readFileSync(p,'utf8');
 if(s.includes("readFirst(['lib/api-handlers/ai3d.js','api/ai3d.js'])")) return;
 const a="function read(rel) { return fs.readFileSync(path.join(root, rel), 'utf8'); }";
 const b="const api = read('api/ai3d.js');";
 must(s.includes(a)&&s.includes(b),'policy source shape changed; refusing blind edit');
 s=s.replace(a,a+"\nfunction readFirst(xs){for(const x of xs){const p=path.join(root,x);if(fs.existsSync(p))return fs.readFileSync(p,'utf8')}throw new Error('AI3D handler missing: '+xs.join(', '))}");
 s=s.replace(b,"const api = readFirst(['lib/api-handlers/ai3d.js','api/ai3d.js']);");
 backup(p);fs.writeFileSync(p,s);
}
function fixDiscovery(){
 const p=path.join(repo,'lib','ai3d-discovery.js');
 must(fs.existsSync(p),'discovery missing');
 let s=fs.readFileSync(p,'utf8');
 if(!s.includes('execSync(`where ${blender}`')) return;
 const a=`function existsFile(p) {\n  try { return fs.statSync(p).isFile(); } catch { return false; }\n}\n`;
 must(s.includes(a),'discovery source shape changed');
 s=s.replace(a,a+`\nfunction findExecutableOnPath(command){if(!command||command.includes('/')||command.includes('\\\\'))return null;const dirs=String(process.env.PATH||'').split(path.delimiter).filter(Boolean),exts=process.platform==='win32'?String(process.env.PATHEXT||'.EXE;.CMD;.BAT;.COM').split(';'):[''];for(const d of dirs)for(const e of exts){const p=path.join(d,command+e);if(existsFile(p))return p}return null}\n`);
 const re=/[ \t]*const which = \(\(\) => \{ try \{ return execSync\(`where \$\{blender\}`, \{ encoding: 'utf8', timeout: 2000 \}\)\.trim\(\); \} catch \{ return ''; \} \}\)\(\);\r?\n[ \t]*if \(which\) \{ blender = which\.split\('\\n'\)\[0\]\.trim\(\); blenderFound = true; blenderSource = 'PATH'; \}/g;
 must((s.match(re)||[]).length===1,'Windows where block changed');
 s=s.replace(re,`      const foundOnPath=findExecutableOnPath(blender);\n      if(foundOnPath){blender=foundOnPath;blenderFound=true;blenderSource='PATH';}`);
 backup(p);fs.writeFileSync(p,s);
}
function fixStability(){
 const p=path.join(repo,'scripts','test-stability-runner.js');
 const q=path.join(repo,'scripts','quality-stability-runner.js');
 must(fs.existsSync(p),'stability runner missing');
 const s=fs.readFileSync(p,'utf8');
 if(s.includes('NODE_TEST_CONTEXT')&&fs.existsSync(q)) return;
 must(s.includes("const tests=['test/quality-regression.test.js'"),'stability source shape changed');
 backup(p);fs.writeFileSync(q,s);
 fs.writeFileSync(p,"#!/usr/bin/env node\n'use strict';\nif(process.env.NODE_TEST_CONTEXT){console.log('[STABILITY_SHIM] broad discovery skipped');process.exit(0)}\nrequire('./quality-stability-runner.js');\n");
}
try{fixPolicy();fixDiscovery();fixStability();console.log('V28_FIX_PASS')}catch(e){console.error(e.stack||e);process.exit(1)}
