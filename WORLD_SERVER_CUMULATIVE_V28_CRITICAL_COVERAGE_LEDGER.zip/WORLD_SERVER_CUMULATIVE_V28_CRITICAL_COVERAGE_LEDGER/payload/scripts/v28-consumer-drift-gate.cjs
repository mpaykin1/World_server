#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path');
const root=path.resolve(process.argv[2]||process.cwd());
const findings=[],ignore=new Set(['node_modules','.git','.vercel','coverage','runtime']);
function existsAny(base){return [base,base+'.js',base+'.cjs',base+'.mjs',base+'.json',path.join(base,'index.js')].some(fs.existsSync)}
function relExists(file,spec){return !spec.startsWith('.')||existsAny(path.resolve(path.dirname(file),spec))}
function rootExists(spec){return existsAny(path.join(root,spec))}
function inspect(file){
 const src=fs.readFileSync(file,'utf8'),rel=path.relative(root,file).replace(/\\/g,'/');
 for(const m of src.matchAll(/require\(\s*['"]([^'"]+)['"]\s*\)/g)) if(!relExists(file,m[1])) findings.push({file:rel,kind:'require',target:m[1]});
 for(const m of src.matchAll(/\bread\(\s*['"]([^'"]+)['"]\s*\)/g)) if(!rootExists(m[1])) findings.push({file:rel,kind:'root-read',target:m[1]});
}
function walk(dir){if(!fs.existsSync(dir))return;for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory()&&!ignore.has(e.name))walk(p);else if(e.isFile()&&/\.(js|cjs|mjs)$/.test(e.name))inspect(p)}}
for(const d of ['scripts','api','lib','test','e2e'])walk(path.join(root,d));
if(findings.length){console.error('V28_CONSUMER_DRIFT_FAIL');for(const f of findings)console.error(`${f.file} ${f.kind} -> ${f.target}`);process.exit(1)}
console.log('V28_CONSUMER_DRIFT_PASS');
