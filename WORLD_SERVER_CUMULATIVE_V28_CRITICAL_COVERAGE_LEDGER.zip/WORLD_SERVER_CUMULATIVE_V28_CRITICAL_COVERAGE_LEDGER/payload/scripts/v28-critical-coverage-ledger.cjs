#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path');
const input=process.argv[2];
if(!input){console.error('usage: node v28-critical-coverage-ledger.cjs <github-jobs.json> [out.json]');process.exit(2)}
const raw=JSON.parse(fs.readFileSync(path.resolve(input),'utf8'));
const jobs=raw.jobs||[];
const required=[
'AI3D discovery smoke',
'AI3D evidence gate (hard)',
'AI3D final delivery policy (hard)',
'AI3D V4 combined integration (hard)',
'WORLD SERVER Golden Standard source/release gate (hard)',
'Sentry runtime smoke (Playwright) - window.WorldServerSentry + ingest (hard)',
'AI3D Voxel City autoplay (Playwright) ai3d-voxel-city-autoplay (hard)'
];
const check=jobs.find(j=>j.name==='check');
if(!check){console.error('V28_COVERAGE_LEDGER_FAIL check job missing');process.exit(2)}
const map=new Map((check.steps||[]).map(s=>[s.name,s]));
const steps=required.map(name=>({name,conclusion:map.get(name)?.conclusion||'missing',verified:map.get(name)?.conclusion==='success'}));
const bad=steps.filter(x=>!x.verified);
const ledger={overall:bad.length?'INCOMPLETE':'COMPLETE',verifiedCount:steps.length-bad.length,requiredCount:steps.length,steps};
const out=path.resolve(process.argv[3]||'CI_CRITICAL_COVERAGE_LEDGER.json');
fs.writeFileSync(out,JSON.stringify(ledger,null,2)+'\n');
console.log(`V28_COVERAGE_LEDGER_${ledger.overall}`);
if(check.conclusion==='success'&&bad.length)process.exit(1);
