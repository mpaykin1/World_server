#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path'),root=path.resolve(process.argv[2]||process.cwd());
const read=p=>fs.existsSync(path.join(root,p))?fs.readFileSync(path.join(root,p),'utf8'):'';
const must=(v,m)=>{if(!v){console.error('V28_GATE_FAIL',m);process.exit(1)}};
must(!read('scripts/check-ai3d-delivery-policy.js').includes("const api = read('api/ai3d.js');"),'stale AI3D path');
must(read('scripts/check-ai3d-delivery-policy.js').includes('lib/api-handlers/ai3d.js'),'current AI3D handler missing');
must(!read('lib/ai3d-discovery.js').includes('execSync(`where ${blender}`'),'Windows where remains');
must(read('scripts/test-stability-runner.js').includes('NODE_TEST_CONTEXT'),'recursive test guard missing');
console.log('V28_REGRESSION_GATE_PASS');
