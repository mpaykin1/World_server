-- Apply only in a real migration after active integration is green.
select indexname,indexdef from pg_indexes where schemaname='public' and tablename='image_world_jobs' order by indexname;
create index if not exists image_world_jobs_world_id_idx on public.image_world_jobs(world_id);
