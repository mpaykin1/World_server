'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),cp=require('child_process');
const ledger=path.resolve(__dirname,'..','scripts','v28-critical-coverage-ledger.cjs');
test('coverage ledger marks skipped critical gate incomplete',()=>{
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'v28-')),i=path.join(d,'jobs.json'),o=path.join(d,'out.json');
 fs.writeFileSync(i,JSON.stringify({jobs:[{name:'check',conclusion:'failure',steps:[{name:'AI3D discovery smoke',conclusion:'success'}]}]}));
 const r=cp.spawnSync(process.execPath,[ledger,i,o],{encoding:'utf8'});
 assert.equal(r.status,0);
 assert.equal(JSON.parse(fs.readFileSync(o,'utf8')).overall,'INCOMPLETE');
});
