# Desktop AI — V28 INSTALL → VERIFY → FIX UNTIL PASS

Safety:
- Never work in master.
- Inspect active PRs/worktrees/locks first and do not overwrite unfinished AI work.
- Use a clean candidate branch.
- Never promote Production from red/unverified CI.

V28 protects against:
1. stale `api/ai3d.js` consumer after API consolidation;
2. Windows-only `where` used on Linux;
3. recursive `node --test` discovery;
4. stale/moved file consumers;
5. false-green CI where critical hard gates are skipped.

Install / verify:
```powershell
node payload\scripts\v28-fix-independent-root-causes.cjs C:\Users\user\Desktop\World_server
node payload\scripts\v28-consumer-drift-gate.cjs C:\Users\user\Desktop\World_server
node payload\scripts\v28-regression-gate.cjs C:\Users\user\Desktop\World_server
node --test payload\test\v28-regression.test.js

cd C:\Users\user\Desktop\World_server
node scripts\check-ai3d-delivery-policy.js
npm run check
npm run quality:stability
npm run release:gate
```

Critical CI rule:
Skipped critical tests are UNVERIFIED, never PASS.
Do not switch Production until the critical coverage ledger is COMPLETE.

For every failure:
root cause → smallest compatible fix → regression test → rerun failed gate → rerun release gate.
