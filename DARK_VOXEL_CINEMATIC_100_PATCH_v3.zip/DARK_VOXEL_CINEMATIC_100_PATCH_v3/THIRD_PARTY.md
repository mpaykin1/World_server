# Third-party OSS used / expected

- Three.js 0.185.1 — renderer / postprocessing / InstancedMesh.
- Rapier `@dimforge/rapier3d-compat` 0.20.0 — physics candidate with deterministic pendulum fallback.
- Meshoptimizer 1.2.0 — geometry optimization pipeline.
- Basis Universal / KTX2 — optional external executable for texture transcoding/build pipeline.
- Playwright — existing repo devDependency used for desktop/mobile/WebKit verification.

Installer vendors browser-facing Three modules locally so production gameplay does not depend on an external CDN.
