@echo off
setlocal
if "%~1"=="" (
  echo Usage: INSTALL_WINDOWS.cmd C:\path\to\World_server_worktree
  exit /b 2
)
node "%~dp0install.mjs" "%~1"
if errorlevel 1 exit /b %errorlevel%
pushd "%~1"
npm run navigator:gate -- --fast
if errorlevel 1 exit /b %errorlevel%
npm run cinematic:gate -- --fast
popd
endlocal
