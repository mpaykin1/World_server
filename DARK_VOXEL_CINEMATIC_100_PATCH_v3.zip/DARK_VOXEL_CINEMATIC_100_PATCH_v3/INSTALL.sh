#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-}"
if [[ -z "$TARGET" ]]; then echo "Usage: ./INSTALL.sh /path/to/World_server_worktree"; exit 2; fi
node "$(dirname "$0")/install.mjs" "$TARGET"
cd "$TARGET"
npm run navigator:gate -- --fast
npm run cinematic:gate -- --fast
