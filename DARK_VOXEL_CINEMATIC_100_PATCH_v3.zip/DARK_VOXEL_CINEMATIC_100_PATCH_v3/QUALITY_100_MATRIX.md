# Quality matrix v3

| Система | Реализовано в patch | Локально проверяемо | 100% только на target |
|---|---:|---:|---:|
| Dark cinematic renderer | yes | yes | full E2E/device |
| Volumetric fog / bloom / ACES | yes | syntax/structural | visual + FPS |
| Greedy Worker meshing | yes | unit PASS | real chunks |
| Rapier rope + fallback | yes | unit PASS | browser/device |
| Giant voxel eye | yes | syntax | visual E2E |
| Eye control/blink | yes | structural | pointer/touch E2E |
| Navigator dialog | yes | structural | desktop/mobile E2E |
| RU/EN world parser | yes | unit PASS | production prompts |
| Unknown prompt fallback | yes | unit PASS | production |
| WorldMutationPlan | yes | unit PASS | production |
| Voxel text manifestation | yes | syntax | browser visual |
| Local chunk batch mutation | yes | installer fixture PASS | live world |
| `/api/voxel-batch` | yes | structural | Supabase integration |
| Offline mutation outbox | yes | structural | offline/online E2E |
| Realtime world_batch | yes | structural | 2-client E2E |
| Undo/redo | yes | unit PASS | integration E2E |
| Reference visual baseline | yes | file present | perceptual compare |
| Desktop/mobile gate | yes | definitions | Playwright PASS |
| Physical devices | protocol only | no | required |

**Truth rule:** local artifact readiness can reach **99%**. `100%` is emitted only after the installed real World_server passes full browser, persistence, existing release gates and device checks.
