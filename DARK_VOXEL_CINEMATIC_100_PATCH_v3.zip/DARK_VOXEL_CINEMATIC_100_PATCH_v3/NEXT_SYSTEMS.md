# Следующие усиления после v3

## Нужно добавить для максимального качества

1. **AI World Planner adapter** — LLM/локальная модель только как надстройка над существующим безопасным `WorldMutationPlan`; никогда не убирать deterministic fallback.
2. **Semantic voxel asset grammar** — библиотека частей: арки, окна, двери, колонны, лица, руки, растения, руины, мосты, интерьер. Это даст качественные произвольные объекты, а не только базовые prefabs.
3. **Constraint solver** — не создавать объект внутри игрока/стены; автоматически искать подходящую поверхность, опору и свободный объём.
4. **Incremental chunk meshing** — remesh только затронутых meshlets/срезов, а не всего chunk.
5. **WebGPU compute meshing candidate** — только после device matrix; WebGL2 остаётся fallback.
6. **Hi-Z depth pyramid + occlusion** для сложных миров.
7. **Temporal volumetric reprojection** — стабильнее и дешевле плотный туман.
8. **GTAO / contact-shadow pass** с adaptive budget.
9. **TAA/TRAA для cinematic HIGH/ULTRA**, с отключением на слабых мобильных.
10. **Virtual texture / KTX2 streaming budget** для будущих не-воксельных деталей.
11. **GPU memory budget telemetry**: textures, render targets, geometry, WebGPU buffers.
12. **Real device farm**: минимум старый iPhone, современный iPhone, Android 4–6 GB, desktop integrated GPU.
13. **Visual critic against SCENE_TARGET** — screenshot → perceptual compare + AI critic; baseline нельзя автоматически принимать после ухудшения.
14. **Long soak 30–60 min** — repeated create/undo/redo, resize, background/foreground, network offline/online.
15. **World-command provenance ledger** — кто/какой prompt/какой plan/какие block changes; облегчает undo и диагностику мультиплеера.
16. **CRDT/transaction world mutations** — для одновременного создания объектов несколькими пользователями без конфликтов.
17. **Streaming command queue** — большие создания разбивать на regions с priority near-camera first.
18. **Procedural destruction + reconstruction** через тот же mutation API.
19. **Spatial audio occlusion/reverb zones** для глаза/огонька/созданных объектов.
20. **Eye emotion state machine**: curiosity/fear/sleep/attention + pupil dilation + eyelid shapes, управляемые Narrative/Navigator state.

## Хорошо бы скачать бесплатно

- Basis Universal: https://github.com/BinomialLLC/basis_universal
- three-mesh-bvh: https://github.com/gkjohnson/three-mesh-bvh — ускорение тяжёлых raycast/collision задач, внедрять только после benchmark.
- glTF Transform: https://github.com/donmccurdy/glTF-Transform — для будущих imported assets, meshopt/KTX2 pipeline.
- Blender: https://www.blender.org/ — offline asset processing, если появятся authored meshes; runtime от Blender не зависеть.

Правило: ничего не добавлять только ради количества технологий. Каждый новый компонент обязан показать измеримое качество/скорость/стабильность и пройти regression gates.
