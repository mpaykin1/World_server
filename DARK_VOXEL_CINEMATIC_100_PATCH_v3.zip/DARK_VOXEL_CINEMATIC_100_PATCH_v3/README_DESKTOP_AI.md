# DARK VOXEL CINEMATIC 100 v3 — Desktop AI install / verify / repair protocol

## Цель
Сделать первую сцену World_server максимально близкой к `reference/SCENE_TARGET.jpeg`:

- тёмный 3D voxel-art мир;
- гигантский воксельный глаз слева, живой и управляемый;
- далёкий огонёк/маяк;
- cinematic fog / bloom / ACES / адаптивное качество;
- нижнее окно «НАВИГАТОР»;
- пользователь пишет естественным языком;
- команда превращается в `WorldMutationPlan`;
- перед созданием показывается glowing voxel preview;
- точный текст пользователя кратко проявляется в самом 3D-мире как voxel-text;
- объект реально появляется в voxel-world, сохраняется в Supabase batch API и синхронизируется другим клиентам;
- Undo / Redo;
- offline outbox: при временном 5xx/network объект не исчезает, операция автоматически повторяется позже;
- desktop + mobile + WebKit.

## Важное правило честности
НЕ писать «100% готово», пока одновременно не PASS:

1. `npm run navigator:gate`
2. `npm run cinematic:gate`
3. `npm run quality:world:full`
4. `npm run release:gate`
5. реальный smoke на production URL с desktop + iPhone/Android.

Локальный `--fast` gate даёт максимум 99%.

---

## 1. Перед установкой

Работать в отдельной ветке/worktree. Не вмешиваться в параллельную работу других AI.

```bash
git status
git branch --show-current
```

Не патчить `main/master` напрямую. Installer специально это блокирует. Он также создаёт backup в `.dark-voxel-backup/<timestamp>/`.

---

## 2. Установка

### Windows

```bat
INSTALL_WINDOWS.cmd C:\Users\user\Desktop\World_server
```

### Универсально

```bash
node install.mjs /path/to/World_server
```

Installer:

- не создаёт дубликат существующего World Quality Autopilot;
- обновляет Three/Rapier/Meshoptimizer pin;
- копирует v2 cinematic stack + v3 Navigator/world-command stack;
- добавляет `/api/voxel-batch`;
- подключает local batch remesh, realtime world_batch, undo/redo;
- исправляет TEXTAREA keyboard conflict;
- добавляет MIME `.mjs/.ktx2/.gltf/.glb`;
- подключает reference baseline в `data/quality-reference/`.

---

## 3. Что скачать / проверить

Installer сам делает `npm install --ignore-scripts` и `npm run graphics:vendor`.

Pinned OSS:

- Three.js `0.185.1`
- `@dimforge/rapier3d-compat` `0.20.0`
- Meshoptimizer `1.2.0`

Для KTX2 желательно/нужно поставить бесплатный Basis Universal (`basisu`):

- https://github.com/BinomialLLC/basis_universal

После установки:

```bash
npm run assets:ktx2 -- --probe
```

Для E2E:

```bash
npx playwright install chromium webkit
```

Не скачивать второй движок, если существующий Three/WebGL2 pipeline решает задачу. WebGPU/TSL пока оставлять candidate/fallback, а не ломать стабильный WebGL2 production path.

---

## 4. Быстрая проверка

```bash
npm run navigator:check
npm run navigator:test
npm run cinematic:check
npm run cinematic:test
npm run navigator:gate -- --fast
npm run cinematic:gate -- --fast
```

Ожидается:

- Navigator structural = 100% PASS;
- unit tests = PASS;
- fast readiness = 99%, а не ложные 100%.

---

## 5. Полная проверка

```bash
npm run navigator:gate
npm run cinematic:gate
npm run quality:world:full
npm run release:gate
```

Playwright должен проверить минимум:

- desktop Chromium;
- mobile Chromium;
- mobile WebKit;
- tablet Chromium.

Обязательный сценарий:

1. открыть `/apps/voxel-world/?cinematic=dark-void&navigator=1`;
2. увидеть глаз + огонёк + окно Навигатора;
3. написать `Создай маленькую башню`;
4. увидеть voxel preview;
5. увидеть фактически созданные блоки;
6. проверить `VoxelWorldRuntime.stats().worldCommands.lastBlocks > 0`;
7. нажать «Отменить»;
8. проверить Redo;
9. на телефоне textarea должна печатать текст, а не двигать игрока;
10. кнопки и safe-area не должны перекрываться.

---

## 6. Как работает «что написал — появляется в мире»

### Tier A — гарантированный локальный CPU fallback
`world-command-parser.mjs` понимает RU/EN команды и строит procedural voxel prefabs:

- глаз;
- огонёк/маяк;
- башня;
- дерево;
- мост;
- лестница;
- дом;
- портал;
- стена;
- сфера;
- монолит.

Любая неизвестная фраза всё равно создаёт детерминированную `wish-sculpture`, поэтому команда никогда не превращается в «ничего».

### Literal manifestation
`world-summoning-visual.mjs` рисует введённую пользователем фразу через Canvas raster → InstancedMesh voxels. То есть слова пользователя сами кратко становятся частью 3D-сцены.

### Tier B — будущий AI planner
Не заменять Tier A. Добавить AI planner как optional adapter, который возвращает тот же безопасный `WorldMutationPlan`. Если AI/API недоступен — fallback должен продолжать работать мгновенно.

---

## 7. Глаз

`voxel-eye-runtime.mjs`:

- InstancedMesh voxel eye;
- voxel wall/face вокруг глаза;
- sclera / iris / pupil / rim;
- micro gaze;
- auto blink;
- режимы `camera`, `user`, `beacon`, `idle`;
- кнопка в Navigator UI переключает режим;
- `user` управляется pointer/touch;
- `camera` следит за игроком;
- `beacon` смотрит на огонёк.

Главный глаз — hero asset. Не понижать его детализацию агрессивно при quality degradation; сначала снижать fog samples, bloom, particles, DPR дальнего окружения.

---

## 8. Производительность

Уже используются:

- greedy meshing + Worker;
- chunk batch rebuild вместо rebuild на каждый созданный блок;
- batch persistence: максимум 512 блоков/request;
- realtime broadcast chunked по 128 блоков;
- adaptive DPR / effect budgets из World Quality Autopilot;
- GPU timing вокруг реального render;
- fog-aware visibility/HLOD;
- Meshoptimizer/KTX2 pipeline;
- offline mutation outbox;
- fixed block budget для одной команды.

Не исправлять FPS удалением hero eye, disabling all shadows или ухудшением графики рядом с камерой. Сначала оптимизировать дорогие дальние/экранные эффекты.

---

## 9. Если ошибка

Desktop AI обязан:

1. воспроизвести;
2. записать точный failing test / stack / browser/device;
3. найти первопричину;
4. исправить в общей системе, а не только конкретную сцену;
5. добавить regression test;
6. прогнать минимум `navigator:gate -- --fast` + affected existing gates;
7. затем полный gate;
8. не уменьшать thresholds ради PASS;
9. сохранить причину/решение в существующей knowledge/regression системе World_server;
10. если исправление полезно другим мирам — распространить через shared system.

### Типовые ошибки

**Пользователь печатает, а персонаж идёт:**
проверить TEXTAREA guard в keyboard handler.

**Объект появляется, но после reload исчезает:**
проверить `/api/voxel-batch`, Supabase env, outbox и response status. Не убирать persistence.

**429 при генерации:**
не возвращаться к тысячам `set_block`; использовать batch endpoint.

**После команды FPS падает:**
проверить, что `setBlocksLocalBatch()` rebuild делает один раз на затронутый chunk и работает greedy Worker.

**Другой клиент не видит объект:**
проверить Supabase broadcast `world_batch` + database override.

**Глаз исчезает/упрощается:**
hero eye не должен попадать под эвристический far-culling.

---

## 10. Acceptance для первой сцены

Сравнить с `reference/SCENE_TARGET.jpeg` и `data/quality-reference/navigator-scene-target.jpeg`.

PASS только если:

- общий кадр визуально тёмный cinematic voxel art;
- глаз читается сразу;
- огонёк читается как второй visual anchor;
- UI не выглядит обычной HTML-формой;
- ввод работает на desktop/mobile;
- созданный объект реально меняет мир;
- нет console exceptions;
- нет дублирования world systems;
- performance не проседает ниже текущих device budgets;
- существующий обычный voxel-world без query `cinematic=dark-void` не сломан.

