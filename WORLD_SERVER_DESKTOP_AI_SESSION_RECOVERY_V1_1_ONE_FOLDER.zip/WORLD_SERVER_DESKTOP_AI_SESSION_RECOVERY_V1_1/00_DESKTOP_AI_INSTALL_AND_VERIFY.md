# Desktop AI — install and verify Session Recovery V1.1

## Mandatory rules

- Work from `C:\Users\user\Desktop\World_server`.
- Do not work directly on `master` and do not merge automatically.
- Do not discard existing dirty work to make the installer pass.
- Do not disable existing blocker/quality timers.
- Do not create a second scheduler for Session Recovery; this patch does not need one.

## 1. Stabilize the current command

If another command is visibly still running, do **not** install concurrently with that write operation. Finish the current atomic command or confirm it has stopped. Existing background long-soak/blocker timers may remain running.

## 2. Install

```powershell
cd C:\Users\user\Desktop\World_server
node "<UNPACKED_PATCH_FOLDER>\install-session-recovery.cjs"
```

Expected: `pass: true`, self-test PASS, backup under `.session-recovery-backups/v1-1-*`.

## 3. First recovery scan

```powershell
npm run desktop-ai:resume
npm run desktop-ai:unfinished
npm run desktop-ai:session:status
```

Verify files exist:

- `state/session-recovery/current.json`
- `state/session-recovery/DESKTOP_AI_RESUME.md`
- `state/session-recovery/UNFINISHED_WORK.json`

## 4. Verify unfinished processes are picked up

The resume packet must list any real unfinished work it finds. In the current World_server this can include:

- unresolved recovery queue steps;
- blocker-repair `requires_ai` work;
- timer-managed blocker `waiting` entries and `nextRunAt`;
- real 8h long-soak if running/waiting;
- active blocker-repair/quality/toolchain/Vercel processes;
- a command that started through `desktop-ai:run` but did not record completion;
- dirty Git work that must be reconciled.

**Do not convert waiting or optional external capability evidence into PASS.**

## 5. Important command protocol

For important commands prefer:

```powershell
npm run desktop-ai:checkpoint -- --message "verified state before operation" --next "exact next action"
npm run desktop-ai:run -- npm run <important-command>
```

If a session crashes while that command is running, the next session runs `npm run desktop-ai:resume` and must:

- detect whether the process is still alive;
- if alive: do not run a duplicate;
- if not alive: verify side effects/log/state before rerunning;
- continue from the first unresolved verified point.

## 6. Every new Desktop AI session

The **first command before any edits** is always:

```powershell
cd C:\Users\user\Desktop\World_server
npm run desktop-ai:resume
```

Then read:

- `WORK_IN_PROGRESS.md`
- `state/session-recovery/DESKTOP_AI_RESUME.md`
- `state/session-recovery/UNFINISHED_WORK.json`

Do not ask the user to reconstruct old chat context when the repository state contains it.

## 7. Regression verification

```powershell
npm run desktop-ai:session:self-test
npm run desktop-ai:resume
npm run desktop-ai:unfinished
npm run desktop-ai:check
npm run blockers:status
```

Run other relevant gates from `WORK_IN_PROGRESS.md`. Do not fake unavailable external evidence.

## 8. Completion rule

Do not archive/finish the recovery session while explicit recovery steps or an interrupted command remain unresolved. Background timer-managed work may remain visible and must be picked up again by the next session.

Only after real task completion:

```powershell
npm run desktop-ai:session:finish
```

## Required report back

Report:

- install PASS/FAIL;
- self-test score;
- `UNFINISHED_WORK.json` counts and discovered sources;
- whether any previously started command/process is still running;
- branch + HEAD;
- exact next action;
- whether any blocker remains `requires_ai` / `waiting`;
- do not claim 100% if evidence is still pending.
