WORLD_SERVER_DESKTOP_AI_SESSION_RECOVERY_V1_1

P0 patch: crash/session recovery + unfinished-process discovery.

Goal: a new Desktop AI chat must not lose unfinished work. It runs `npm run desktop-ai:resume`, scans durable state and live background processes, and continues from the first unresolved verified point without duplicating work that is still running.

Install from World_server root:
  node "<THIS_FOLDER>\install-session-recovery.cjs"

Then:
  npm run desktop-ai:resume
  npm run desktop-ai:unfinished
  npm run desktop-ai:session:status

Read 00_DESKTOP_AI_INSTALL_AND_VERIFY.md for the mandatory procedure.
