# Design & Safety — Session Recovery V1.1

## Durable truth

Chat/session memory is disposable. Recovery truth lives in repository state and is reconciled with current Git/OS reality on every resume.

## Unfinished-work discovery

`desktop-ai:resume` calls the unfinished-work scanner before choosing the next action. It combines:

1. explicit recovery steps (`pending/running/failed/blocked`);
2. an `activeCommand` left behind if `desktop-ai:run` started but never recorded completion;
3. blocker-repair durable state and timers;
4. known live OS background processes;
5. `WORK_IN_PROGRESS.md` Next action;
6. Git dirty state and checkpoint divergence.

The scan is written atomically to `state/session-recovery/UNFINISHED_WORK.json`.

## Running process rule

A live process is never restarted merely because a new Desktop AI chat appeared. Resume reports it and instructs the new session to observe durable state/output. This prevents duplicate long-soaks, duplicate blocker repair, duplicate deploy/inspect loops, and race conditions.

## Interrupted command rule

Before an important command, V1.1 persists `activeCommand` plus a pre-command snapshot. Normal completion clears `activeCommand`. If the AI/session dies in between, the next resume can see the orphaned command. It must verify side effects before deciding whether to rerun.

## Lock safety

- live same-host lock: never removed;
- read-only `resume/status/unfinished` can still observe a live operation without starting a duplicate;
- dead same-host PID: lock is quarantined immediately;
- foreign-host lock: quarantined only after configured expiry;
- stale locks are archived, not silently deleted.

## Truthfulness

Android/iOS/remote-CAS optional capability waits remain visible but do not become fake PASS. Required `requires_ai` blockers remain actionable. Timer-managed work remains `waiting` until its real condition/time occurs.

## Git safety

Recovery never commits, pushes, merges, resets, or discards changes automatically. Git reality overrides stale state. Divergence is surfaced as a warning requiring reconciliation.
