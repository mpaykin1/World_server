# WORLD_SERVER_DESKTOP_AI_SESSION_RECOVERY_V1_1

## Что исправляет V1.1

Desktop AI может зависнуть или пользователь может открыть новую сессию. Новая сессия не должна начинать задачу заново и не должна терять фоновые процессы.

После установки **первое действие каждой новой Desktop AI-сессии**:

```powershell
cd C:\Users\user\Desktop\World_server
npm run desktop-ai:resume
```

`resume` автоматически проверяет:

- `WORK_IN_PROGRESS.md`;
- recovery queue и последний checkpoint;
- незавершённую команду, если сессия умерла между START и PASS/FAIL;
- `state/blocker-repair/state.json`, включая `requires_ai`, `waiting` и `nextRunAt`;
- живые фоновые процессы blocker-repair / long-soak / quality autoloop / toolchain / Vercel inspect;
- Git branch / HEAD / незакоммиченные изменения;
- предыдущие ошибки и последний успешный шаг.

Результат сохраняется в:

- `state/session-recovery/DESKTOP_AI_RESUME.md`
- `state/session-recovery/UNFINISHED_WORK.json`

Если старый процесс ещё жив, новая сессия **не запускает его второй раз**. Если процесс оборвался, он считается `interrupted`, а не автоматически FAIL/PASS: сначала проверяются реальные side effects и evidence.

Патч не создаёт новый scheduler и не делает auto-push/auto-merge.
