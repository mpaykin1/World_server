#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const PATCH_ROOT = __dirname;
const ROOT = process.cwd();
const BACKUP_ROOT = path.join(ROOT, '.session-recovery-backups', `v1-1-${new Date().toISOString().replace(/[:.]/g, '-')}`);
const MARK_START = '<!-- WORLD_SERVER_DESKTOP_AI_SESSION_RECOVERY_V1_START -->';
const MARK_END = '<!-- WORLD_SERVER_DESKTOP_AI_SESSION_RECOVERY_V1_END -->';

const scripts = {
  'desktop-ai:resume': 'node scripts/desktop-ai-session-recovery.cjs resume',
  'desktop-ai:session:start': 'node scripts/desktop-ai-session-recovery.cjs start',
  'desktop-ai:checkpoint': 'node scripts/desktop-ai-session-recovery.cjs checkpoint',
  'desktop-ai:step:add': 'node scripts/desktop-ai-session-recovery.cjs step-add',
  'desktop-ai:step:done': 'node scripts/desktop-ai-session-recovery.cjs step-done',
  'desktop-ai:step:fail': 'node scripts/desktop-ai-session-recovery.cjs step-fail',
  'desktop-ai:run': 'node scripts/desktop-ai-session-recovery.cjs run',
  'desktop-ai:heartbeat': 'node scripts/desktop-ai-session-recovery.cjs heartbeat',
  'desktop-ai:session:status': 'node scripts/desktop-ai-session-recovery.cjs status',
  'desktop-ai:session:finish': 'node scripts/desktop-ai-session-recovery.cjs finish',
  'desktop-ai:unfinished': 'node scripts/desktop-ai-session-recovery.cjs unfinished',
  'desktop-ai:session:self-test': 'node scripts/desktop-ai-session-recovery.cjs self-test'
};

const agentsBlock = [
  MARK_START,
  '## DESKTOP AI SESSION RECOVERY V1.1 — mandatory crash/resume protocol',
  '',
  '- A Desktop AI chat/session is disposable. Critical task context must live in the repository recovery state, not only in chat memory.',
  '- **At the beginning of every new Desktop AI session, before editing files, run `npm run desktop-ai:resume`.** This command must scan unfinished durable work and live background processes before choosing the next action.',
  '- Read `WORK_IN_PROGRESS.md` and `state/session-recovery/DESKTOP_AI_RESUME.md`; then verify `git status`, current branch, and HEAD. Git reality overrides stale recovery metadata.',
  '- Do not restart the task from scratch when a valid unfinished recovery session exists. Continue from the first unresolved verified checkpoint. Read `state/session-recovery/UNFINISHED_WORK.json` and reconcile every discovered unfinished process.',
  '- Before risky edits, migrations, deployment, large installs, or long-running verification, run `npm run desktop-ai:checkpoint -- --message "<verified state>" --next "<exact next action>"`.',
  '- Register multi-step work with `desktop-ai:step:add`, then mark real completion with `desktop-ai:step:done`; record reproducible failures with `desktop-ai:step:fail`.',
  '- Prefer `npm run desktop-ai:run -- <command>` for important tests/build/deploy commands so command, exit code and log tail survive a dead session. If a session dies after command start and before completion is recorded, the next session must treat it as interrupted and verify side effects before rerunning.',
  '- If a discovered background process is still alive (for example long-soak or blocker repair), **do not start a duplicate**; observe its durable state and continue when it completes/fails/timer fires.',
  '- Timer-managed waiting work remains visible after a new chat/session and must be picked up automatically by `desktop-ai:resume`.',
  '- Never clear a live recovery lock. Only the recovery engine may quarantine a safely stale/dead lock.',
  '- Never fake PASS/evidence after a restart. Never auto-push or auto-merge from recovery. `master` remains protected.',
  '- After 2–3 failed attempts at the same error, change strategy and record the new root-cause hypothesis.',
  '- Finish/archive a session only after the real completion criteria and final evidence are satisfied: `npm run desktop-ai:session:finish`.',
  MARK_END
].join('\n');

function die(msg) { throw new Error(msg); }
function ensureDir(p) { fs.mkdirSync(p, { recursive: true }); }
function sha256File(p) { return crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'); }
function copyFile(src, dst) { ensureDir(path.dirname(dst)); fs.copyFileSync(src, dst); }
function backup(pathRel) {
  const src = path.join(ROOT, pathRel);
  if (!fs.existsSync(src)) return;
  const dst = path.join(BACKUP_ROOT, pathRel);
  ensureDir(path.dirname(dst)); fs.copyFileSync(src, dst);
}
function restore(pathRel) {
  const b = path.join(BACKUP_ROOT, pathRel); const d = path.join(ROOT, pathRel);
  if (fs.existsSync(b)) { ensureDir(path.dirname(d)); fs.copyFileSync(b, d); }
  else { try { fs.unlinkSync(d); } catch {} }
}
function managedAppend(raw, block) {
  const s = raw.indexOf(MARK_START), e = raw.indexOf(MARK_END);
  if (s >= 0 && e > s) return raw.slice(0,s).replace(/\s+$/,'') + '\n\n' + block + '\n' + raw.slice(e + MARK_END.length).replace(/^\s+/,'');
  return raw.replace(/\s+$/,'') + '\n\n' + block + '\n';
}
function verifyManifest() {
  const mf = JSON.parse(fs.readFileSync(path.join(PATCH_ROOT, 'PATCH_MANIFEST.json'),'utf8'));
  const bad = [];
  for (const f of mf.files || []) {
    const p = path.join(PATCH_ROOT, f.path);
    if (!fs.existsSync(p)) bad.push({ path:f.path, reason:'missing' });
    else if (sha256File(p) !== f.sha256) bad.push({ path:f.path, reason:'sha256' });
  }
  if (bad.length) die(`Patch manifest validation failed: ${JSON.stringify(bad)}`);
  return mf;
}

const touched = ['package.json','AGENTS.md','.gitignore','00_DESKTOP_AI_MASTER_INSTALL.md','WORK_IN_PROGRESS.md','scripts/desktop-ai-session-recovery.cjs','data/desktop-ai-session-recovery-policy.json'];
let copiedPayload = [];
try {
  if (!fs.existsSync(path.join(ROOT,'package.json'))) die('Run installer from World_server repository root (package.json missing).');
  const manifest = verifyManifest();
  ensureDir(BACKUP_ROOT);
  for (const f of touched) backup(f);

  for (const rel of ['scripts/desktop-ai-session-recovery.cjs','data/desktop-ai-session-recovery-policy.json']) {
    const src = path.join(PATCH_ROOT,'payload',rel), dst = path.join(ROOT,rel);
    if (!fs.existsSync(src)) die(`Missing payload: ${rel}`);
    copyFile(src,dst); copiedPayload.push(rel);
  }

  const pkgPath = path.join(ROOT,'package.json');
  const pkg = JSON.parse(fs.readFileSync(pkgPath,'utf8')); pkg.scripts = pkg.scripts || {};
  for (const [k,v] of Object.entries(scripts)) {
    if (pkg.scripts[k] && pkg.scripts[k] !== v) die(`Refusing to overwrite conflicting package script ${k}: ${pkg.scripts[k]}`);
    pkg.scripts[k] = v;
  }
  fs.writeFileSync(pkgPath, JSON.stringify(pkg,null,2)+'\n','utf8');

  const agentsPath = path.join(ROOT,'AGENTS.md');
  const agentsRaw = fs.existsSync(agentsPath) ? fs.readFileSync(agentsPath,'utf8') : '# AGENTS.md\n';
  fs.writeFileSync(agentsPath, managedAppend(agentsRaw, agentsBlock), 'utf8');

  const masterPath = path.join(ROOT,'00_DESKTOP_AI_MASTER_INSTALL.md');
  if (fs.existsSync(masterPath)) {
    const raw = fs.readFileSync(masterPath,'utf8');
    const compact = `${MARK_START}\n## Session recovery — mandatory first action in a new session\nRun \`npm run desktop-ai:resume\` before changing files. Continue from the first unresolved verified checkpoint; do not restart completed work. See \`AGENTS.md\`.\n${MARK_END}`;
    fs.writeFileSync(masterPath, managedAppend(raw, compact), 'utf8');
  }

  const giPath = path.join(ROOT,'.gitignore');
  let gi = fs.existsSync(giPath) ? fs.readFileSync(giPath,'utf8') : '';
  for (const line of ['state/session-recovery/','.session-recovery-backups/']) {
    const re = new RegExp(`^${line.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}$`,'m');
    if (!re.test(gi)) gi = gi.replace(/\s+$/,'') + '\n' + line + '\n';
  }
  fs.writeFileSync(giPath,gi,'utf8');

  const self = spawnSync(process.execPath,[path.join(ROOT,'scripts','desktop-ai-session-recovery.cjs'),'self-test'],{cwd:ROOT,encoding:'utf8',windowsHide:true});
  if (self.status !== 0) die(`Self-test failed:\n${self.stdout}\n${self.stderr}`);
  const init = spawnSync(process.execPath,[path.join(ROOT,'scripts','desktop-ai-session-recovery.cjs'),'init'],{cwd:ROOT,encoding:'utf8',windowsHide:true});
  if (init.status !== 0) die(`Initialization failed:\n${init.stdout}\n${init.stderr}`);

  const report = {
    patch:'WORLD_SERVER_DESKTOP_AI_SESSION_RECOVERY_V1_1', version:'1.1.0', installedAt:new Date().toISOString(),
    manifestSchemaVersion:manifest.schemaVersion, backup:path.relative(ROOT,BACKUP_ROOT), payload:copiedPayload,
    scripts:Object.keys(scripts), selfTest:JSON.parse(self.stdout), initOutput:init.stdout.trim(), pass:true,
    next:['npm run desktop-ai:resume','npm run desktop-ai:unfinished','npm run desktop-ai:session:status']
  };
  fs.writeFileSync(path.join(ROOT,'SESSION_RECOVERY_V1_1_INSTALL_REPORT.json'),JSON.stringify(report,null,2)+'\n','utf8');
  console.log(JSON.stringify(report,null,2));
} catch (e) {
  for (const f of touched) { try { restore(f); } catch {} }
  for (const f of copiedPayload) { if (!fs.existsSync(path.join(BACKUP_ROOT,f))) { try { fs.unlinkSync(path.join(ROOT,f)); } catch {} } }
  console.error(`[SESSION_RECOVERY_INSTALL] FAIL: ${e.message}`);
  process.exit(1);
}
