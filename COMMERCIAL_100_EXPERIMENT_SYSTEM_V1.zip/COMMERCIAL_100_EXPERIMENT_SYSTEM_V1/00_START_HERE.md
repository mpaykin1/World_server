# 00_START_HERE — COMMERCIAL 100 EXPERIMENT SYSTEM V1

## Цель

Установить в `World_server` постоянный стандарт коммерческой упаковки с целью `100/100`,
**не превращая его в запрет на эксперименты**.

Ключевая архитектура:

- разные главные можно выпускать и тестировать параллельно;
- низкий/неполный Commercial Score **не блокирует release**;
- предыдущие главные никогда не удаляются;
- предыдущие версии переводятся в `library`;
- `100/100` — цель и promotion-to-primary gate;
- реальный победитель определяется только реальными сравнительными метриками.

## Инструкция Desktop AI

1. Открой корень `World_server`.
2. Прочитай существующие:
   - `AGENTS.md`
   - `DESKTOP_AI_INSTALL_AND_VERIFY.md`
   - `WORK_IN_PROGRESS.md`
3. Создай отдельную ветку, не работай в `master`.
4. До установки выполни существующие baseline/golden тесты и зафиксируй уже существующие ошибки.
5. Положи **всю эту папку целиком** в удобное место рядом с репозиторием.
6. Из корня `World_server` выполни:

```powershell
node <ПУТЬ_К_ЭТОЙ_ПАПКЕ>\install-commercial-100.cjs
```

7. Затем обязательно:

```powershell
npm run commercial:validate
node --test test/commercial-standard.test.js
npm run commercial:audit
npm run check
npm run golden:check
npm run release:gate
```

8. Если существующие quality-gates падают — исправляй причину, не отключай тесты и не упрощай графику.
9. Если установка не находит ожидаемый файл/конфликтует с уже существующей одноимённой системой:
   - не создавай дубликат;
   - сравни реализации;
   - усили существующую;
   - адаптацию запиши в `WORK_IN_PROGRESS.md`;
   - повторяй тесты до PASS.
10. **Не добавляй Commercial Score как hard release gate.**
11. Для каждой новой главной создавай отдельный путь и регистрируй его:
```powershell
node scripts/home-experiment-manager.js add <id> <path> "Название"
node scripts/home-experiment-manager.js activate <id>
```
12. Старую главную не удаляй:
```powershell
node scripts/home-experiment-manager.js library <old-id>
```
13. Чтобы сделать вариант новой primary:
```powershell
node scripts/commercial-promotion-check.js <id>
node scripts/home-experiment-manager.js promote <id>
```
14. Если promotion score <100 — вариант всё равно можно продолжать публиковать и тестировать.
15. Никогда не придумывай retention/conversion/payment/winner data.
16. После успешного внедрения создай PR, приложи результаты тестов и Commercial report.

## Что патч намеренно НЕ делает

- не удаляет и не заменяет существующую главную;
- не меняет `release:gate`;
- не утверждает, что рынок/конверсия уже 100;
- не требует платных библиотек;
- не создаёт второй quality-orchestrator.

## Completion criteria

- `commercial:validate` PASS;
- `commercial-standard.test.js` PASS;
- существующие golden/release tests не ухудшены;
- старые главные физически сохраняются;
- новая главная может быть добавлена независимо;
- promotion и release разделены;
- коммерческие цели всех ранее оценённых систем стоят на 100/100.
