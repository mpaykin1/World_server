# COMMERCIAL_100_EXPERIMENT_SYSTEM_V1

Единый патч для World_server.

Содержит:
- Commercial 100 standard;
- отдельные rubrics для user-facing и infrastructure;
- targets=100 для ранее оценённых систем;
- append-only registry всех главных;
- immutable-ish event ledger истории;
- менеджер add/activate/library/promote;
- non-blocking release audit;
- hard promotion packaging check;
- regression tests;
- installer;
- обязательную инструкцию Desktop AI.

Внешние зависимости: **нет**.
