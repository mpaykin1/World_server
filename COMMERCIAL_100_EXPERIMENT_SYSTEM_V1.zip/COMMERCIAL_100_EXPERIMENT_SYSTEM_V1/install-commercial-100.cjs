'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PATCH = __dirname;
const ROOT = process.cwd();
const PAYLOAD = path.join(PATCH,'payload');
const backupRoot = path.join(ROOT,'.commercial-100-backups',new Date().toISOString().replace(/[:.]/g,'-'));

function mkdir(p){fs.mkdirSync(p,{recursive:true});}
function copyRecursive(src,dst){
  const st=fs.statSync(src);
  if(st.isDirectory()){
    mkdir(dst);
    for(const n of fs.readdirSync(src)) copyRecursive(path.join(src,n),path.join(dst,n));
  }else{
    mkdir(path.dirname(dst));
    if(fs.existsSync(dst)){
      const rel=path.relative(ROOT,dst);
      const b=path.join(backupRoot,rel);
      mkdir(path.dirname(b)); fs.copyFileSync(dst,b);
    }
    fs.copyFileSync(src,dst);
  }
}
function appendOnce(file, marker, text){
  const p=path.join(ROOT,file);
  if(!fs.existsSync(p)) throw new Error(`Required file missing: ${file}`);
  const src=fs.readFileSync(p,'utf8');
  if(src.includes(marker)) return;
  mkdir(path.dirname(path.join(backupRoot,file)));
  fs.copyFileSync(p,path.join(backupRoot,file));
  fs.writeFileSync(p,src.replace(/\s*$/,'')+'\n\n'+text.trim()+'\n','utf8');
}
function patchPackage(){
  const p=path.join(ROOT,'package.json');
  if(!fs.existsSync(p)) throw new Error('package.json not found; run installer from World_server root');
  const src=fs.readFileSync(p,'utf8');
  const pkg=JSON.parse(src);
  pkg.scripts ||= {};
  const scripts={
    'commercial:validate':'node scripts/commercial-validate.js',
    'commercial:report':'node scripts/commercial-report.js',
    'commercial:audit':'node scripts/commercial-release-audit.js',
    'commercial:score':'node scripts/commercial-score.js',
    'commercial:promotion':'node scripts/commercial-promotion-check.js',
    'home:experiments':'node scripts/home-experiment-manager.js list'
  };
  for(const [k,v] of Object.entries(scripts)){
    if(pkg.scripts[k] && pkg.scripts[k]!==v) throw new Error(`Refusing to overwrite existing npm script ${k}`);
    pkg.scripts[k]=v;
  }
  mkdir(path.dirname(path.join(backupRoot,'package.json')));
  fs.copyFileSync(p,path.join(backupRoot,'package.json'));
  fs.writeFileSync(p,JSON.stringify(pkg,null,2)+'\n','utf8');
}

if(!fs.existsSync(path.join(ROOT,'AGENTS.md'))) throw new Error('AGENTS.md missing');
if(!fs.existsSync(path.join(ROOT,'DESKTOP_AI_INSTALL_AND_VERIFY.md'))) throw new Error('DESKTOP_AI_INSTALL_AND_VERIFY.md missing');

copyRecursive(PAYLOAD,ROOT);
patchPackage();
appendOnce('AGENTS.md','## COMMERCIAL 100 — permanent product experiment standard',fs.readFileSync(path.join(PATCH,'AGENTS_APPEND.md'),'utf8'));
appendOnce('DESKTOP_AI_INSTALL_AND_VERIFY.md','## COMMERCIAL 100 / HOMEPAGE EXPERIMENT PROTOCOL',fs.readFileSync(path.join(PATCH,'DESKTOP_AI_APPEND.md'),'utf8'));

console.log('COMMERCIAL 100 INSTALL: PASS');
console.log('Backup:',backupRoot);
console.log('Release gate was NOT modified.');
console.log('Commercial score/evidence does NOT block release.');
console.log('Run: npm run commercial:validate');
console.log('Run: node --test test/commercial-standard.test.js');
console.log('Run: npm run commercial:audit');
