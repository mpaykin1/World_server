# Design and safety — Session Recovery V1.2

## Core invariant
The chat/session is not the source of truth. Durable repository state + Git reality are the source of truth.

## Watchdog safety
1. Watchdog is observer-first and uses its own `watchdog.lock.json`; it never waits for or owns `state/blocker-repair/unified.lock`.
2. A live PID is never killed automatically.
3. A live long-soak/timer-managed process is classified `WAITING_VALID`, not as a hang.
4. A live process with no durable progress beyond `stalledMinutes` becomes `STALLED`; recovery request is written, but no kill/reset occurs.
5. A process is `DEAD` only when unfinished work exists and no responsible process is present (or a same-host lock PID is proven dead).
6. On `DEAD`, the engine may acquire the recovery lock, quarantine only a proven-dead stale lock, create a Git snapshot/checkpoint, and mark the session interrupted.
7. Uncommitted changes are preserved; no blind `git reset`, auto-commit, auto-push, merge, deploy, or fake PASS.

## Progress detection
The watchdog compares durable signals between checks: recovery state, checkpoint/steps, Git HEAD/worktree summary, `WORK_IN_PROGRESS.md`, blocker state/gates, long-soak log, and recorded command log.

## Scheduler separation
The watchdog task runs every 5 minutes on Windows and is intentionally independent because it must still report health when the main unified scheduler is blocked. It never starts the main cycle, so it does not duplicate blocker repair.
