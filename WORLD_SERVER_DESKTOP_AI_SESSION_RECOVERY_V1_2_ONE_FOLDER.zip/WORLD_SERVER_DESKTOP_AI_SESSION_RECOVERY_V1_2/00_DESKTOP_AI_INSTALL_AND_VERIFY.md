# Desktop AI — install and verify Session Recovery V1.2

## Mandatory rules
- Finish the current atomic file write/commit operation before installing.
- Do not work directly on `master` and do not merge automatically.
- Preserve existing blocker-repair timers and long-soak state.
- Never delete a live lock or kill a live PID merely to make installation pass.

## Install
From the World_server repository root:

```powershell
node "<PATCH_FOLDER>\install-session-recovery.cjs"
```

The installer backs up touched files, verifies the patch manifest, installs/upgrades the recovery engine, updates package scripts + managed AGENTS instructions, runs self-tests and initial health, and on Windows installs the independent 5-minute watchdog task.

## Verify
Run:

```powershell
npm run desktop-ai:session:self-test
npm run desktop-ai:health
npm run desktop-ai:resume
npm run desktop-ai:unfinished
npm run desktop-ai:session:status
```

Required:
- self-test PASS;
- `state/session-recovery/SESSION_HEALTH.json` exists;
- health is one of `LIVE`, `WAITING_VALID`, `STALLED`, `DEAD`, `IDLE`;
- `UNFINISHED_WORK.json` and `DESKTOP_AI_RESUME.md` exist after resume;
- Windows: Task Scheduler contains `WorldServer-SessionWatchdog-<repo-hash>` and it is Ready/runnable;
- watchdog must not create or run blocker repair/deploy/push/merge commands.

## If current Desktop AI appears frozen
Run only this safe diagnostic first:

```powershell
npm run desktop-ai:health
```

Interpretation:
- `LIVE`: current work is moving; do not duplicate it.
- `WAITING_VALID`: legitimate wait; leave it running.
- `STALLED`: open a new Desktop AI session if UI is unresponsive, run `desktop-ai:resume`, inspect PID/logs; do not kill automatically.
- `DEAD`: open a new session and run `desktop-ai:resume`; verify side effects and continue from checkpoint.

## New-session protocol
Every new Desktop AI session must begin with:

```powershell
cd C:\Users\user\Desktop\World_server
npm run desktop-ai:health
npm run desktop-ai:resume
```

Then read `SESSION_HEALTH.json`, `UNFINISHED_WORK.json`, `DESKTOP_AI_RESUME.md`, `WORK_IN_PROGRESS.md`, verify Git branch/HEAD/status, and continue only the unfinished verified work.
