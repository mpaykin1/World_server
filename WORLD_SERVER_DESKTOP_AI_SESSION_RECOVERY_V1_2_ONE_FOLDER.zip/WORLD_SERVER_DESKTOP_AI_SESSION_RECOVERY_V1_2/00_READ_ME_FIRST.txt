WORLD_SERVER_DESKTOP_AI_SESSION_RECOVERY_V1_2

P0 patch: crash/session recovery + independent hang watchdog.

Desktop AI: open 00_DESKTOP_AI_INSTALL_AND_VERIFY.md and follow it exactly.
After install every new session starts with:
  npm run desktop-ai:health
  npm run desktop-ai:resume

Health states: LIVE / WAITING_VALID / STALLED / DEAD / IDLE.
The watchdog observes only; it never starts blocker repair/deploy/push/merge.
On proven DEAD it may create a recovery checkpoint. It never kills a live PID automatically.
