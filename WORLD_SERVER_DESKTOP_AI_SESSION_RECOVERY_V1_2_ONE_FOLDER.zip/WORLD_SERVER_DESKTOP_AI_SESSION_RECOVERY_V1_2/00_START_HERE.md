# WORLD SERVER — Desktop AI Session Recovery V1.2

## Purpose
Make Desktop AI sessions disposable without losing work. If a chat freezes, crashes, or a new session is opened, the repository keeps the task context and unfinished-process registry.

V1.2 adds an **independent Session Watchdog**. It continues checking health even when Desktop AI or the unified blocker scheduler is waiting on a lock.

## Health states
- `LIVE` — recent durable activity/progress is visible.
- `WAITING_VALID` — legitimate timer / long-soak / known background process is still running. Do not kill or duplicate it.
- `STALLED` — responsible PID is alive but durable progress has not changed beyond the policy threshold. Diagnose before killing anything.
- `DEAD` — unfinished work exists but the responsible process is proven absent/dead. Watchdog creates a safe recovery checkpoint when possible.
- `IDLE` — no active unfinished recovery work.

## Files created at runtime
- `state/session-recovery/current.json`
- `state/session-recovery/UNFINISHED_WORK.json`
- `state/session-recovery/DESKTOP_AI_RESUME.md`
- `state/session-recovery/SESSION_HEALTH.json`
- `state/session-recovery/WATCHDOG_RECOVERY_REQUEST.md` (only when STALLED/DEAD)
- snapshots/history/logs under `state/session-recovery/`

## Commands
```powershell
npm run desktop-ai:health
npm run desktop-ai:resume
npm run desktop-ai:unfinished
npm run desktop-ai:session:status
```

On Windows the installer also creates a lightweight Task Scheduler watchdog every 5 minutes. It is intentionally separate from the main repair scheduler: it **does not run repairs**, deploys, pushes, or merges.
