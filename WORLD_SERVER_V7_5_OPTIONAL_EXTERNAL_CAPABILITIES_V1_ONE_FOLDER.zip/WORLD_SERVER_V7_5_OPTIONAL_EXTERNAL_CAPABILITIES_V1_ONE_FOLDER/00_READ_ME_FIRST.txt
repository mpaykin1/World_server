WORLD_SERVER V7.5 OPTIONAL EXTERNAL CAPABILITIES V1 — ONE FOLDER

1. Open 00_START_HERE.md
2. Desktop AI must follow 00_DESKTOP_AI_INSTALL_AND_VERIFY.md exactly.
3. Do not merge master until required gates and the real 8h long-soak pass.
4. Android / iOS / remote-CAS remain checked but are OPTIONAL and do not block mergeSafe.
5. Never fake PASS or disable verification.

Everything needed for this patch is in this one folder.
