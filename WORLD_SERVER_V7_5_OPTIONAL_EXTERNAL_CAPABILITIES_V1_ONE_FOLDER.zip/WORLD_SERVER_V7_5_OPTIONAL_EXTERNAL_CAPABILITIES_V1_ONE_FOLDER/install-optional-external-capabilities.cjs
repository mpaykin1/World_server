#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PATCH = 'WORLD_SERVER_V7_5_OPTIONAL_EXTERNAL_CAPABILITIES_V1';
const VERSION = '1.0.0';
const OPTIONAL = ['fresh-android-device', 'fresh-ios-device', 'remote-cas-peer'];
const CORE_MUST_REMAIN_REQUIRED = [
  'toolchain-bootstrap',
  'tlc',
  'wasmtime',
  'native-cosign',
  'etw-ebpf-perf',
  'fenced-migration',
  '8h-long-soak',
  'vercel-deployment',
  'local-gates',
  'durable-scheduler'
];

function now() { return new Date().toISOString(); }
function stamp() { return new Date().toISOString().replace(/[:.]/g, '-'); }
function exists(p) { try { fs.accessSync(p); return true; } catch { return false; } }
function ensureDir(p) { fs.mkdirSync(p, { recursive: true }); }
function readJson(p) { return JSON.parse(fs.readFileSync(p, 'utf8')); }
function writeJsonAtomic(p, obj) {
  ensureDir(path.dirname(p));
  const tmp = `${p}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2) + '\n', 'utf8');
  fs.renameSync(tmp, p);
}
function sha256File(p) {
  return crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
}
function discoverRoot(start) {
  let cur = path.resolve(start || process.cwd());
  for (let i = 0; i < 8; i++) {
    if (exists(path.join(cur, 'package.json')) && exists(path.join(cur, 'data'))) return cur;
    const next = path.dirname(cur);
    if (next === cur) break;
    cur = next;
  }
  throw new Error(`World_server root not found from ${start || process.cwd()}`);
}
function uniq(xs) { return [...new Set(xs)]; }

function transformPolicy(policy) {
  if (!policy || typeof policy !== 'object') throw new Error('Policy must be an object');
  if (!policy.merge || !Array.isArray(policy.merge.requiredBlockers)) {
    throw new Error('Expected merge.requiredBlockers array');
  }

  const beforeRequired = [...policy.merge.requiredBlockers];
  const required = beforeRequired.filter(id => !OPTIONAL.includes(id));
  const existingOptional = Array.isArray(policy.merge.optionalCapabilities)
    ? policy.merge.optionalCapabilities
    : [];

  const next = JSON.parse(JSON.stringify(policy));
  next.merge.requiredBlockers = uniq(required);
  next.merge.optionalCapabilities = uniq([...existingOptional, ...OPTIONAL]);
  next.merge.optionalCapabilitiesBlockMerge = false;
  next.merge.optionalCapabilityPolicy = 'external-capabilities-v1';
  next.merge.optionalCapabilityPolicyUpdatedAt = now();
  return { next, beforeRequired };
}

function validatePolicy(policy) {
  const errors = [];
  const req = policy?.merge?.requiredBlockers;
  const opt = policy?.merge?.optionalCapabilities;
  if (!Array.isArray(req)) errors.push('merge.requiredBlockers missing');
  if (!Array.isArray(opt)) errors.push('merge.optionalCapabilities missing');
  if (Array.isArray(req)) {
    for (const id of OPTIONAL) if (req.includes(id)) errors.push(`${id} is still required`);
    for (const id of CORE_MUST_REMAIN_REQUIRED) if (!req.includes(id)) errors.push(`core blocker lost: ${id}`);
  }
  if (Array.isArray(opt)) for (const id of OPTIONAL) if (!opt.includes(id)) errors.push(`${id} missing from optionalCapabilities`);
  if (policy?.merge?.optionalCapabilitiesBlockMerge !== false) errors.push('optionalCapabilitiesBlockMerge must be false');
  return errors;
}

function selfTest() {
  const sample = {
    merge: {
      requiredBlockers: [
        'toolchain-bootstrap','tlc','wasmtime','native-cosign','etw-ebpf-perf',
        'fresh-android-device','fresh-ios-device','remote-cas-peer','fenced-migration',
        '8h-long-soak','vercel-deployment','local-gates','durable-scheduler','future-critical-blocker'
      ],
      optionalCapabilities: ['existing-optional']
    }
  };
  const { next } = transformPolicy(sample);
  const errors = validatePolicy(next);
  if (errors.length) throw new Error(`self-test policy validation failed: ${errors.join('; ')}`);
  if (!next.merge.requiredBlockers.includes('future-critical-blocker')) throw new Error('self-test lost future required blocker');
  if (!next.merge.optionalCapabilities.includes('existing-optional')) throw new Error('self-test lost existing optional capability');
  if (next.merge.requiredBlockers.some(id => OPTIONAL.includes(id))) throw new Error('self-test optional blocker remained required');
  return { pass: true, tests: 4 };
}

function main() {
  if (process.argv.includes('--self-test')) {
    console.log(JSON.stringify(selfTest(), null, 2));
    return;
  }

  selfTest();
  const root = discoverRoot(process.cwd());
  const policyPath = path.join(root, 'data', 'blocker-repair-policy.json');
  const enginePath = path.join(root, 'scripts', 'autonomous-blocker-repair.cjs');
  if (!exists(policyPath)) throw new Error(`Missing ${policyPath}. Install blocker-repair V1 first.`);
  if (!exists(enginePath)) throw new Error(`Missing ${enginePath}. Install blocker-repair V1 first.`);
  const engineSource = fs.readFileSync(enginePath, 'utf8');
  if (!engineSource.includes('computeMergeSafe') || !engineSource.includes('policy.merge.requiredBlockers')) {
    throw new Error('Blocker-repair engine no longer computes mergeSafe from policy.merge.requiredBlockers; refusing a policy-only migration.');
  }

  const policy = readJson(policyPath);
  const beforeSha = sha256File(policyPath);
  const { next, beforeRequired } = transformPolicy(policy);
  const validationErrors = validatePolicy(next);
  if (validationErrors.length) throw new Error(`Refusing unsafe migration: ${validationErrors.join('; ')}`);

  const backupDir = path.join(root, '.blocker-repair-backups', `optional-capabilities-v1-${stamp()}`);
  const backupPath = path.join(backupDir, 'data', 'blocker-repair-policy.json');
  ensureDir(path.dirname(backupPath));
  fs.copyFileSync(policyPath, backupPath);

  try {
    writeJsonAtomic(policyPath, next);
    const reread = readJson(policyPath);
    const afterErrors = validatePolicy(reread);
    if (afterErrors.length) throw new Error(`Post-write validation failed: ${afterErrors.join('; ')}`);

    const stateDir = path.join(root, 'state', 'blocker-repair');
    ensureDir(stateDir);
    const reportPath = path.join(stateDir, 'OPTIONAL_CAPABILITIES_POLICY_REPORT.json');
    const report = {
      patch: PATCH,
      version: VERSION,
      pass: true,
      installedAt: now(),
      root,
      policyPath: path.relative(root, policyPath),
      backupPath: path.relative(root, backupPath),
      sha256Before: beforeSha,
      sha256After: sha256File(policyPath),
      beforeRequiredBlockers: beforeRequired,
      afterRequiredBlockers: reread.merge.requiredBlockers,
      optionalCapabilities: reread.merge.optionalCapabilities,
      optionalCapabilitiesBlockMerge: reread.merge.optionalCapabilitiesBlockMerge,
      removedFromRequired: OPTIONAL.filter(id => beforeRequired.includes(id)),
      preservedUnknownRequired: beforeRequired.filter(id => !OPTIONAL.includes(id) && !CORE_MUST_REMAIN_REQUIRED.includes(id)),
      nextAction: 'Run npm run blockers:tick, then npm run blockers:status. Optional capability waiting states remain honest but no longer block mergeSafe.'
    };
    writeJsonAtomic(reportPath, report);
    console.log(JSON.stringify(report, null, 2));
  } catch (e) {
    fs.copyFileSync(backupPath, policyPath);
    throw e;
  }
}

try { main(); }
catch (e) {
  console.error(`[${PATCH}] FAIL: ${e.stack || e}`);
  process.exitCode = 1;
}
