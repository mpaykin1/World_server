# Инструкция Desktop AI

1. Работать в текущей рабочей ветке. Не переключаться на `master` и не merge.
2. Запустить `node install-optional-external-capabilities.cjs` из корня World_server.
3. Проверить отчёт `state/blocker-repair/OPTIONAL_CAPABILITIES_POLICY_REPORT.json`.
4. Убедиться, что в `data/blocker-repair-policy.json`:
   - `fresh-android-device`, `fresh-ios-device`, `remote-cas-peer` отсутствуют в `merge.requiredBlockers`;
   - эти три ID присутствуют в `merge.optionalCapabilities`;
   - `merge.optionalCapabilitiesBlockMerge === false`.
5. Запустить `npm run blockers:tick`, затем `npm run blockers:status`.
6. Не подделывать PASS для внешних capability. Они могут оставаться `waiting`.
7. Не ослаблять остальные required blockers, `local-gates`, Vercel и 8h soak.
8. Если возникает ошибка: найти root cause -> сделать минимальный безопасный фикс -> regression test -> снова `blockers:tick` -> повторять до устранения локально исправимых ошибок.
9. Не использовать `SYSTEM_INTEGRATION_SKIP_FULL_VERIFY=1` для доказательства готовности.
10. Merge разрешён только при честном `mergeSafe:true` после завершения обязательных проверок.
