# WORLD_SERVER V7.5 — Optional External Capabilities V1

Цель: Android, iOS и remote-CAS остаются честно проверяемыми возможностями, но отсутствие этих внешних ресурсов больше не блокирует `mergeSafe`.

## Что меняется

Только merge-policy в `data/blocker-repair-policy.json`:

- `fresh-android-device` -> optional capability;
- `fresh-ios-device` -> optional capability;
- `remote-cas-peer` -> optional capability.

Они **не получают фиктивный PASS**. Их статусы `waiting` / `pass` продолжают сохраняться и таймеры продолжают их перепроверять.

Остаются обязательными, в частности: локальные gates, Vercel deployment, toolchain/TLC/Wasmtime/cosign/performance evidence, fenced migration, durable scheduler и реальный 8h long-soak.

## Установка Desktop AI

```powershell
cd C:\Users\user\Desktop\World_server
node "<ПАПКА_ПАТЧА>\install-optional-external-capabilities.cjs"
npm run blockers:tick
npm run blockers:status
```

`mergeSafe:true` допустим только если все оставшиеся required blockers и gates реально PASS.
