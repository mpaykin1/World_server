# Design / Safety

Патч не заменяет blocker-repair engine и не перезаписывает его код. Это специально: локальная версия engine могла уже получить исправления Desktop AI.

Installer выполняет точечную policy-migration:

- читает существующий `data/blocker-repair-policy.json`;
- делает timestamped backup;
- удаляет из `requiredBlockers` **только** три заранее разрешённых внешних ID;
- сохраняет любые другие текущие и будущие required blockers;
- добавляет те же ID в `optionalCapabilities`;
- запрещает optional capabilities блокировать merge;
- проверяет, что ключевые core blockers не были случайно потеряны;
- пишет машинный отчёт.

Проверки Android/iOS/CAS не выключаются. Меняется только роль их результата в production merge policy.
