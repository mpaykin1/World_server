# OPEN SOURCE — V27

Новых зависимостей не добавлено: свежий bottleneck — CAS snapshot/control-plane, а не отсутствие графического инструмента.

Новый OSS добавлять только:
reuse check → license verify → compatibility → isolated benchmark → real runtime/visual evidence → tournament → winner-only promotion.
