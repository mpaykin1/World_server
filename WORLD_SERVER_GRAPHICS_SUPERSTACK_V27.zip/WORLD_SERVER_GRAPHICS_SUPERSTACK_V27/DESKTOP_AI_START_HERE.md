# WORLD_SERVER_GRAPHICS_SUPERSTACK_V27 — DESKTOP AI

## Свежий blocker
В `checkpoint/desktop-ai-20260828-091133` control-plane snapshot падает:
`EBUSY ... state/blocker-repair/unified.lock`.

Root cause: CAS snapshot хэширует живой runtime synchronization lock как стабильный project artifact.

## Установка
Только текущая Desktop AI ветка/worktree, НЕ master:
```powershell
powershell -ExecutionPolicy Bypass -File .\INSTALL_V27.ps1
```

Installer не перезаписывает существующие V27 helper/test файлы и не меняет `scripts/cas-merkle-store.cjs`.
Он создаёт staged candidate только если target совпадает с проверенным checkpoint Git blob SHA.

`SOURCE_CHANGED_OR_OTHER_AI_ALREADY_PATCHED` = HOLD. Не перетирать работу другого ИИ.

## Проверка
```powershell
node --test test\cas-snapshot-lock-v27.test.cjs
```

После review diff перенести из `.quality-generated\v27-safe-port`:
- `cas-merkle-store.cjs`
- `cas-snapshot-file-policy-v27.cjs`

Исправление:
- пропускать только `EBUSY/EPERM/EAGAIN` внутри `state/`;
- каждый пропуск писать в `CAS_INDEX.json.transientExcluded`;
- `Cargo.lock`, source/assets и non-state файлы не исключать;
- остальные ошибки не маскировать.

## Root-cause verification
```powershell
node scripts\cas-merkle-store.cjs snapshot v27-lock-fix
```
Если lock занят, snapshot должен завершиться, а lock попасть в `transientExcluded`.

Затем перезапустить существующий control-plane/system integration gate.
Исправление не считается закрытым, пока requiredFailures содержит `snapshot`.

## Регрессионная защита
```powershell
npm run quality:root-cause
npm run quality:generate-tests
npm run quality:learn-fix
npm run quality:tournament
```
Сохранить правило:
`CAS snapshot must tolerate actively locked transient runtime-state files without hiding source/asset errors.`

## Graphics runtime
Свежий checkpoint уже честно оставляет Depth, Blender, Godot, InstantMesh, TRELLIS, Hunyuan3D runtime-unverified.
Не повышать проценты по наличию адаптеров.

CPU-first mandatory:
1. Depth Anything Small CPU — real image → finite depth artifact.
2. Blender — real headless export → GLB validator.
3. Godot — real headless fixture.

## Device / visual
После control-plane:
```powershell
npm run quality:real-devices
npm run quality:visual-critic
npm run quality:perceptual
npm run quality:world:evidence
```

## Финал
```powershell
node scripts\graphics-v27-readiness.cjs
npm run quality:world
npm run release:gate
```

Не ухудшать geometry/textures/materials/lighting/shadows/animation/effects ради FPS или теста.
