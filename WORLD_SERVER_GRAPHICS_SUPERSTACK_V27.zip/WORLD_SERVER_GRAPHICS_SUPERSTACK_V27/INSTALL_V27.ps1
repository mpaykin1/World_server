param([string]$Repo="C:\Users\user\Desktop\World_server")
$ErrorActionPreference="Stop"
Set-Location $Repo
node "$PSScriptRoot\SELF_TEST.cjs"
$files=@(
 "cas-snapshot-file-policy-v27.cjs",
 "cas-merkle-store-v27-patcher.cjs",
 "graphics-v27-safe-port.cjs",
 "graphics-v27-readiness.cjs"
)
foreach($f in $files){
 $dst=Join-Path ".\scripts" $f
 if(Test-Path $dst){Write-Host "HOLD existing $dst"; continue}
 Copy-Item (Join-Path "$PSScriptRoot\scripts" $f) $dst
}
$tdst=".\test\cas-snapshot-lock-v27.test.cjs"
if(!(Test-Path $tdst)){Copy-Item "$PSScriptRoot\test\cas-snapshot-lock-v27.test.cjs" $tdst}else{Write-Host "HOLD existing $tdst"}
node .\scripts\graphics-v27-safe-port.cjs
node --test .\test\cas-snapshot-lock-v27.test.cjs
Write-Host "V27 staged. Review .quality-generated\v27-safe-port before replacing live CAS files."
