#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path');

function apply(source){
 if(source.includes("shouldSkipTransientReadError"))return source;
 if(!/const\s+hash\s*=\s*shaFile\(abs\);/.test(source))throw new Error('TARGET_PATTERN_MISSING');

 source=source.replace(
   "} = require('./integration-utils.cjs');",
   "} = require('./integration-utils.cjs');\nconst { shouldSkipTransientReadError } = require('./cas-snapshot-file-policy-v27.cjs');"
 );

 source=source.replace(
   /(\s*)const\s+entries\s*=\s*\[\];/,
   "$1const entries = [];$1const transientExcluded = [];"
 );

 source=source.replace(
   /(\s*)const\s+hash\s*=\s*shaFile\(abs\);\s*\n\s*if\s*\(store\)\s*storeObject\(abs,\s*hash\);/,
`$1let hash;
$1try {
$1  hash = shaFile(abs);
$1} catch (err) {
$1  if (shouldSkipTransientReadError(rel, err)) {
$1    transientExcluded.push({ path: rel, code: err.code || 'UNKNOWN' });
$1    continue;
$1  }
$1  throw err;
$1}
$1if (store) storeObject(abs, hash);`
 );

 source=source.replace(
   /const out = \{ schemaVersion: '2\.0\.0', generatedAt: nowIso\(\), algorithm: 'sha256-merkle-v1', root, files: entries\.length, bytes: entries\.reduce\(\(n,e\)=>n\+e\.bytes,0\), entries \};/,
   "const out = { schemaVersion: '2.1.0', generatedAt: nowIso(), algorithm: 'sha256-merkle-v1', root, files: entries.length, bytes: entries.reduce((n,e)=>n+e.bytes,0), transientExcluded, entries };"
 );

 if(!source.includes('transientExcluded.push'))throw new Error('HASH_BLOCK_PATCH_FAILED');
 if(!source.includes("schemaVersion: '2.1.0'"))throw new Error('OUTPUT_PATCH_FAILED');
 return source;
}
module.exports={apply};

if(require.main===module){
 const input=process.argv[2],output=process.argv[3];
 if(!input||!output)throw new Error('usage: cas-merkle-store-v27-patcher.cjs <input> <output>');
 fs.writeFileSync(path.resolve(output),apply(fs.readFileSync(path.resolve(input),'utf8')));
 console.log('[CAS_V27_PATCHER] PASS');
}
