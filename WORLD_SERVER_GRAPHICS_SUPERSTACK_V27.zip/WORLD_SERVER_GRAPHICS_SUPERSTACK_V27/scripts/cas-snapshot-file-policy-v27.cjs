'use strict';
function isRuntimeState(rel=''){return String(rel).replaceAll('\\','/').startsWith('state/')}
function shouldSkipTransientReadError(rel,err){
 if(!isRuntimeState(rel))return false;
 return ['EBUSY','EPERM','EAGAIN'].includes(String(err?.code||'').toUpperCase());
}
module.exports={isRuntimeState,shouldSkipTransientReadError};
