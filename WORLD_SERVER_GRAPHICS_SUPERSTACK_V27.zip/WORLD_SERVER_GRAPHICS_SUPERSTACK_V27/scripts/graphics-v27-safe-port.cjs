#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const ROOT=process.cwd(),target=path.join(ROOT,'scripts','cas-merkle-store.cjs');
const report={generatedAt:new Date().toISOString(),expectedGitBlobSha:'95fdcff5265e89b701c88a363a6ff52a66eaf24e',status:'HOLD'};
function blob(p){const b=fs.readFileSync(p);return crypto.createHash('sha1').update(Buffer.concat([Buffer.from(`blob ${b.length}\0`),b])).digest('hex')}
if(!fs.existsSync(target))report.reason='TARGET_MISSING';
else{
 const observed=blob(target);report.observedGitBlobSha=observed;
 if(observed!=='95fdcff5265e89b701c88a363a6ff52a66eaf24e')report.reason='SOURCE_CHANGED_OR_OTHER_AI_ALREADY_PATCHED';
 else{
  const patcher=require('./cas-merkle-store-v27-patcher.cjs');
  const out=patcher.apply(fs.readFileSync(target,'utf8'));
  const d=path.join(ROOT,'.quality-generated','v27-safe-port');fs.mkdirSync(d,{recursive:true});
  fs.writeFileSync(path.join(d,'cas-merkle-store.cjs'),out);
  fs.copyFileSync(path.join(__dirname,'cas-snapshot-file-policy-v27.cjs'),path.join(d,'cas-snapshot-file-policy-v27.cjs'));
  report.status='STAGED_CANDIDATE';report.stagedDir='.quality-generated/v27-safe-port';
 }
}
fs.writeFileSync('GRAPHICS_V27_SAFE_PORT_REPORT.json',JSON.stringify(report,null,2)+'\n');
console.log(`[GRAPHICS_V27_SAFE_PORT] ${report.status} ${report.reason||''}`);
process.exitCode=report.status==='STAGED_CANDIDATE'?0:46;
