#!/usr/bin/env node
'use strict';
const fs=require('fs');
let staged={};try{staged=JSON.parse(fs.readFileSync('GRAPHICS_V27_SAFE_PORT_REPORT.json','utf8'))}catch{}
const software=100,runtime=0,evidence=0,blockerFix=staged.status==='STAGED_CANDIDATE'?100:0;
const production=Math.round(software*.20+runtime*.35+evidence*.30+blockerFix*.15);
const out={generatedAt:new Date().toISOString(),softwarePercent:software,runtimePercent:runtime,evidencePercent:evidence,blockerFixPreparedPercent:blockerFix,productionReadinessPercent:production,production100:false,holds:[
 'APPLY_STAGED_CAS_FIX_IN_ACTIVE_DESKTOP_WORKTREE',
 'RERUN_CONTROL_PLANE_SNAPSHOT',
 'DEPTH_BLENDER_GODOT_REAL_RUNTIME_REQUIRED',
 'REAL_BROWSER_DEVICE_VISUAL_EVIDENCE_REQUIRED'
]};
fs.writeFileSync('GRAPHICS_V27_READINESS.json',JSON.stringify(out,null,2)+'\n');
console.log(`[GRAPHICS_V27_READINESS] software=${software} runtime=${runtime} evidence=${evidence} production=${production}`);
