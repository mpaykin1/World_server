#!/usr/bin/env node
'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {shouldSkipTransientReadError}=require('../scripts/cas-snapshot-file-policy-v27.cjs');
const {apply}=require('../scripts/cas-merkle-store-v27-patcher.cjs');

test('only transient runtime-state read errors are skippable',()=>{
 assert.equal(shouldSkipTransientReadError('state/blocker-repair/unified.lock',{code:'EBUSY'}),true);
 assert.equal(shouldSkipTransientReadError('state/blocker-repair/repair.lock',{code:'EPERM'}),true);
 assert.equal(shouldSkipTransientReadError('state/x/a.lock',{code:'EAGAIN'}),true);
 assert.equal(shouldSkipTransientReadError('Cargo.lock',{code:'EBUSY'}),false);
 assert.equal(shouldSkipTransientReadError('scripts/a.js',{code:'EBUSY'}),false);
 assert.equal(shouldSkipTransientReadError('state/x/file.json',{code:'ENOENT'}),false);
});

test('patch records exclusions and rethrows non-transient failures',()=>{
 const src=`const {
 ROOT, STATE_DIR, norm, ensureDir, shaBuffer, shaFile, readJSON, writeJSON, projectFiles, nowIso, safeLabel
} = require('./integration-utils.cjs');
function buildIndex({ store = true } = {}) {
 const files=projectFiles();
 const entries = [];
 for (const rel of files) {
  const abs=path.join(ROOT,rel);
  const st=fs.statSync(abs);
  const hash = shaFile(abs);
  if (store) storeObject(abs, hash);
  entries.push({path:rel,bytes:st.size,sha256:hash});
 }
 const root='x';
 const out = { schemaVersion: '2.0.0', generatedAt: nowIso(), algorithm: 'sha256-merkle-v1', root, files: entries.length, bytes: entries.reduce((n,e)=>n+e.bytes,0), entries };
}`;
 const out=apply(src);
 assert.match(out,/transientExcluded/);
 assert.match(out,/continue;/);
 assert.match(out,/throw err;/);
 assert.match(out,/schemaVersion: '2\.1\.0'/);
});
