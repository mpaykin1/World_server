#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process');let fail=0;
for(const d of ['scripts','test'])for(const f of fs.readdirSync(path.join(__dirname,d))){
 if(!/\.(js|cjs)$/.test(f))continue;
 const r=cp.spawnSync(process.execPath,['--check',path.join(__dirname,d,f)],{encoding:'utf8'});
 if(r.status!==0){console.error(f,r.stderr);fail++}
}
const t=cp.spawnSync(process.execPath,['--test',path.join(__dirname,'test','cas-snapshot-lock-v27.test.cjs')],{cwd:__dirname,encoding:'utf8'});
if(t.status!==0){console.error(t.stdout,t.stderr);fail++}
console.log(fail?'[SELF_TEST] FAIL':'[SELF_TEST] PASS');process.exitCode=fail?1:0;
