# ИНСТРУКЦИЯ ДЛЯ DESKTOP AI

Цель: безопасно внедрить production-quality evidence guard в существующий World_server, не мешая параллельной работе других ИИ.

## 1. Предварительная проверка
1. Репозиторий: `C:\Users\user\Desktop\World_server`.
2. Выполни `git status --short`.
3. Проверь, не редактирует ли другой ИИ одновременно:
   - `.github/workflows/production-quality-feedback.yml`
   - `scripts/production-quality-pull.js`
   - `test/production-quality-evidence.test.js`
4. Если эти конкретные файлы сейчас активно меняются другим ИИ — НЕ перезаписывай их. Сравни изменения, перенеси только инварианты патча вручную и сохрани лучшее из обоих решений.
5. Не трогай остальные файлы и worktree.

## 2. Установка
Запусти из PowerShell:
`powershell -ExecutionPolicy Bypass -File .\install.ps1`

Скрипт:
- создаёт backup;
- заменяет только 3 целевых файла;
- запускает focused regression tests;
- запускает `npm run check`;
- показывает ограниченный diff.

## 3. Обязательные инварианты
После любого merge/refactor должны оставаться:
- `production-quality-pull.js` создаёт `PRODUCTION_QUALITY_REPORT.json` при product regression И при monitor failure;
- создаётся `PRODUCTION_QUALITY_ISSUE.md`;
- workflow содержит `actions/upload-artifact@v4`;
- upload evidence выполняется с `if: always()`;
- `if-no-files-found: error`;
- issue создаётся/обновляется из evidence-файла через `--body-file`;
- `monitor_failure` и `product_regression` имеют разные blocker titles;
- baseline нельзя автоматически ослаблять для прохождения gate.

## 4. Проверка
Выполнять до PASS:
`node --test test/production-quality-evidence.test.js`
`npm run check`
`npm run quality:production`

Важно: последний вызов проверяет реальный production и МОЖЕТ законно завершиться ненулевым кодом, если production действительно нарушает budget. Это не означает, что patch сломан. В этом случае обязательно должны существовать:
- `PRODUCTION_QUALITY_REPORT.json`
- `PRODUCTION_QUALITY_ISSUE.md`
и `classification` должна объяснить, это product regression или monitor failure.

## 5. GitHub Actions
После push/PR:
1. Запусти workflow `Production Quality Feedback` вручную.
2. Даже при failure проверь наличие artifact `production-quality-evidence-<run>-<attempt>`.
3. Открой artifact: JSON и Markdown должны присутствовать.
4. Если gate упал:
   - `product_regression` => чинить FPS/load/runtime errors продукта;
   - `monitor_failure` => чинить endpoint/network/JSON/monitor code, не менять quality baseline.
5. Blocker issue должен содержать таблицу конкретных violations и ссылку на workflow run.

## 6. Если тест упал
Не обходить и не удалять тест.
- выяснить первопричину;
- исправить её;
- повторять focused test + `npm run check` до PASS;
- если новый конфликт возник из-за параллельного PR, объединить лучшие инварианты, а не откатывать чужую полезную работу.

## 7. Что скачать
Ничего. Патч использует только Node 24, GitHub Actions и `actions/upload-artifact@v4`, уже совместимые с текущим стеком. Новую дублирующую систему качества не устанавливать.

## 8. Сохранение знания
После успешного production run зафиксировать в существующей системе качества:
root cause: production evidence was generated locally but discarded by workflow on failure;
guard: always-upload evidence + exact issue body + monitor/product classification + regression tests.
Если в репозитории уже есть knowledge/regression ledger — использовать его, новый ledger не создавать.

## 9. Commit
Коммитить только после PASS focused test и `npm run check`.
Не включать несвязанные изменения других ИИ в тот же commit.
