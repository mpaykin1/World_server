# World_server Production Quality Evidence Patch v1

Исправляет первопричину потери production evidence.

Что меняется:
- `production-quality-pull.js` гарантированно пишет JSON + Markdown evidence даже при fetch/timeout/invalid JSON/internal monitor failure.
- Ошибки классифицируются как `product_regression` или `monitor_failure`.
- GitHub Actions загружает evidence с `if: always()`.
- Blocker issue получает конкретные нарушения через `--body-file`, а не одинаковую общую фразу.
- Добавлен regression-test на artifact guard, product regression и network monitor failure.
- Никакие системы графики/multiplayer/Navigator этим патчем не заменяются и не дублируются.

Установка: см. `INSTALL_DESKTOP_AI.md`.
