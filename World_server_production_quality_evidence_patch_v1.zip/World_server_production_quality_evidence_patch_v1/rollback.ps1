param(
  [Parameter(Mandatory=$true)][string]$Backup,
  [string]$Repo = "C:\Users\user\Desktop\World_server"
)
$ErrorActionPreference = "Stop"
$targets = @(
  ".github/workflows/production-quality-feedback.yml",
  "scripts/production-quality-pull.js",
  "test/production-quality-evidence.test.js"
)
foreach ($rel in $targets) {
  $src = Join-Path $Backup $rel
  $dst = Join-Path $Repo $rel
  if (Test-Path $src) {
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
    Copy-Item $src $dst -Force
  } elseif ($rel -eq "test/production-quality-evidence.test.js" -and (Test-Path $dst)) {
    Remove-Item $dst -Force
  }
}
Write-Host "Rollback complete."
