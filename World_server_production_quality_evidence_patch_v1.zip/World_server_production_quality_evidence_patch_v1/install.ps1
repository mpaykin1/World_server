param(
  [string]$Repo = "C:\Users\user\Desktop\World_server"
)
$ErrorActionPreference = "Stop"

$PatchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Payload = Join-Path $PatchRoot "payload"

if (!(Test-Path (Join-Path $Repo ".git"))) {
  throw "World_server repository not found: $Repo"
}

Set-Location $Repo

Write-Host "1/6 Checking repository state..."
git status --short
if ($LASTEXITCODE -ne 0) { throw "git status failed" }

$targets = @(
  ".github/workflows/production-quality-feedback.yml",
  "scripts/production-quality-pull.js",
  "test/production-quality-evidence.test.js"
)

$backup = Join-Path $PatchRoot ("backup-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
New-Item -ItemType Directory -Force -Path $backup | Out-Null

Write-Host "2/6 Backing up existing target files..."
foreach ($rel in $targets) {
  $dst = Join-Path $Repo $rel
  if (Test-Path $dst) {
    $bak = Join-Path $backup $rel
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $bak) | Out-Null
    Copy-Item $dst $bak -Force
  }
}

Write-Host "3/6 Installing patch without touching unrelated files..."
foreach ($rel in $targets) {
  $src = Join-Path $Payload $rel
  $dst = Join-Path $Repo $rel
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
  Copy-Item $src $dst -Force
}

Write-Host "4/6 Running focused regression tests..."
node --test test/production-quality-evidence.test.js
if ($LASTEXITCODE -ne 0) {
  throw "Focused regression tests failed. Restore from $backup and investigate before commit."
}

Write-Host "5/6 Running repository JS/test gate..."
npm run check
if ($LASTEXITCODE -ne 0) {
  throw "npm run check failed. Do not commit until the pre-existing/new failure is classified and fixed."
}

Write-Host "6/6 Showing only patch diff..."
git diff -- .github/workflows/production-quality-feedback.yml scripts/production-quality-pull.js test/production-quality-evidence.test.js

Write-Host ""
Write-Host "PATCH INSTALLED AND TESTED."
Write-Host "Backup: $backup"
Write-Host "Next: review diff, then commit only these three paths if no other AI is editing them."
