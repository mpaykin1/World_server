# WORLD_SERVER V7.5 — Autonomous Blocker Repair V1

## What this patch adds

One production repair layer **on top of V7.5**. It does not replace the existing control plane, toolchain bootstrap, quality gates, or long-soak harness.

Flow:

`DETECT → CLASSIFY → SAFE REPAIR → WAIT/TIMER if needed → VERIFY → ROOT-CAUSE task for Desktop AI if code change is required → RETRY`

### Automatic deterministic repairs

- reuses `scripts/toolchain-bootstrap.cjs` for existing free toolchain resources;
- verified free `cosign` download from official GitHub release assets only when needed;
- checks real ETW/WPR capability on Windows;
- detects physical Android devices; emulators do **not** count;
- detects physical iOS only through real device tooling; simulator/fake evidence is forbidden;
- probes configured remote CAS and refuses localhost as remote evidence;
- discovers/runs existing fenced-migration verifier;
- starts and polls the existing real 8-hour `long-soak-runner.cjs`;
- checks GitHub commit status for Vercel and captures `vercel inspect ... --logs` on failure;
- runs full gates without `SYSTEM_INTEGRATION_SKIP_FULL_VERIFY`;
- stores timers and repair state durably in `state/blocker-repair/`.

### Timers / wait-resume

The installer first tries to **reuse an existing `*autoloop*.ps1`** and injects one idempotent managed hook.  
If none is found on Windows, it creates one current-user Task Scheduler task every 15 minutes.

All waiting blockers have `nextRunAt` in `state/blocker-repair/state.json`. A restart does not lose the timer state.

## Installation

From the unpacked patch folder, with `C:\Users\user\Desktop\World_server` available:

```powershell
cd C:\Users\user\Desktop\World_server
node "<PATCH_FOLDER>\install-autonomous-blocker-repair.cjs"
```

The installer:
1. verifies `PATCH_MANIFEST.json`;
2. backs up every touched target file under `.blocker-repair-backups/`;
3. copies the two payload files;
4. adds npm commands idempotently;
5. appends the Desktop AI master instruction if that file exists;
6. runs offline self-test;
7. reuses the existing autoloop or creates the Windows scheduler fallback.

Then run:

```powershell
npm run blockers:tick
```

## Main commands

```powershell
npm run blockers:tick
npm run blockers:status
npm run blockers:self-test
npm run blockers:loop
npm run blockers:scheduler:install
npm run blockers:scheduler:remove
```

## PASS rule

Do **not** merge merely because the patch installed.

Merge is allowed only when:

- `npm run blockers:status` says `mergeSafe: true`;
- local gates are PASS;
- Vercel is PASS;
- long soak is genuinely certified;
- required real-device / remote evidence is genuinely present;
- no `requires_ai` blocker remains.

No fake 100%, no shortened production soak, no synthetic device evidence, no SKIP_FULL_VERIFY.
