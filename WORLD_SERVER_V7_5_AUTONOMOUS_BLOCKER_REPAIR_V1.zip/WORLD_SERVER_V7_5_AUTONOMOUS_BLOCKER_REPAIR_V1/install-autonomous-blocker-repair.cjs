#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const PATCH_VERSION = '1.0.0';
const PATCH_NAME = 'WORLD_SERVER_V7_5_AUTONOMOUS_BLOCKER_REPAIR_V1';

function nowStamp() { return new Date().toISOString().replace(/[:.]/g, '-'); }
function exists(p) { try { fs.accessSync(p); return true; } catch { return false; } }
function ensureDir(p) { fs.mkdirSync(p, { recursive: true }); }
function sha256(p) { const h = crypto.createHash('sha256'); h.update(fs.readFileSync(p)); return h.digest('hex'); }
function atomicWrite(p, text) {
  ensureDir(path.dirname(p));
  const tmp = `${p}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(tmp, text);
  fs.renameSync(tmp, p);
}
function parseArgs(argv) {
  const o = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--root') o.root = argv[++i];
    else if (argv[i] === '--no-scheduler') o.noScheduler = true;
  }
  return o;
}
function run(cmd, args, cwd) {
  const r = spawnSync(cmd, args, { cwd, encoding: 'utf8', windowsHide: true, timeout: 120000, maxBuffer: 8 * 1024 * 1024 });
  return { ok: r.status === 0, code: r.status, stdout: String(r.stdout || ''), stderr: String(r.stderr || '') };
}
function discoverRoot(explicit) {
  if (explicit) return path.resolve(explicit);
  const r = run('git', ['rev-parse', '--show-toplevel'], process.cwd());
  if (r.ok && r.stdout.trim()) return path.resolve(r.stdout.trim());
  return process.cwd();
}
function copyRecursive(src, dst) {
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    ensureDir(dst);
    for (const name of fs.readdirSync(src)) copyRecursive(path.join(src, name), path.join(dst, name));
  } else {
    ensureDir(path.dirname(dst));
    fs.copyFileSync(src, dst);
  }
}
function listFiles(dir, base = dir, out = []) {
  for (const name of fs.readdirSync(dir)) {
    const p = path.join(dir, name);
    const st = fs.statSync(p);
    if (st.isDirectory()) listFiles(p, base, out);
    else out.push(path.relative(base, p).replace(/\\/g, '/'));
  }
  return out;
}
function backupFile(root, backupRoot, rel) {
  const src = path.join(root, rel);
  if (!exists(src)) return;
  const dst = path.join(backupRoot, rel);
  ensureDir(path.dirname(dst));
  fs.copyFileSync(src, dst);
}
function restoreBackup(root, backupRoot, touched) {
  for (const rel of touched) {
    const b = path.join(backupRoot, rel);
    const t = path.join(root, rel);
    if (exists(b)) {
      ensureDir(path.dirname(t));
      fs.copyFileSync(b, t);
    } else {
      try { fs.unlinkSync(t); } catch {}
    }
  }
}
function verifyManifest(packageDir) {
  const manifestPath = path.join(packageDir, 'PATCH_MANIFEST.json');
  const m = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  if (m.patch !== PATCH_NAME || m.version !== PATCH_VERSION) throw new Error('Manifest patch/version mismatch');
  for (const item of m.files) {
    const p = path.join(packageDir, item.path);
    if (!exists(p)) throw new Error(`Manifest file missing: ${item.path}`);
    const got = sha256(p);
    if (got !== item.sha256) throw new Error(`SHA256 mismatch: ${item.path}`);
  }
  return m;
}
function ensurePackageScripts(root) {
  const p = path.join(root, 'package.json');
  const pkg = JSON.parse(fs.readFileSync(p, 'utf8'));
  pkg.scripts = pkg.scripts || {};
  const desired = {
    'blockers:tick': 'node scripts/autonomous-blocker-repair.cjs tick',
    'blockers:loop': 'node scripts/autonomous-blocker-repair.cjs loop',
    'blockers:status': 'node scripts/autonomous-blocker-repair.cjs status',
    'blockers:self-test': 'node scripts/autonomous-blocker-repair.cjs self-test',
    'blockers:scheduler:install': 'node scripts/autonomous-blocker-repair.cjs scheduler-install',
    'blockers:scheduler:remove': 'node scripts/autonomous-blocker-repair.cjs scheduler-remove'
  };
  for (const [name, value] of Object.entries(desired)) {
    if (pkg.scripts[name] && pkg.scripts[name] !== value) {
      throw new Error(`Refusing to overwrite existing package script "${name}": ${pkg.scripts[name]}`);
    }
    pkg.scripts[name] = value;
  }
  atomicWrite(p, JSON.stringify(pkg, null, 2) + '\n');
}
function appendMasterInstruction(root) {
  const p = path.join(root, '00_DESKTOP_AI_MASTER_INSTALL.md');
  if (!exists(p)) return false;
  const marker = '<!-- WORLD_SERVER_BLOCKER_REPAIR_V1 -->';
  const src = fs.readFileSync(p, 'utf8');
  if (src.includes(marker)) return false;
  const block = `

${marker}
## Autonomous blocker repair V1

- Run \`npm run blockers:tick\` after every root-cause fix.
- Read \`state/blocker-repair/DESKTOP_AI_NEXT_ACTION.md\` whenever it exists and continue the repair loop.
- Never use \`SYSTEM_INTEGRATION_SKIP_FULL_VERIFY\`, fake device evidence, shortened production soak, or fabricated PASS.
- Timer/wait states are persisted in \`state/blocker-repair/state.json\`.
- Free resources may be auto-installed only through the verified allowlisted bootstrap/policy.
- Do not merge while \`mergeSafe\` is false.
`;
  atomicWrite(p, src.replace(/\s*$/, '') + block + '\n');
  return true;
}

(function main() {
  const args = parseArgs(process.argv.slice(2));
  const packageDir = __dirname;
  const payload = path.join(packageDir, 'payload');
  const root = discoverRoot(args.root);
  if (!exists(path.join(root, 'package.json'))) throw new Error(`package.json not found in target root: ${root}`);

  const manifest = verifyManifest(packageDir);
  const backupRoot = path.join(root, '.blocker-repair-backups', `v1-${nowStamp()}`);
  ensureDir(backupRoot);

  const payloadFiles = listFiles(payload);
  const touched = [...payloadFiles, 'package.json'];
  if (exists(path.join(root, '00_DESKTOP_AI_MASTER_INSTALL.md'))) touched.push('00_DESKTOP_AI_MASTER_INSTALL.md');
  for (const rel of touched) backupFile(root, backupRoot, rel);

  try {
    copyRecursive(payload, root);
    ensurePackageScripts(root);
    appendMasterInstruction(root);

    const self = run(process.execPath, [path.join(root, 'scripts', 'autonomous-blocker-repair.cjs'), 'self-test'], root);
    if (!self.ok) throw new Error(`Self-test failed:\n${self.stdout}\n${self.stderr}`);

    let scheduler = { skipped: true };
    if (!args.noScheduler) {
      scheduler = run(process.execPath, [path.join(root, 'scripts', 'autonomous-blocker-repair.cjs'), 'scheduler-install'], root);
      if (!scheduler.ok) {
        console.warn('[WARN] Scheduler install was not fully successful. Patch remains installed; Desktop AI must repair durable scheduler.');
        console.warn(scheduler.stdout);
        console.warn(scheduler.stderr);
      }
    }

    const report = {
      patch: PATCH_NAME,
      version: PATCH_VERSION,
      pass: true,
      installedAt: new Date().toISOString(),
      root,
      backupRoot,
      manifestFiles: manifest.files.length,
      payloadFiles: payloadFiles.length,
      selfTest: JSON.parse(self.stdout || '{"pass":false}'),
      scheduler: {
        attempted: !args.noScheduler,
        ok: args.noScheduler ? null : scheduler.ok,
        outputTail: args.noScheduler ? null : (scheduler.stdout + '\n' + scheduler.stderr).trim().split(/\r?\n/).slice(-40).join('\n')
      },
      next: [
        'npm run blockers:tick',
        'If state/blocker-repair/DESKTOP_AI_NEXT_ACTION.md exists: Desktop AI fixes ROOT CAUSE then runs blockers:tick again',
        'Do not merge until npm run blockers:status reports mergeSafe=true'
      ]
    };
    atomicWrite(path.join(root, 'BLOCKER_REPAIR_V1_INSTALL_REPORT.json'), JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify(report, null, 2));
  } catch (e) {
    restoreBackup(root, backupRoot, touched);
    console.error(`[${PATCH_NAME}] INSTALL FAILED; rolled back touched files`);
    throw e;
  }
})();
