# Desktop AI — install, verify, repair until clean

## Goal

Install `WORLD_SERVER_V7_5_AUTONOMOUS_BLOCKER_REPAIR_V1` over the current V7.5 branch without touching `master`, then keep repairing until all locally repairable blockers are green.

## Mandatory procedure

1. Confirm current git branch is **not `master`**.
2. Make sure the working tree is understood; do not delete unrelated user work.
3. Run the patch installer from its unpacked folder:
   `node <PATCH_FOLDER>\install-autonomous-blocker-repair.cjs`
4. Run:
   `npm run blockers:self-test`
5. Run:
   `npm run blockers:tick`
6. Read:
   - `state/blocker-repair/state.json`
   - `state/blocker-repair/latest-gates.json`
   - `state/blocker-repair/DESKTOP_AI_NEXT_ACTION.md` if present
7. For every `requires_ai` blocker:
   - diagnose the **root cause** from the recorded command/output;
   - reuse and strengthen existing systems first;
   - implement the smallest production-safe fix;
   - add or strengthen a regression test;
   - run the relevant focused test;
   - run `npm run blockers:tick` again.
8. Repeat step 7 until there is no `requires_ai` blocker.

## Waiting blockers

If a blocker is `waiting`, **do not fake it**. The scheduler/timer will retry automatically.

Examples:
- Vercel still building → wait until `nextRunAt`, re-check.
- network/free resource temporarily unavailable → wait and retry.
- long soak → leave the real process running; scheduler polls it.
- Android/iOS device missing → keep WAITING until a physical device is actually present.
- remote CAS not configured → keep honest WAITING/EXTERNAL; do not substitute localhost.

## Free resources

The repair engine may download/install only free resources allowed by `data/blocker-repair-policy.json`.

Rules:
- prefer existing `scripts/toolchain-bootstrap.cjs`;
- never use `sudo`;
- never mutate global toolchain if a local install is possible;
- download over HTTPS from allowlisted hosts only;
- require verifiable SHA-256/digest for downloaded native binaries;
- cache resolved version/digest so the successful installation is reusable.

## Vercel P0

If Vercel is failed, the engine captures the deployment ID from GitHub status and tries:

`npx vercel inspect <deployment-id> --logs`

Use those logs to repair the root cause, add regression coverage, commit to the current branch, and rerun:

`npm run blockers:tick`

Never merge while Vercel is failed.

## Long soak

The production soak is **8 hours / 28800 seconds** by policy and uses the existing `scripts/long-soak-runner.cjs`.

Do not shorten it to claim certification.  
If interrupted, restart a real soak; certification must come from existing evidence with `longSoakCertified=true`.

## Never do

- `SYSTEM_INTEGRATION_SKIP_FULL_VERIFY=1`
- fake/stub PASS
- fabricated device evidence
- localhost presented as a remote CAS peer
- mark `longSoakCertified=true` manually
- blind automatic edits based only on a guessed error string
- overwrite existing npm scripts with conflicting meanings
- merge to `master` while `mergeSafe=false`

## Completion report

Return:

1. patch install PASS/FAIL;
2. scheduler mode;
3. `control-plane X/75`;
4. `honest-100 X/76`;
5. `orchestrator-continuity X/8`;
6. full gate PASS/FAIL;
7. Vercel PASS/FAIL;
8. blockers by `pass / waiting / requires_ai / external`;
9. `longSoakCertified`;
10. `mergeSafe`;
11. commit SHA + PR;
12. exact remaining external blockers.

Do not stop at the first failure. Continue `DIAGNOSE → ROOT CAUSE FIX → REGRESSION TEST → TICK → VERIFY` until all repairable failures are gone.
