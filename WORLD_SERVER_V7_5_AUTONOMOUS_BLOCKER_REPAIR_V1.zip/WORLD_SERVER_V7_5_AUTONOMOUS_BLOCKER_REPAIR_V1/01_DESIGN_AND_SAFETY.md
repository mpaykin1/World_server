# Design / safety notes

This patch deliberately separates **repairable machine state** from **arbitrary source-code changes**.

The repair engine may automatically:
- install verified free dependencies;
- configure durable retry execution;
- collect real evidence;
- invoke existing project verifiers;
- retry transient operations;
- start/poll the existing long soak.

The engine must not blindly rewrite application code from an error string. For code failures it writes `state/blocker-repair/DESKTOP_AI_NEXT_ACTION.md` with the exact failed command and output tail. Desktop AI performs the root-cause code fix and the engine then verifies it.

This prevents an infinite "repair" loop from silently corrupting the repository while still keeping the overall workflow autonomous.
