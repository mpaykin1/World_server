# DESKTOP AI — INSTALL / RECONSTRUCT / VERIFY

## Goal
Reconstruct ONE coherent 3D voxel world that visually matches `00_MASTER_REFERENCE.png`.
All helper images describe the SAME scene. They are not alternative designs.

## Priority order
1. `00_MASTER_REFERENCE.png` — immutable visual ground truth.
2. `01_SCENE_ONLY_CROP.png` — geometry/composition ground truth without UI.
3. `08_COMPOSITION_ANCHORS_GUIDE.png` — anchor placement.
4. `02_SHADOW_DETAIL_GEOMETRY_HELPER.png` + `04_GEOMETRY_EDGES.png` — recover hidden block structure.
5. `06_DEPTH_LAYOUT_GUIDE_APPROX.png` — rough depth initialization only.
6. Detail crops + palette + lighting guide — materials, voxel scale, fog, emissive tuning.

## Critical scene structure
- Huge near dark voxel rock/monolith occupies the LEFT side.
- The EYE is embedded into the rock, not pasted on a flat plane.
- Deep irregular voxel valley/terrain fills the middle and foreground.
- Small stepped altar/tower with one warm flame sits FAR RIGHT, much farther away than the eye.
- The world is almost black; geometry becomes readable through grazing reflected light, fog and tiny highlights.
- Volumetric fog / atmospheric perspective is essential.
- Keep the original asymmetry and negative space. Do not center the eye or altar.
- Do not replace the scene with a generic procedural cave/mountain.

## Coordinates in the 1024x915 scene crop
- Eye center ≈ (257, 521)
- Flame center ≈ (759, 455)
Treat these as hard camera-match anchors.

## Reconstruction workflow
1. Create a camera that matches the master image first.
2. Block out only 3 masses: near-left monolith, valley/foreground, far-right altar.
3. Match silhouette and anchor positions before adding detail.
4. Add voxel terracing and broken surfaces at multiple scales.
5. Carve a real recessed eye socket into the left monolith.
6. Tune depth/fog so the altar is clearly farther away than the eye.
7. Add the tiny warm flame and subtle warm volumetric scattering.
8. Add restrained reflected eye light. Avoid global fill light.
9. Only after geometry matches, tune material roughness, micro-variation, fog noise and shadow softness.
10. Preserve performance using chunking/LOD/occlusion rather than simplifying the visible composition.

## Validation loop
Render from the reference camera at 1024x915 and compare automatically:
- anchor error: eye/flame <= 2% of frame dimension;
- silhouette / mass layout: target IoU >= 0.85;
- depth ordering: left monolith near, altar far;
- value histogram and dark-area ratio must stay close to reference;
- final still-image SSIM target >= 0.80 where feasible.
If a test fails: identify the root cause, fix it, rerender, repeat until all gates pass.
Store the failure + root cause + successful fix in the project knowledge/log so the same failure is not reintroduced.

## Important warnings
- `02_SHADOW_DETAIL_GEOMETRY_HELPER.png` is intentionally brighter. Never use it as the final lighting reference.
- `06_DEPTH_LAYOUT_GUIDE_APPROX.png` is NOT true metric depth. Use it only to initialize relative near/far ordering.
- The master image remains the final judge.

## Free/open-source helpers worth using if already compatible
- OpenCV: image comparison, silhouettes, anchor detection.
- ONNX Runtime CPU: lightweight inference/analysis.
- Depth Anything V2 Small / MiDaS Small: optional monocular-depth proposal; compare against the supplied depth-layout guide, do not trust blindly.
- Godot built-in occlusion/LOD/chunking or the project's existing equivalents for runtime performance.

## Definition of done
A scene is not done because it 'looks similar'.
It is done only when:
- same major geometry;
- same camera composition;
- same relative depth;
- same eye/altar placement;
- same darkness/fog/light hierarchy;
- same voxel character;
- automated camera-match regression tests pass.

Do not create duplicate parallel systems if the project already has camera-match, telemetry, LOD, voxel generation, lighting or regression infrastructure. Reuse and strengthen the existing systems.
