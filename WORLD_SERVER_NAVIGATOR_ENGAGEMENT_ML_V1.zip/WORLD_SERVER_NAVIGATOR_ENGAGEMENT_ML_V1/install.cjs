#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const ROOT = process.cwd();
const PATCH = __dirname;
const APPLY = !process.argv.includes('--verify-only');
const VERIFY = process.argv.includes('--verify') || process.argv.includes('--verify-only');

function die(msg){ console.error('[NAV_ML_PATCH] '+msg); process.exit(1); }
function file(p){ return path.join(ROOT,p); }
function read(p){ return fs.readFileSync(file(p),'utf8'); }
function write(p,s){ fs.mkdirSync(path.dirname(file(p)),{recursive:true}); fs.writeFileSync(file(p),s); }
function copy(srcRel,dstRel){ const src=path.join(PATCH,'payload',srcRel); if(!fs.existsSync(src))die('payload missing '+srcRel); fs.mkdirSync(path.dirname(file(dstRel)),{recursive:true}); fs.copyFileSync(src,file(dstRel)); }
function insertOnce(text, marker, insertion, label){ if(text.includes(insertion.trim())) return text; const i=text.indexOf(marker); if(i<0) die(`anchor not found for ${label}: ${marker}`); return text.slice(0,i)+insertion+text.slice(i); }
function replaceOnce(text, from, to, label){ if(text.includes(to)) return text; const i=text.indexOf(from); if(i<0) die(`anchor not found for ${label}`); return text.slice(0,i)+to+text.slice(i+from.length); }
function run(cmd,cwd=ROOT){ console.log('> '+cmd); cp.execSync(cmd,{cwd,stdio:'inherit',shell:true}); }

if (!fs.existsSync(file('package.json')) || !fs.existsSync(file('AGENTS.md'))) die('Run from World_server repository root.');

if (APPLY) {
  const added = [
    'lib/progressive-world.js',
    'apps/improve-world-home/public/navigator-world-loop.js',
    'apps/improve-world-home/public/engagement-policy.json',
    'scripts/engagement-learning-loop.js',
    'test/progressive-world-preview.test.js',
    'test/engagement-learning-loop.test.js'
  ];
  for (const p of added) copy(p,p);

  let world = read('lib/api-handlers/world.js');
  world = insertOnce(world,
    "const { deriveVoxelWorld } = require('../voxel-provisioning');\n",
    "const { buildProgressiveSpec, previewWorldId, deriveProgressiveVoxelWorld } = require('../progressive-world');\n",
    'progressive-world import');
  world = insertOnce(world,
    "async function handleGet(admin, identity, body) {",
`async function handlePreview(admin, identity, body) {
  const step = Math.max(0, Math.min(63, Math.trunc(Number(body.step) || 0)));
  const totalSteps = Math.max(1, Math.min(64, Math.trunc(Number(body.totalSteps) || 31)));
  const journey = body.journey === 'join' ? 'join' : 'create';
  const id = previewWorldId(identity, journey);
  const spec = buildProgressiveSpec({ answers: body.answers || {}, step, totalSteps, journey, sourceTitle: body.sourceTitle || '' });
  const voxelRow = deriveProgressiveVoxelWorld(spec, id, { step, totalSteps });
  const { error } = await admin.from('voxel_worlds').upsert(voxelRow, { onConflict: 'id' });
  if (error) throw error;
  return {
    id,
    playUrl: playUrlFor(id),
    revision: voxelRow.settings.previewRevision,
    detailStage: voxelRow.settings.detailStage,
    detailProgress: voxelRow.settings.detailProgress
  };
}

`, 'handlePreview');
  world = replaceOnce(world,
    "  if (body.action === 'get') return sendJson(res, 200, await handleGet(admin, identity, body));\n  if (body.action === 'generate') return sendJson(res, 200, await handleGenerate(admin, identity, body));",
    "  if (body.action === 'get') return sendJson(res, 200, await handleGet(admin, identity, body));\n  if (body.action === 'preview') return sendJson(res, 200, await handlePreview(admin, identity, body));\n  if (body.action === 'generate') return sendJson(res, 200, await handleGenerate(admin, identity, body));",
    'world action dispatch');
  world = replaceOnce(world,
    "module.exports._private = { newWorldId, playUrlFor, PLAY_BASE_URL, handleGenerate, handleGet, ownerColumns, ownerFilterColumn };",
    "module.exports._private = { newWorldId, playUrlFor, PLAY_BASE_URL, handleGenerate, handlePreview, handleGet, ownerColumns, ownerFilterColumn };",
    'world private exports');
  write('lib/api-handlers/world.js', world);

  let html = read('apps/improve-world-home/public/index.html');
  html = replaceOnce(html,
    '<script src="/app.js"></script></body></html>',
    '<script src="/app.js"></script><script src="/navigator-world-loop.js"></script></body></html>',
    'navigator script include');
  write('apps/improve-world-home/public/index.html', html);

  let client = read('apps/voxel-world/client.js');
  client = replaceOnce(client,
    "let worldTreeDensity=1;\n",
    "let worldTreeDensity=1;\nlet worldDetailStage=31;\nlet worldDetailProgress=1;\n",
    'voxel detail state');
  client = insertOnce(client,
    "function generateChunkData(c,rows=[]){",
`function addProgressiveLandmark(c,bx,bz){
  if(worldDetailStage<2)return;
  const reveal=clamp(worldDetailProgress,.03,1);
  const roll=hash32(c.cx,c.cz,worldSeed+6100);
  const probability=clamp(.015+reveal*.12,.015,.135);
  if(roll<1-probability)return;
  const lx=4+(hash32(c.cx*13,c.cz*7,worldSeed+6111)*8|0),lz=4+(hash32(c.cx*5,c.cz*17,worldSeed+6123)*8|0);
  const x=bx+lx,z=bz+lz,h=heightAt(x,z);if(h<=SEA+1||h+12>=WORLD_Y)return;
  const material=worldTheme==='desert'?BLOCK.BRICK:worldTheme==='snow'?BLOCK.GLASS:BLOCK.STONE;
  const height=Math.min(8,3+Math.floor(worldDetailStage/5));
  for(let y=h+1;y<=h+height;y++)c.set(lx,y,lz,material);
  if(worldDetailStage>=8){for(let dx=-2;dx<=2;dx++)c.set(lx+dx,h+2,lz,dx===0?BLOCK.GLASS:material);}
  if(worldDetailStage>=15){for(let y=h+1;y<=h+Math.max(3,height-1);y++)c.set(lx+3,y,lz,material);for(let dx=0;dx<=3;dx++)c.set(lx+dx,h+height,lz,material);}
  if(worldDetailStage>=24){for(const [dx,dz] of [[1,1],[-1,1],[1,-1],[-1,-1]])c.set(lx+dx,h+height+1,lz+dz,BLOCK.GLASS);}
}

`, 'progressive landmark helper');
  client = replaceOnce(client,
    "  for(const r of rows){ const b=validBlockType(r.block_type);",
    "  addProgressiveLandmark(c,bx,bz);\n  for(const r of rows){ const b=validBlockType(r.block_type);",
    'progressive landmark call');
  client = replaceOnce(client,
    "worldTreeDensity=Number(vs.treeDensity)||1; if(vs.skyTint!==undefined)",
    "worldTreeDensity=Number(vs.treeDensity)||1; worldDetailStage=Math.max(1,Math.min(64,Math.trunc(Number(vs.detailStage)||31))); worldDetailProgress=clamp(Number(vs.detailProgress)||1,.03,1); if(vs.skyTint!==undefined)",
    'progressive detail init');
  write('apps/voxel-world/client.js', client);

  const pkg = JSON.parse(read('package.json'));
  pkg.scripts = pkg.scripts || {};
  pkg.scripts['engagement:learn'] = 'node scripts/engagement-learning-loop.js';
  pkg.scripts['engagement:learn:apply'] = 'node scripts/engagement-learning-loop.js --apply';
  write('package.json', JSON.stringify(pkg,null,2)+'\n');

  const wipPath='WORK_IN_PROGRESS.md';
  let wip=fs.existsSync(file(wipPath))?read(wipPath):'# WORK IN PROGRESS\n';
  const marker='## Navigator + Progressive World + Engagement Learning V1';
  if(!wip.includes(marker)) wip += `\n\n${marker}\n- Goal: replace the questionnaire feeling with a Navigator conversation while preserving the exact 31/28 ADD_ONLY question contract.\n- Reuse: PR #12 Story/World/Merge backend, existing Voxel World runtime, World Quality Autopilot, PostHog/Sentry. No duplicate scheduler or new top-level Vercel function.\n- Progressive world: /api/world action=preview upserts one stable voxel_worlds row per identity/journey. Same playable world reloads after each step, preserving player state.\n- Visual growth: bounded procedural landmarks + fog/tree/detail progression; one structure max per chunk; existing adaptive quality remains authoritative.\n- Learning: guarded UCB online learner changes only UX policy variants after minimum evidence and FPS/error/crash gates. It never rewrites question content automatically.\n- Required evidence: node tests, improve-world-home ADD_ONLY check, npm run check, release:gate, Playwright desktop+mobile, live /api/world preview, live PostHog events, no FPS regression.\n- Completion: only after all required evidence is real PASS; otherwise leave PR unmerged and continue fixing root causes.\n`;
  write(wipPath,wip);
  console.log('[NAV_ML_PATCH] apply complete');
}

if (VERIFY) {
  run('node --test test/progressive-world-preview.test.js test/engagement-learning-loop.test.js');
  run('node check.js', path.join(ROOT,'apps','improve-world-home'));
  run('npm run check');
  console.log('[NAV_ML_PATCH] quick verification PASS. Desktop AI must still run release:gate + Playwright + live preview/PostHog checks before merge.');
}
