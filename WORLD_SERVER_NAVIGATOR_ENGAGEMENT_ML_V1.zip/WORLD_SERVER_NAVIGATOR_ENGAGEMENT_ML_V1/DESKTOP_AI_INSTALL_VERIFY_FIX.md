# Desktop AI — install / verify / fix until green

## Цель
Внедрить **Navigator + Progressive Playable World + Engagement ML V1** без удаления/упрощения существующих систем. Это усиление текущего PR #12: Story/World/Merge + Voxel World + PostHog + World Quality Autopilot. **Не создавать второй мир-движок, второй quality-autopilot или второй scheduler.**

## Почему ZIP
В этой сессии прямое создание ветки через подключённый GitHub вернуло **403 `Resource not accessible by integration`**. Поэтому патч собран полностью и идемпотентно для Desktop AI.

## Перед установкой
1. Открой `C:\Users\user\Desktop\World_server`.
2. Прочитай `AGENTS.md` и `DESKTOP_AI_INSTALL_AND_VERIFY.md`.
3. Не трогай worktree/ветку другого ИИ. Проверь:
   ```powershell
   git status
   git branch --show-current
   git worktree list
   git log --oneline --decorate -20
   gh pr list --state open
   ```
4. Сравни текущую работу с PR #12 (`ai/claude/safe-parallel-20260826`). Переиспользуй его Story/World/Merge/PostHog изменения. Если PR #12 уже влит — работай от свежего `master`. Если нет — создай **свою** ветку поверх совместимой базы, не правь чужую ветку напрямую.
5. Создай ветку вида:
   ```powershell
   git checkout -b ai/desktop/navigator-engagement-ml-v1
   ```

## Установка
Скопируй **всю папку** `WORLD_SERVER_NAVIGATOR_ENGAGEMENT_ML_V1` рядом с репозиторием или внутрь временной папки. Из корня World_server запусти:

```powershell
node <ПУТЬ_К_ПАПКЕ>\install.cjs --verify
```

Installer:
- добавляет `lib/progressive-world.js`;
- добавляет `/api/world action=preview` в уже существующий narrative router (новой Vercel Function нет);
- добавляет `navigator-world-loop.js` поверх существующего 31/28 wizard, не удаляя вопросы;
- после каждого шага обновляет один и тот же playable Voxel World, а не создаёт новый Vercel project;
- добавляет bounded progressive landmarks (не больше 1 на chunk, малое число блоков, без новых draw-call систем);
- добавляет PostHog product events **без текста ответов**;
- добавляет `engagement-learning-loop.js` и guardrailed policy;
- обновляет `WORK_IN_PROGRESS.md`;
- запускает быстрые тесты.

## Архитектура мира — выбран гибрид
**Не генерировать полный новый проект/деплой после каждого ответа.** Это медленно и будет плодить проекты. Использовать один стабильный preview-world `p-...` на пользователя/режим.

После каждого ответа:
1. ответы уже сохранены в `localStorage` + Story sync;
2. `/api/world action=preview` строит partial World Spec;
3. сервер **upsert**-ит настройки того же `voxel_worlds`;
4. iframe Voxel World перезагружается с revision;
5. позиция игрока сохраняется через существующий `voxel_player_states`;
6. seed остаётся стабильным: мир узнаваемый, но каждый шаг проявляет больше деталей;
7. если динамический live-patch позже станет надёжнее reload — можно добавить его поверх, но deterministic reload остаётся fallback.

Это даёт ощущение: **«я ответил → мир реально изменился»** с минимальным риском FPS.

## Шаги проявления мира
Не превращать их в новый опросник — это внутренние фазы разговора Навигатора:
- **Искра**: темнота, глаз, огонёк, сильный туман, почти нет деталей.
- **Пространство**: рельеф, свет, погода, поверхность, первые ориентиры.
- **Живое**: персонажи/желания отражаются через плотность и атмосферу.
- **Напряжение**: рельеф/туман/ландшафт усиливают конфликт.
- **Решение**: появляются пути, руины/башни/ориентиры.
- **Проявление**: финальный playable мир + публикация/соединение.

## Обязательные проверки
После installer quick PASS обязательно продолжить:

```powershell
npm run release:gate
npx playwright test e2e/improve-world-home-baseline.spec.js --project=desktop-chromium
npx playwright test e2e/improve-world-home-baseline.spec.js --project=mobile-webkit
```

Добавь/запусти новый E2E сценарий:
1. открыть главную;
2. увидеть dark-eye-fire intro;
3. нажать «Создать свой мир»;
4. дождаться iframe playable preview;
5. пройти минимум 6 вопросов разными ответами;
6. доказать, что `world id` остаётся тем же, `revision/detailStage` меняются;
7. доказать, что после каждого `Дальше` мир перерисовывается;
8. зайти в iframe и пройти/осмотреться;
9. проверить desktop + mobile touch;
10. проверить отсутствие Vercel Function count regression;
11. проверить FPS и ошибки.

## FPS-gate
Нельзя повышать коммерческий/engagement score ценой лагов.
- mobile p10: целевой минимум **30 FPS**;
- desktop p10: целевой минимум **45 FPS**;
- crash rate ≤ **0.5%**;
- error-session rate ≤ **2%**.
Если не проходит — уменьшай **только новые** landmark probability/height/reload cadence. Не упрощай существующую графику.

## PostHog / обучение
Используй уже установленный PostHog из PR #12. Не включай PostHog Session Replay/Error Tracking — это уже делает Sentry.

События новой системы:
- `iw_navigator_intro_viewed`
- `iw_navigator_started`
- `iw_navigator_step`
- `iw_question_advanced`
- `iw_question_skipped`
- `iw_world_preview_ready`
- `iw_world_preview_error`

**Не отправлять текст ответов.** Только step/total, bucket длины, число сущностей, variant, first-world-visible time, технические метрики.

Подготовь агрегированный файл (не коммить сырые пользовательские события):
`data/engagement-telemetry-export.json`

Формат session:
```json
{
  "variant": {"navigatorTone":"mysterious","worldRefreshCadence":"every-step","revealStrength":"cinematic"},
  "totalSteps":31,
  "maxStep":12,
  "firstWowMs":14000,
  "completed":false,
  "worldInteractions":5,
  "published":false,
  "merged":false,
  "shared":false,
  "returnedWithin7d":false,
  "skips":1,
  "fpsP10":48,
  "device":"mobile",
  "errorCount":0,
  "crashed":false
}
```

Запуск обучения:
```powershell
npm run engagement:learn
```
Сначала только report. Применение политики разрешено лишь при достаточной выборке и всех guardrails:
```powershell
npm run engagement:learn:apply
```
Никогда не применять `--apply`, если нет реальной статистической выборки или FPS/error/crash guardrails не PASS.

## Что измерять для движения 55 → 100
Score не ставить «на глаз». Использовать доказательства:
- time-to-first-wow / first playable world;
- дошёл ли человек до 3/6/12/финального шага;
- глубина взаимодействия с миром;
- skip/abandon;
- publish/share/merge intent;
- return within 7d;
- FPS p10, crashes, JS/API errors;
- world-change visibility после каждого ответа.

`engagement-learning-loop.js` считает guarded score 0–100. **100 допустим только при реальных данных**, а не потому что код «готов».

## Если ошибка
1. Зафиксируй точную ошибку + reproduction.
2. Найди первопричину.
3. Исправь её в общей системе, не точечным обходом.
4. Добавь regression test.
5. Повтори quick tests → `npm run check` → `release:gate` → Playwright → live deployment.
6. Сохрани причину/решение в `WORK_IN_PROGRESS.md` и, если обобщается, в Golden Component/knowledge system.
7. Не merge, пока реальные gates не PASS.

## Что ещё хорошо бы добавить после V1
Только после стабильного V1:
- live world hot-reload без iframe reload (WebSocket/Broadcast settings revision) с reload fallback;
- semantic mapping answer → landmark/material/light using existing `semantic-provider`, без платного API;
- spatialized Navigator voice (open-source TTS, локальный fallback — текст всегда работает);
- procedural creatures/NPC silhouettes, которые проявляются из ответов;
- questlets: каждый ответ создаёт маленькую цель в уже существующем мире;
- PostHog experiment/feature-flag layer или собственный contextual bandit только после достаточной выборки;
- automated synthetic-user Playwright personas: explorer / storyteller / impatient / child-friendly / mobile-low-end;
- perceptual screenshot diff для каждого detailStage.

## Готовность этого патча
- Код/инсталлятор: **≈90%**.
- Production readiness: **не считать выше реальных gates**. До 100% нужны live deploy, PostHog event proof, mobile/desktop FPS evidence и реальная пользовательская выборка.
