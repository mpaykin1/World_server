param([string]$Repo = "C:\Users\user\Desktop\World_server")
$ErrorActionPreference='Stop'
Push-Location $Repo
try {
  node --check scripts/cinematic-voxel-quality-gate.js
  node --check scripts/cinematic-v3-quality-gate.js
  node --check scripts/cinematic-asset-pipeline.js
  node --check shared/cinematic-voxel-quality-guard.js
  node --check shared/cinematic-visibility-supervisor.js
  node --check shared/cinematic-temporal-quality-governor.js
  node --check shared/cinematic-scene-adapter-contract.js
  node --test test/cinematic-voxel-policy.test.js test/cinematic-v3-systems.test.js
  npm run quality:cinematic:v3
  npm run quality:cinematic:assets
  Write-Host "Static V3 checks PASS."
  Write-Host "For real evidence start server, capture Playwright screenshots, then run:"
  Write-Host "  npm run quality:cinematic:devices"
  Write-Host "  `$env:CINEMATIC_CANDIDATE='artifacts\cinematic\voxel-world-desktop.png'; npm run quality:cinematic:v3:strict"
  Write-Host "Finally run npm run release:gate. Fix root cause until every required gate PASS."
} finally { Pop-Location }
