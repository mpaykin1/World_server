# ОБЯЗАТЕЛЬНАЯ ИНСТРУКЦИЯ DESKTOP AI — CINEMATIC VOXEL QUALITY V3

## Главная цель
Никогда не выдавать примитивный prototype-render за готовую графику. Любая cinematic/hero 3D voxel сцена сразу строится как high-detail 3D voxel art с адаптивным quality ceiling и максимально возможным FPS на конкретном устройстве. Stretch goal = 100, production target = 99, hard floor = 90. 100 заявлять только при реальном evidence.

## Сначала переиспользовать существующее
В World_server уже есть `WorldQualityAutopilot`, `GoldenPerformanceAutoTune`, telemetry, visual baselines/regression, world detail/material/visibility/device systems, Golden Components, quality/root-cause/evidence systems и AI3D Depth Anything. Усиливать их. Не создавать второй общий autopilot и не дублировать SDK.

## Без конфликта с другими ИИ
Перед изменениями прочитать `WORK_IN_PROGRESS.md`, проверить открытые PR/ветки/worktree. Сейчас особенно возможны пересечения с активными quality/runtime и Vercel ветками. Не писать поверх незавершённой работы. Делать отдельную ветку/worktree; конфликтующие изменения HOLD/patch. Не push в master.

## Установка
1. Запустить:
   `powershell -ExecutionPolicy Bypass -File .\INSTALL.ps1 -Repo "C:\Users\user\Desktop\World_server"`
2. Базовые Python зависимости: Pillow + NumPy. Они CPU-only и обязательны для reference/depth proxy.
3. Тяжёлый ML стек опционален:
   `powershell -ExecutionPolicy Bypass -File .\INSTALL.ps1 -Repo "C:\Users\user\Desktop\World_server" -InstallHeavyML`
   Он ставит CPU-capable Torch/OpenCLIP/LPIPS, но НЕ скачивает модельные веса автоматически. Использовать только локально одобренные бесплатные веса; иначе fallback остаётся рабочим.
4. Для Godot скопировать `tools/cinematic-voxel-godot-addon/cinematic_voxel_guard` в `<ACTIVE_GODOT_PROJECT>/addons/`, включить plugin и пометить hero/cinematic scene группой `cinematic_voxel_scene` или metadata `cinematic_voxel_guard=true`.

## Новый обязательный V3 loop на каждом цикле
1. **Capture**: desktop + mobile +, когда возможно, 3–5 orbit/camera angles + depth evidence.
2. **Score**: structural reference scorer + perceptual scorer + depth-structure scorer + runtime quality stats.
3. **Find worst metric**: не улучшать всё хаотично; найти главный bottleneck.
4. **Root cause**: geometry density / material hierarchy / light transport / fog depth / composition / UI / LOD / culling / frame-time spike.
5. **Repair**: исправить первопричину.
6. **Optimize in order**: occluded → offscreen → far density → far shadows → secondary particles → far materials/reflections → atmosphere samples → shadow resolution → render resolution → near nonhero → near hero LAST.
7. **Re-capture and re-score**. Нельзя увеличивать readiness без нового evidence.
8. **Regression shield**: любой новый failure class превращать в автоматический тест/guard.
9. **Promote success**: успешный material/LOD/fog/light/streaming preset сохранять в существующих Golden/quality системах и распространять на совместимые сцены/Web/Native.

## Cinematic Eye + Fire contract
- глаз физически встроен в voxel wall/terrain; sprite/billboard без 3D integration = FAIL;
- огонь = geometry + animated emissive flame + glow + local light spill + fog illumination + pedestal;
- минимум foreground/midground/background, желательно 5 depth bands;
- тьма должна содержать геометрию/атмосферу; большой однотонный синий/чёрный фон = FAIL;
- detail hierarchy: macro silhouette + medium voxel forms + micro voxel breakup;
- минимум 3 material layers, target 5: albedo variation, roughness, edge/wetness, macro dirt, emissive/accent where justified;
- warm amber focus против cold charcoal/neutral darkness;
- Navigator UI — законченная часть art direction, не debug overlay;
- hero silhouette и near geometry не деградируют первыми ради FPS.

## Производительность
Использовать уже существующий `WorldQualityAutopilot` + V3 supervisors:
- frustum culling + HZB/occlusion hooks;
- instance/material clustering;
- hero/camera importance budget;
- temporal quality governor с hysteresis и p95 frame time;
- dynamic resolution только после уменьшения невидимой/дальней работы;
- meshoptimizer/gltfpack для GLB;
- KTX2/BasisU для текстур;
- worker/off-thread meshing и streaming, если уже поддерживается сценой;
- CPU fallback обязателен; платный/server GPU не является требованием.

## Проверка
Статика:
- `powershell -ExecutionPolicy Bypass -File .\VERIFY.ps1 -Repo "C:\Users\user\Desktop\World_server"`

Runtime:
- запустить сервер;
- `npx playwright test e2e/cinematic-voxel-quality.spec.js e2e/cinematic-device-matrix.spec.js --project=desktop-chromium`
- `$env:CINEMATIC_CANDIDATE='artifacts\cinematic\voxel-world-desktop.png'; npm run quality:cinematic:v3:strict`
- `npm run release:gate`

## Если FAIL
Не ослаблять threshold, чтобы тест стал зелёным. Исправить причину, повторить capture/score. Threshold разрешено менять только если доказана ошибка измерения, и одновременно добавить regression test на эту ошибку измерения.

## Бесплатные инструменты
Обязательные/лёгкие: Python, Pillow, NumPy, Playwright, ffmpeg/ImageMagick при наличии.
Полезные native asset tools: meshoptimizer/gltfpack, KTX-Software/toktx, Basis Universal.
Опциональные ML: Torch + OpenCLIP + LPIPS; DINOv2 допустим как дополнительный offline backend. Не делать большой model download обязательным для build/release.

## Definition of Done
- primitive failure screenshot отвергается;
- реальная новая сцена проходит desktop/mobile capture;
- reference + perceptual + depth evidence PASS;
- p95 frame time соответствует device budget;
- нет визуальной деградации near hero/UI;
- release gate PASS;
- новый evidence сохранён;
- readiness повышается только по измеренному результату.
