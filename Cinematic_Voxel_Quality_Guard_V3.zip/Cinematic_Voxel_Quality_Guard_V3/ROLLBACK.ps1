param([string]$Repo = "C:\Users\user\Desktop\World_server")
$ErrorActionPreference='Stop'
$backup=Get-ChildItem $Repo -Directory -Filter '.cinematic-voxel-guard-backup-*'|Sort-Object Name -Descending|Select-Object -First 1
if(!$backup){throw 'No cinematic guard backup found'}
Get-ChildItem $backup.FullName -File -Recurse|ForEach-Object{
  $rel=$_.FullName.Substring($backup.FullName.Length).TrimStart('\','/')
  $dst=Join-Path $Repo $rel;New-Item -ItemType Directory -Force (Split-Path $dst -Parent)|Out-Null;Copy-Item $_.FullName $dst -Force
}
Write-Host "Restored $($backup.FullName)"
