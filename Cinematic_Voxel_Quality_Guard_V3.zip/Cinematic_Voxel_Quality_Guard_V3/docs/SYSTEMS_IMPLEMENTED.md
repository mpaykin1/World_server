# Реализованные системы V3

V3 сохраняет всё из V2 и добавляет:

- **Semantic/Perceptual Reference Critic** — OpenCLIP/LPIPS hooks с обязательным CPU fallback без скачивания весов.
- **Depth Structure Regression** — сравнение настоящих depth maps, если движок их отдаёт; иначе conservative CPU proxy.
- **Multi-angle Evidence Contract** — не только один красивый кадр, но и orbit/camera evidence.
- **Visibility Supervisor** — frustum + HZB/occlusion hooks + instance clustering + camera/hero importance budget.
- **Temporal Quality Governor** — p95 frame-time hysteresis; сначала режет дальние/вторичные расходы, near hero защищён.
- **Asset Optimization Pipeline** — обнаружение meshoptimizer/gltfpack, KTX2/BasisU/toktx, правила безопасного сжатия.
- **Device Matrix** — phone-low / phone-mid / desktop-iGPU / desktop-high capture/evidence.
- **Scene Adapter Contract** — единый интерфейс, соединяющий существующий WorldQualityAutopilot, cinematic guard, visibility и temporal governor.
- **Godot Export Gate** — cinematic scene не собирается, если слишком бедная геометрия, свет, fog, LOD или voxel contract.
- **Evidence-locked readiness** — процент нельзя повышать только по плану/коду без нового runtime/visual evidence.
- **No-conflict installation** — backup, idempotent scripts, add-only runtime layers, запрет дублировать существующий autopilot.
