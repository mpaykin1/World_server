# Что ещё может существенно улучшить качество после V3

## Самый сильный следующий слой
1. **True engine depth + normals capture** для каждого golden camera — заменит proxy depth реальной геометрией.
2. **Approved DINOv2/OpenCLIP local weights cache** — semantic similarity без сетевых downloads в CI.
3. **GPU HZB implementation in the actual renderer** — сейчас V3 даёт contract/hooks; нужна конкретная реализация в активном Three.js/Godot renderer.
4. **Greedy meshing + meshlet/cluster streaming everywhere** — текущие миры должны унифицировать лучшие worker/meshing решения.
5. **Temporal volumetric fog reprojection** — улучшит атмосферу при меньшем sample budget.
6. **Contact shadows + importance shadow atlas** — hero eye/fire получают стабильные тени, фон дешевле.
7. **Material/texture virtual atlas** — меньше draw calls без потери near detail.
8. **Automated cinematic camera search** — несколько кандидатов композиции оцениваются quality critic, лучший сохраняется Golden.
9. **Real-device farm evidence** — Android/iOS/desktop реальный p50/p95/p99, thermal drop, memory, WebGL/WebGPU capability.
10. **Native/Web cross-quality loop** — одинаковые scene seeds/camera paths/replays и visual/perf diff между Godot EXE и Web.
11. **Perceptual importance map** — gaze/hero/contrast-driven detail, а не только distance LOD.
12. **Shader variant compiler/cache** — заранее готовить варианты материалов по device tier и избегать runtime shader stalls.

Главный оставшийся путь к честным 100% — не новые правила, а реальный runtime renderer integration + новые кадры + реальные device measurements.
