# Cinematic Voxel Quality Guard V3 — единый cumulative patch

Установка:
`powershell -ExecutionPolicy Bypass -File .\INSTALL.ps1 -Repo "C:\Users\user\Desktop\World_server"`

Проверка:
`powershell -ExecutionPolicy Bypass -File .\VERIFY.ps1 -Repo "C:\Users\user\Desktop\World_server"`

Главная инструкция Desktop AI: `DESKTOP_AI_MASTER_INSTRUCTIONS.md`.

V3 не создаёт новый общий autopilot. Он усиливает существующие World_server quality/performance/telemetry/golden системы и добавляет fail-closed cinematic gates, perceptual/depth evidence, device matrix, visibility/temporal supervisors и Godot export gate.
