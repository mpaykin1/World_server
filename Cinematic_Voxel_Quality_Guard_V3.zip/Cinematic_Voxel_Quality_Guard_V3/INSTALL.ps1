param(
  [string]$Repo = "C:\Users\user\Desktop\World_server",
  [switch]$SkipPythonDeps,
  [switch]$InstallHeavyML
)
$ErrorActionPreference='Stop'
$Here=Split-Path -Parent $MyInvocation.MyCommand.Path
$Patch=Join-Path $Here 'patch'
if(!(Test-Path (Join-Path $Repo 'package.json'))){throw "World_server repo not found: $Repo"}
if(!(Test-Path (Join-Path $Repo 'shared\world-quality-autopilot.js'))){throw "Existing WorldQualityAutopilot missing; refusing duplicate/unsafe install"}
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
$backup=Join-Path $Repo ".cinematic-voxel-guard-backup-$stamp"
New-Item -ItemType Directory -Force $backup | Out-Null

function Backup-File([string]$rel){$src=Join-Path $Repo $rel;if(Test-Path $src){$dst=Join-Path $backup $rel;New-Item -ItemType Directory -Force (Split-Path $dst -Parent)|Out-Null;Copy-Item $src $dst -Force}}
function Install-File([string]$rel){$src=Join-Path $Patch $rel;$dst=Join-Path $Repo $rel;New-Item -ItemType Directory -Force (Split-Path $dst -Parent)|Out-Null;Backup-File $rel;Copy-Item $src $dst -Force}

$files=@(
 'data\cinematic-voxel-quality-policy.json','data\cinematic-voxel-regression-signatures.json','shared\cinematic-voxel-quality-guard.js','shared\cinematic-visibility-supervisor.js',
 'shared\cinematic-temporal-quality-governor.js','shared\cinematic-scene-adapter-contract.js',
 'scripts\cinematic-reference-score.py','scripts\cinematic-ml-score.py','scripts\cinematic-depth-regression.py','scripts\cinematic-asset-pipeline.js',
 'scripts\cinematic-voxel-quality-gate.js','scripts\cinematic-v3-quality-gate.js',
 'e2e\cinematic-voxel-quality.spec.js','e2e\cinematic-device-matrix.spec.js','test\cinematic-voxel-policy.test.js','test\cinematic-v3-systems.test.js',
 '.github\workflows\cinematic-voxel-quality.yml','docs\CINEMATIC_VOXEL_QUALITY_GUARD.md',
 'reference\cinematic_eye_fire_reference.png','reference\primitive_failure_example.png','reference\reference_metrics.json'
)
foreach($f in $files){Install-File $f}

# Extend package scripts idempotently, never replace the existing autopilot.
$pkgPath=Join-Path $Repo 'package.json'; Backup-File 'package.json'; $pkg=Get-Content $pkgPath -Raw|ConvertFrom-Json
$pkg.scripts | Add-Member -NotePropertyName 'quality:cinematic' -NotePropertyValue 'node scripts/cinematic-voxel-quality-gate.js' -Force
$pkg.scripts | Add-Member -NotePropertyName 'quality:cinematic:strict' -NotePropertyValue 'node scripts/cinematic-voxel-quality-gate.js --strict' -Force
$pkg.scripts | Add-Member -NotePropertyName 'quality:cinematic:v3' -NotePropertyValue 'node scripts/cinematic-v3-quality-gate.js' -Force
$pkg.scripts | Add-Member -NotePropertyName 'quality:cinematic:v3:strict' -NotePropertyValue 'node scripts/cinematic-v3-quality-gate.js --strict' -Force
$pkg.scripts | Add-Member -NotePropertyName 'quality:cinematic:devices' -NotePropertyValue 'playwright test e2e/cinematic-device-matrix.spec.js --project=desktop-chromium' -Force
$pkg.scripts | Add-Member -NotePropertyName 'quality:cinematic:assets' -NotePropertyValue 'node scripts/cinematic-asset-pipeline.js' -Force
if($pkg.scripts.'release:gate' -notmatch 'quality:cinematic:v3'){$pkg.scripts.'release:gate'=$pkg.scripts.'release:gate' -replace 'npm run quality:perceptual','npm run quality:perceptual && npm run quality:cinematic:v3'}
$pkg|ConvertTo-Json -Depth 50|Set-Content $pkgPath -Encoding UTF8

# Extend existing visual policy, preserving prior keys.
$vp='data\visual-quality-policy.json'; Backup-File $vp; $vpPath=Join-Path $Repo $vp; $v=Get-Content $vpPath -Raw|ConvertFrom-Json
$v.rules | Add-Member -NotePropertyName 'cinematicVoxelGuardRequired' -NotePropertyValue $true -Force
$v.rules | Add-Member -NotePropertyName 'primitivePrototypeCannotShip' -NotePropertyValue $true -Force
$v.rules | Add-Member -NotePropertyName 'referenceProxyRequiredForCinematicScenes' -NotePropertyValue $true -Force
$v.rules | Add-Member -NotePropertyName 'depthStructureEvidenceRequired' -NotePropertyValue $true -Force
$v.rules | Add-Member -NotePropertyName 'multiAngleGoldenEvidencePreferred' -NotePropertyValue $true -Force
$v.rules | Add-Member -NotePropertyName 'cinematicQualityIncreaseRequiresEvidence' -NotePropertyValue $true -Force
$v|ConvertTo-Json -Depth 20|Set-Content $vpPath -Encoding UTF8


# Register the primitive-graphics root cause in the existing recurrence-protection registry.
$erp='data\error-prevention-registry.json'
$erpPath=Join-Path $Repo $erp
if(Test-Path $erpPath){
  Backup-File $erp
  $reg=Get-Content $erpPath -Raw|ConvertFrom-Json
  $exists=$false
  foreach($e in $reg.knownErrors){if($e.id -eq 'primitive-flat-voxel-scene'){$exists=$true}}
  if(!$exists){
    $entry=[pscustomobject]@{
      id='primitive-flat-voxel-scene'; category='graphics'; severity='release-blocker'; status='protected';
      symptom='large flat background, sparse geometry, weak depth, simple eye/fire placeholders or missing cinematic UI';
      rootCause='scene accepted before high-detail geometry, lighting, atmosphere, materials and evidence gates were satisfied';
      protection=@('cinematic V3 reference/perceptual/depth gates','Godot export gate','desktop/mobile device matrix','hero quality floor','evidence-locked readiness')
    }
    $reg.knownErrors=@($reg.knownErrors)+$entry
    $reg|ConvertTo-Json -Depth 50|Set-Content $erpPath -Encoding UTF8
  }
}

# Make the rule visible to Desktop AI in the repo without replacing existing instructions.
$daiRel='DESKTOP_AI_INSTALL_AND_VERIFY.md'; $daiPath=Join-Path $Repo $daiRel
if(Test-Path $daiPath){
  Backup-File $daiRel
  $dai=Get-Content $daiPath -Raw
  if($dai -notmatch 'CINEMATIC_VOXEL_QUALITY_V3_BEGIN'){
    $block=@'

<!-- CINEMATIC_VOXEL_QUALITY_V3_BEGIN -->
## Cinematic Voxel Quality V3 — mandatory graphics gate
For cinematic/high-detail 3D voxel scenes, primitive placeholder graphics are a release blocker. Reuse WorldQualityAutopilot and existing Golden/telemetry systems; run `npm run quality:cinematic:v3`, desktop/mobile captures and strict candidate scoring before claiming improvement. Preserve hero/near quality first; optimize occluded/offscreen/far work before render resolution or hero geometry. Every failure requires root cause + regression protection. See `docs/CINEMATIC_VOXEL_QUALITY_GUARD.md`.
<!-- CINEMATIC_VOXEL_QUALITY_V3_END -->
'@
    Set-Content $daiPath ($dai+$block) -Encoding UTF8
  }
}

# Inject the additive runtime layers after WorldQualityAutopilot. Safe/idempotent.
$idx='apps\voxel-world\index.html'; Backup-File $idx; $idxPath=Join-Path $Repo $idx; $html=Get-Content $idxPath -Raw
$inject=@(
 '<script src="/shared/cinematic-voxel-quality-guard.js"></script>',
 '<script src="/shared/cinematic-visibility-supervisor.js"></script>',
 '<script src="/shared/cinematic-temporal-quality-governor.js"></script>',
 '<script src="/shared/cinematic-scene-adapter-contract.js"></script>'
)
foreach($tag in $inject){if($html -notmatch [regex]::Escape(($tag -replace '^<script src="','' -replace '"></script>$',''))){$html=$html.Replace('</body>',"$tag`r`n</body>")}}
Set-Content $idxPath $html -Encoding UTF8

# Godot addon payload: copy to neutral integration area; Desktop AI places it in the active Godot project/worktree after conflict check.
$godotDst=Join-Path $Repo 'tools\cinematic-voxel-godot-addon'; if(Test-Path $godotDst){Backup-File 'tools\cinematic-voxel-godot-addon'}; New-Item -ItemType Directory -Force $godotDst|Out-Null
Copy-Item (Join-Path $Patch 'godot\addons\cinematic_voxel_guard') $godotDst -Recurse -Force

if(!$SkipPythonDeps){
  try{python -c "import PIL,numpy" 2>$null}catch{python -m pip install --disable-pip-version-check pillow numpy}
}
if($InstallHeavyML){
  Write-Host "Installing optional CPU-capable perceptual backends. This can be a large download."
  python -m pip install --disable-pip-version-check torch torchvision open_clip_torch lpips
  Write-Host "OpenCLIP pretrained weights are NOT auto-downloaded. Set CINEMATIC_OPENCLIP_WEIGHTS to a locally approved weights file."
}

Write-Host "Installed Cinematic Voxel Quality Guard V3"
Write-Host "Backup: $backup"
Write-Host "Next: powershell -ExecutionPolicy Bypass -File `"$Here\VERIFY.ps1`" -Repo `"$Repo`""
