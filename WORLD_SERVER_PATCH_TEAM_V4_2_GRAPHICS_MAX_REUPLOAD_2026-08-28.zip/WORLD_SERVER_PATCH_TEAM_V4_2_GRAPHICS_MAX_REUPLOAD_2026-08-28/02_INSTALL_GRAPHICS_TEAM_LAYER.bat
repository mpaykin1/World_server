@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp002_INSTALL_GRAPHICS_TEAM_LAYER.ps1"
pause
