# PATCH TEAM V2 — как патчи усиливают друг друга

## Главный принцип
Не создаётся второй master-orchestrator. Используется уже существующий `scripts/technology-orchestrator.js`. Новый `patch-team-gate.js` — слой контрактов совместимости, подключённый к существующему `release:gate`.

## Командная цепочка
1. Session Recovery — checkpoint/resume для всей установки.
2. Vercel Function Budget — гарантирует deployability объединённой системы.
3. CharacterForge — voxel-персонажи + LOD/metadata.
4. Frame/Procedural Motion — единая анимация персонажей, объектов, камеры, эффектов и окружения.
5. Ink / Pixel 360 / 3DGS — разные world providers, но общие animation/input/quality contracts.
6. Home Curator — автоматически обнаруживает готовые миры.
7. PWA — ставится последней, версионирует cache после изменения миров/ассетов.
8. Existing Quality + Knowledge — ошибки и успешные решения идут в существующие regression/quality/knowledge системы.

## Обязательные связи
- CharacterForge output -> shared animation adapter -> compatible world runtime.
- World output -> existing quality analyzer -> curator -> PWA manifest/cache.
- Asset change -> asset dedup -> PWA cache version bump.
- New endpoint -> Vercel function-budget gate.
- Interactive world -> desktop + mobile Playwright; keyboard/mouse/touch.
- Heavy generator -> CPU fallback.
- Fix -> regression test -> existing regression/knowledge capture.

## Защита от конфликтов
- Один capability = один канонический provider.
- Новая версия заменяет старую, старую рядом не ставить.
- Если V7.5/V13 уже содержит эквивалент — новый патч становится adapter/extension либо `SKIP_SUPERSEDED`.
