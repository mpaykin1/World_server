# GRAPHICS TEAM ARCHITECTURE V4

## Один мозг, несколько рендеров
- `technology-orchestrator` — реестр доступных технологий.
- `WorldQualityAutopilot` — единый runtime quality/performance control plane.
- `Frame/Procedural Motion` — единая анимационная временная шкала.
- `Asset Registry + content hashes` — единое происхождение и cache.
- `PWA` — последняя упаковка/cache, а не отдельный источник истины.

## Пайплайн
1. **World Spec** задаёт смысл/тему/seed/напряжение/параметры.
2. **Graphics Router** выбирает режим по задаче, устройству и бюджету:
   - voxel: мгновенно/интерактивно;
   - Pixel360: лёгкая иммерсивная сцена;
   - GS360: дорогая реконструкция, когда есть хорошие входные данные;
   - Godot/mesh: готовые high-detail assets.
3. Все режимы используют одну Device Profile/Quality policy.
4. CharacterForge output подключается к shared motion и collision contracts.
5. Pixel V5 + GS V7 используют один Depth Anything adapter/cache.
6. GS V7 конвертирует master только в производные SPZ/SOG/LOD, master не удаляется.
7. Home/Curator регистрирует только certified worlds.
8. PWA пересобирает manifest/cache только после certification.
9. Ошибка -> root cause -> regression -> knowledge.

## Порядок новых усилений
**PR12 current dynamic runtime** → **PR3 selective worker/greedy acceleration** → **Three r185 staged migration** → **WQA full adapter wiring** → **Pixel V5** → **GS V7** → **PWA/cache**.
