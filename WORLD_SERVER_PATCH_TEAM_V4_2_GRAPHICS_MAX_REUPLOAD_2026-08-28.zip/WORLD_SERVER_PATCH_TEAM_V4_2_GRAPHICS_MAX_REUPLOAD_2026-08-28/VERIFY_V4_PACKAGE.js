#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process');
const ROOT=__dirname;
const required=[
 'PATCH_MANIFEST.json','NEW_PATCHES_2026-08-28.md','GRAPHICS_ENGINE_ANALYSIS.md','GRAPHICS_TEAM_ARCHITECTURE.md',
 'DESKTOP_AI_V4_INSTALL_VERIFY_FIX.md','FETCH_PATCH_SOURCES.ps1','02_INSTALL_GRAPHICS_TEAM_LAYER.ps1',
 'MIGRATE_THREE_TO_R185.ps1','INSTALL_GRAPHICS_OSS.ps1',
 'TEAM_INTEGRATION_PAYLOAD/data/graphics-team-contracts.json',
 'TEAM_INTEGRATION_PAYLOAD/shared/voxel-quality-bridge.js',
 'TEAM_INTEGRATION_PAYLOAD/scripts/graphics-engine-gap-audit.js',
 'TEAM_INTEGRATION_PAYLOAD/scripts/graphics-team-gate.js',
 'TEAM_INTEGRATION_PAYLOAD/test/graphics-team-contract.test.js'
];
const missing=required.filter(x=>!fs.existsSync(path.join(ROOT,x)));
const js=required.filter(x=>x.endsWith('.js'));
const syntax=[];
for(const rel of js){
 const r=cp.spawnSync(process.execPath,['--check',path.join(ROOT,rel)],{encoding:'utf8'});
 if(r.status!==0)syntax.push({rel,error:r.stderr});
}
const t=cp.spawnSync(process.execPath,['--test',
 path.join(ROOT,'TEAM_INTEGRATION_PAYLOAD/test/graphics-team-contract.test.js'),
 path.join(ROOT,'TEAM_INTEGRATION_PAYLOAD/test/patch-team-contract.test.js'),
 path.join(ROOT,'TEAM_INTEGRATION_PAYLOAD/test/feature-flags.test.js')
],{cwd:ROOT,encoding:'utf8'});
const m=JSON.parse(fs.readFileSync(path.join(ROOT,'PATCH_MANIFEST.json'),'utf8'));
const pixel=m.patches.find(p=>p.id==='pixel-panorama-360');
const gs=m.patches.find(p=>p.id==='gs360-cpu-quality');
const assertions=[];
if(pixel?.archive!=='WORLD_SERVER_PIXEL_PANORAMA_360_V5.zip')assertions.push('pixel_not_v5');
if(gs?.archive!=='WORLD_SERVER_3DGS_360_CPU_QUALITY_V7.zip')assertions.push('gs_not_v7');
if(!m.source_patches?.some(x=>x.pr===12))assertions.push('pr12_missing');
if(!m.source_patches?.some(x=>x.pr===3))assertions.push('pr3_missing');
const report={pass:!missing.length&&!syntax.length&&t.status===0&&!assertions.length,missing,syntax,unitExit:t.status,assertions};
fs.writeFileSync(path.join(ROOT,'V4_PACKAGE_SELFTEST.json'),JSON.stringify(report,null,2)+'\n');
console.log(`[V4_PACKAGE] ${report.pass?'PASS':'FAIL'} required=${required.length} testsExit=${t.status}`);
if(!report.pass){process.stderr.write(t.stderr||'');process.exit(1)}
