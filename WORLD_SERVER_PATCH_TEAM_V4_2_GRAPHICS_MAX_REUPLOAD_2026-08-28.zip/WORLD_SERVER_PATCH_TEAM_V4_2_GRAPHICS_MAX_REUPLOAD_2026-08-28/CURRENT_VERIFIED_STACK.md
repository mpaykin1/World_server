# CURRENT VERIFIED OSS STACK — checked 2026-08-27

Desktop AI must still query **latest stable at installation time** and pin the exact version it actually installs.

- Trivy: latest 0.74.x line observed; installer resolves GitHub `releases/latest` and requires SHA-256/release digest.
- OSV-Scanner: v2.4.0 latest observed.
- Renovate: 44.2.1 latest observed.
- @axe-core/playwright: 4.13.0 latest observed.
- size-limit: 13.0.3 latest observed.
- @openfeature/server-sdk: 1.23.0 latest observed.
- @opentelemetry/api: 1.9.1 latest observed.
- @opentelemetry/sdk-node: 0.221.0 observed and is EXPERIMENTAL; install as optional/canary only.

Policy:
- no hard-coded old binary downloads;
- exact npm versions are resolved and pinned during Desktop AI install;
- production enablement requires preview + regression + performance pass;
- Sentry remains canonical browser error/replay layer.
