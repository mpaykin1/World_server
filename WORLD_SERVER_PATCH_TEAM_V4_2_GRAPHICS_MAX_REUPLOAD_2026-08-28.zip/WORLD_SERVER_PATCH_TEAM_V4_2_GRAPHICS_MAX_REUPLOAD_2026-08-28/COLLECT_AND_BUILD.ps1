﻿param([string]$RepoPath="C:\Users\user\Desktop\World_server",[string[]]$ExtraSearchRoots=@())
$ErrorActionPreference="Stop";$here=Split-Path -Parent $MyInvocation.MyCommand.Path;$manifest=Get-Content -Raw (Join-Path $here "PATCH_MANIFEST.json")|ConvertFrom-Json
function AddRoot($list,$p){if([string]::IsNullOrWhiteSpace($p)){return};try{$f=[IO.Path]::GetFullPath($p);if((Test-Path $f)-and-not $list.Contains($f)){$list.Add($f)}}catch{}}
$roots=[Collections.Generic.List[string]]::new();AddRoot $roots $RepoPath;AddRoot $roots (Split-Path -Parent $RepoPath);AddRoot $roots (Join-Path $env:USERPROFILE "Downloads");AddRoot $roots (Join-Path $env:USERPROFILE "Desktop");AddRoot $roots (Join-Path $env:USERPROFILE "Documents");AddRoot $roots (Join-Path $env:USERPROFILE "OneDrive\Desktop");AddRoot $roots (Join-Path $env:USERPROFILE "OneDrive\Downloads");foreach($r in $ExtraSearchRoots){AddRoot $roots $r}
$stamp=Get-Date -Format "yyyyMMdd-HHmmss";$outRoot=Join-Path $here ("OUTPUT\WORLD_SERVER_PATCH_TEAM_V4_"+$stamp);$patchDir=Join-Path $outRoot "PATCHES";New-Item -ItemType Directory -Force $patchDir|Out-Null
$report=[ordered]@{schema='world-server.pending-patches-collection-report/v4';created_at=(Get-Date).ToString('o');repo=$RepoPath;search_roots=@($roots);found=@();missing=@();hash_mismatch=@();candidate_found=@();missing_confirmed_pending=@()}
function FindExact($name){$hits=@();foreach($root in $roots){try{$hits+=Get-ChildItem -LiteralPath $root -Filter $name -File -Recurse -ErrorAction SilentlyContinue}catch{}};return $hits|Sort-Object LastWriteTime -Descending}
foreach($p in ($manifest.patches|Sort-Object priority)){
  $hits=@(FindExact $p.archive)
  if(!$hits.Count){$x=[ordered]@{id=$p.id;archive=$p.archive;status=$p.status;reason=$p.reason};$report.missing+=$x;if($p.status -like 'confirmed_pending*'){$report.missing_confirmed_pending+=$p.archive};continue}
  $chosen=$null
  foreach($h in $hits){if($p.sha256){$a=(Get-FileHash -Algorithm SHA256 $h.FullName).Hash.ToLowerInvariant();if($a -eq $p.sha256.ToLowerInvariant()){$chosen=$h;break}}else{$chosen=$h;break}}
  if(!$chosen){$chosen=$hits[0]}
  $dest=Join-Path $patchDir $p.archive;Copy-Item -Force $chosen.FullName $dest
  $actual=(Get-FileHash -Algorithm SHA256 $dest).Hash.ToLowerInvariant()
  $entry=[ordered]@{id=$p.id;archive=$p.archive;status=$p.status;source=$chosen.FullName;copied_to=$dest;sha256_actual=$actual;sha256_expected=$p.sha256;sha256_ok=$(if($p.sha256){$actual -eq $p.sha256.ToLowerInvariant()}else{$null})}
  if($p.sha256 -and $actual -ne $p.sha256.ToLowerInvariant()){$report.hash_mismatch+=$entry}elseif($p.status -like 'candidate_pending*'){$report.candidate_found+=$entry}else{$report.found+=$entry}
}
foreach($name in @("PATCH_MANIFEST.json","DESKTOP_AI_V4_INSTALL_VERIFY_FIX.md","GRAPHICS_ENGINE_ANALYSIS.md","GRAPHICS_TEAM_ARCHITECTURE.md","NEW_PATCHES_2026-08-28.md")){
  Copy-Item (Join-Path $here $name) $outRoot
}
Copy-Item (Join-Path $here 'TEAM_INTEGRATION_PAYLOAD') $outRoot -Recurse
$reportPath=Join-Path $outRoot 'COLLECTION_REPORT.json';$report|ConvertTo-Json -Depth 8|Set-Content -Encoding UTF8 $reportPath
$zip=$outRoot+'.zip';if(Test-Path $zip){Remove-Item -Force $zip};Compress-Archive -Path (Join-Path $outRoot '*') -DestinationPath $zip -CompressionLevel Optimal
Write-Host "DONE ZIP=$zip";Write-Host "REPORT=$reportPath"
if($report.missing_confirmed_pending.Count){Write-Warning ('Missing confirmed pending: '+($report.missing_confirmed_pending -join ', '))}
if($report.hash_mismatch.Count){Write-Warning 'SHA256 mismatch: do not install affected archives.'}
