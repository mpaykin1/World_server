# Superseded by V4

Use `DESKTOP_AI_V4_INSTALL_VERIFY_FIX.md`.
