#!/usr/bin/env node
'use strict';
const cp=require('child_process'),fs=require('fs'),path=require('path');
const ROOT=process.cwd();
const r=cp.spawnSync(process.execPath,[path.join(ROOT,'scripts','graphics-engine-gap-audit.js'),'--strict'],{cwd:ROOT,encoding:'utf8'});
process.stdout.write(r.stdout||'');process.stderr.write(r.stderr||'');
if(r.status!==0){console.error('[GRAPHICS_TEAM_GATE] FAIL: P0 runtime contracts are not all wired.');process.exit(1)}
const report=JSON.parse(fs.readFileSync(path.join(ROOT,'GRAPHICS_ENGINE_GAP_REPORT.json'),'utf8'));
console.log(`[GRAPHICS_TEAM_GATE] PASS score=${report.scorePercent}%`);
