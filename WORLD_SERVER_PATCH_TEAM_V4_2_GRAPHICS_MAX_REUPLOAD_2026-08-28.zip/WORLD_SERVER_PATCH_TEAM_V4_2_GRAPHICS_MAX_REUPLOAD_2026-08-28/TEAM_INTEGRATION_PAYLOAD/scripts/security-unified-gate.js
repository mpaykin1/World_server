#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process');
const ROOT=process.cwd(), isWin=process.platform==='win32';
function exe(envName,localName,command){
  const e=process.env[envName];
  if(e&&fs.existsSync(e)) return e;
  const l=path.join(ROOT,'.tools','bin',isWin?localName+'.exe':localName);
  if(fs.existsSync(l)) return l;
  const r=cp.spawnSync(isWin?'where':'which',[command],{encoding:'utf8'});
  return r.status===0?r.stdout.trim().split(/\r?\n/)[0]:null;
}
const trivy=exe('TRIVY_BIN','trivy','trivy');
const osv=exe('OSV_SCANNER_BIN','osv-scanner','osv-scanner');
if(!trivy||!osv){console.error('[SECURITY] required scanner missing');process.exit(2)}

const trivyOut=path.join(ROOT,'SECURITY_TRIVY_REPORT.json');
const osvOut=path.join(ROOT,'SECURITY_OSV_REPORT.json');

const t=cp.spawnSync(trivy,['fs','--scanners','vuln,misconfig,secret,license','--format','json','--output',trivyOut,'.'],{cwd:ROOT,encoding:'utf8'});
const o=cp.spawnSync(osv,['scan','source','-r','.','--format','json'],{cwd:ROOT,encoding:'utf8'});
if(o.stdout) fs.writeFileSync(osvOut,o.stdout);
if(t.status===null||t.status>1){console.error('[SECURITY] trivy execution failed',t.stderr||'');process.exit(2)}
if(o.status===null||o.status>1){console.error('[SECURITY] osv execution failed',o.stderr||'');process.exit(2)}

let high=0,critical=0,secrets=0,misconfigHigh=0;
try{
  const j=JSON.parse(fs.readFileSync(trivyOut,'utf8'));
  for(const r of j.Results||[]){
    for(const v of r.Vulnerabilities||[]){
      if(v.Severity==='CRITICAL') critical++;
      else if(v.Severity==='HIGH') high++;
    }
    for(const m of r.Misconfigurations||[]){
      if(m.Severity==='CRITICAL'||m.Severity==='HIGH') misconfigHigh++;
    }
    secrets += (r.Secrets||[]).length;
  }
}catch(e){console.error('[SECURITY] cannot parse trivy JSON',e.message);process.exit(2)}

const strict=process.env.WORLD_SERVER_SECURITY_STRICT==='1'||process.env.CI==='true'||process.env.VERCEL==='1';
const report={
  generatedAt:new Date().toISOString(),strict,
  trivyExit:t.status,osvExit:o.status,
  critical,high,misconfigHigh,secrets,
  osvFindings:o.status===1
};
fs.writeFileSync(path.join(ROOT,'SECURITY_UNIFIED_SUMMARY.json'),JSON.stringify(report,null,2)+'\n');
const findings=critical+high+misconfigHigh+secrets+(o.status===1?1:0);
console.log(`[SECURITY] findings=${findings} strict=${strict}`);
if(strict&&findings>0) process.exit(1);
