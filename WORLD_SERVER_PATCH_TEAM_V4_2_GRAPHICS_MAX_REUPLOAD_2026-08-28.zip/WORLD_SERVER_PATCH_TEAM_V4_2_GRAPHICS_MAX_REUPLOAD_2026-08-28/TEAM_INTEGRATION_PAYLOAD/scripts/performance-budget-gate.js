#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path');
const ROOT=process.cwd();
const BASE=path.join(ROOT,'data','performance-budget-baseline.json');
const REPORT=path.join(ROOT,'PERFORMANCE_BUDGET_REPORT.json');
const roots=['apps','public','shared'].map(x=>path.join(ROOT,x)).filter(fs.existsSync);
const exts=new Set(['.js','.mjs','.cjs','.wasm','.css','.html','.json','.webmanifest']);
const skip=new Set(['node_modules','.git','.tools','.system-integration-backups','.patch-team-backups']);
function walk(dir,out=[]){
  for(const e of fs.readdirSync(dir,{withFileTypes:true})){
    if(skip.has(e.name)) continue;
    const p=path.join(dir,e.name);
    if(e.isDirectory()) walk(p,out);
    else if(exts.has(path.extname(e.name).toLowerCase())) out.push(p);
  }
  return out;
}
const files=roots.flatMap(r=>walk(r));
const groups={js:0,wasm:0,css:0,html:0,json:0,other:0};
let largest={path:null,bytes:0};
for(const f of files){
  const n=fs.statSync(f).size, ext=path.extname(f).toLowerCase();
  const k=['.js','.mjs','.cjs'].includes(ext)?'js':ext==='.wasm'?'wasm':ext==='.css'?'css':ext==='.html'?'html':['.json','.webmanifest'].includes(ext)?'json':'other';
  groups[k]+=n;
  if(n>largest.bytes) largest={path:path.relative(ROOT,f),bytes:n};
}
const current={generatedAt:new Date().toISOString(),files:files.length,groups,largest};
if(process.argv.includes('--capture')){
  fs.mkdirSync(path.dirname(BASE),{recursive:true});
  fs.writeFileSync(BASE,JSON.stringify(current,null,2)+'\n');
  console.log(`[PERF_BUDGET] BASELINE CAPTURED files=${files.length}`);
  process.exit(0);
}
if(!fs.existsSync(BASE)){
  fs.writeFileSync(REPORT,JSON.stringify({pass:false,reason:'baseline_missing',current},null,2)+'\n');
  console.error('[PERF_BUDGET] baseline missing; review current build then run npm run quality:bundle-budget:capture');
  process.exit(2);
}
const base=JSON.parse(fs.readFileSync(BASE,'utf8'));
const limits={js:1.12,wasm:1.15,css:1.12,html:1.12,json:1.15,other:1.15};
const violations=[];
for(const [k,factor] of Object.entries(limits)){
  const old=base.groups?.[k]||0, now=groups[k]||0;
  if(old>0&&now>old*factor) violations.push({group:k,baseline:old,current:now,growth:now/old,limit:factor});
}
const report={pass:violations.length===0,generatedAt:new Date().toISOString(),baseline:base.generatedAt,current,violations};
fs.writeFileSync(REPORT,JSON.stringify(report,null,2)+'\n');
console.log(`[PERF_BUDGET] ${report.pass?'PASS':'FAIL'} violations=${violations.length}`);
if(!report.pass) process.exit(1);
