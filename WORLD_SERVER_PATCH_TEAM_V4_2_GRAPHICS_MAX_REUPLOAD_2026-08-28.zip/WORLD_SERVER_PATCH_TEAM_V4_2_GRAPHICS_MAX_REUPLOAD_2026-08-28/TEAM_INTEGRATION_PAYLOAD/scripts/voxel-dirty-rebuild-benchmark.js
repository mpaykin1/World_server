'use strict';
const fs=require('fs');
const loaded=49;
const reduction=n=>+(100*(1-n/loaded)).toFixed(2);
const report={
  loadedChunks:loaded,
  interior:{rebuilds:1,reductionPercent:reduction(1)},
  edge:{rebuilds:2,reductionPercent:reduction(2)},
  corner:{rebuilds:3,reductionPercent:reduction(3)}
};
fs.writeFileSync('VOXEL_DIRTY_REBUILD_BENCHMARK.json',JSON.stringify(report,null,2)+'\n');
console.log(`[DIRTY_REBUILD] interior=${report.interior.reductionPercent}% edge=${report.edge.reductionPercent}% corner=${report.corner.reductionPercent}%`);
