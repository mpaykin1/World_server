#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process');
const ROOT=process.cwd();
const isWin=process.platform==='win32';
const candidates={
  trivy:[process.env.TRIVY_BIN,path.join(ROOT,'.tools','bin',isWin?'trivy.exe':'trivy'),'trivy'],
  osv:[process.env.OSV_SCANNER_BIN,path.join(ROOT,'.tools','bin',isWin?'osv-scanner.exe':'osv-scanner'),'osv-scanner']
};
function resolve(list){
  for(const p of list){
    if(!p) continue;
    if((p.includes('/')||p.includes('\\')) && fs.existsSync(p)) return p;
    const r=cp.spawnSync(isWin?'where':'which',[p],{encoding:'utf8'});
    if(r.status===0) return r.stdout.trim().split(/\r?\n/)[0];
  }
  return null;
}
function pkgVersion(name){
  try{return require(path.join(ROOT,'node_modules',name,'package.json')).version}catch{return null}
}
const report={
  generatedAt:new Date().toISOString(),
  binaries:{trivy:resolve(candidates.trivy),osvScanner:resolve(candidates.osv)},
  npm:{
    axePlaywright:pkgVersion('@axe-core/playwright'),
    sizeLimit:pkgVersion('size-limit'),
    openFeature:pkgVersion('@openfeature/server-sdk'),
    otelApi:pkgVersion('@opentelemetry/api'),
    otelSdkNode:pkgVersion('@opentelemetry/sdk-node')
  }
};
const required=[
  report.binaries.trivy,report.binaries.osvScanner,
  report.npm.axePlaywright,report.npm.sizeLimit,report.npm.openFeature,report.npm.otelApi
];
report.pass=required.every(Boolean);
report.otelCanary=!!report.npm.otelSdkNode;
fs.writeFileSync(path.join(ROOT,'OSS_TOOL_HEALTH.json'),JSON.stringify(report,null,2)+'\n');
console.log(`[OSS_HEALTH] ${report.pass?'PASS':'FAIL'} otelCanary=${report.otelCanary}`);
if(!report.pass) process.exit(1);
