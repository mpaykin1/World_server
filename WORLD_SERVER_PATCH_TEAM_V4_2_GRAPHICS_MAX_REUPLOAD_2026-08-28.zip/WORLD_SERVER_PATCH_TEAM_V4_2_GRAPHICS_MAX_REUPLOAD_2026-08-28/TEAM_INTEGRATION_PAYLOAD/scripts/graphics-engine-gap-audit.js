#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path');
const ROOT=process.cwd();
const read=p=>{try{return fs.readFileSync(path.join(ROOT,p),'utf8')}catch{return''}};
const exists=p=>fs.existsSync(path.join(ROOT,p));
const c=read('apps/voxel-world/client.js');
const q=read('shared/world-quality-autopilot.js');
const checks={
  voxelClient:!!c,
  dynamicWorldId:/URLSearchParams\(location\.search\).*world|worldId\s*=\s*new URLSearchParams/s.test(c),
  goldenPhysics:/GameGoldenPhysics\.canonicalXZ/.test(c),
  narrativeTheme:/worldTheme|settings\.theme/.test(c),
  worldQualityRenderer:/WorldQualityAutopilot\?*\.registerRenderer|WorldQualityAutopilot\.registerRenderer/.test(c),
  workerMesherFile:exists('apps/voxel-world/chunk-worker.js'),
  workerUsed:/new Worker\(/.test(c),
  greedyMesher:read('apps/voxel-world/chunk-worker.js').includes('greedy2D'),
  localThreePrimary:/\.\/vendor\/three\.module/.test(c)||/from ['"]three['"]/.test(c),
  cdnThreePrimary:/^import .*https:\/\/unpkg\.com\/three/m.test(c),
  adaptiveView:/viewDistance/.test(c)&&/VIEW_MIN|VIEW_MAX/.test(c),
  noHardcodedMainApi:!/(worldId\s*:\s*['"]main['"]|voxel:main)/.test(c),
  visibilityAdapter:/registerVisibilityAdapter/.test(c)||exists('shared/voxel-quality-bridge.js'),
  materialAdapter:/registerMaterialAdapter/.test(c)||exists('shared/voxel-quality-bridge.js'),
  sceneBudgetAdapter:/registerSceneBudgetAdapter/.test(c)||exists('shared/voxel-quality-bridge.js'),
  qualityGpuTiming:q.includes('EXT_disjoint_timer_query_webgl2'),
  qualityLongTasks:q.includes('PerformanceObserver'),
  qualityThermalProxy:q.includes('thermalProxy')
};
const p0=[
  'dynamicWorldId','goldenPhysics','workerMesherFile','workerUsed','greedyMesher',
  'localThreePrimary','adaptiveView','noHardcodedMainApi',
  'visibilityAdapter','materialAdapter','sceneBudgetAdapter'
];
const missing=p0.filter(k=>!checks[k]);
const report={
  schema:'world-server.graphics-gap-audit/v4',
  generatedAt:new Date().toISOString(),
  checks,missingP0:missing,
  passP0:missing.length===0,
  scorePercent:Math.round((p0.length-missing.length)*100/p0.length),
  notes:{
    cdnThreePrimary:checks.cdnThreePrimary?'CDN is still primary; vendor/package should become primary with CDN fallback only.':'OK or not detected',
    qualityAutopilot:'GPU timer/long-task/thermal logic already exists; wire its visibility/material/scene-budget callbacks into voxel runtime.'
  }
};
fs.writeFileSync(path.join(ROOT,'GRAPHICS_ENGINE_GAP_REPORT.json'),JSON.stringify(report,null,2)+'\n');
console.log(`[GRAPHICS_GAP_V4] P0=${report.scorePercent}% missing=${missing.join(',')||'none'}`);
if(process.argv.includes('--strict')&&!report.passP0)process.exit(1);
