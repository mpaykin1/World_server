#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path');
const ROOT=process.cwd(),cfgPath=path.join(ROOT,'data','patch-team-capabilities.json');
if(!fs.existsSync(cfgPath)){console.error('[PATCH_TEAM] missing data/patch-team-capabilities.json');process.exit(2)}
const cfg=JSON.parse(fs.readFileSync(cfgPath,'utf8')),issues=[];
for(const [id,c] of Object.entries(cfg.capabilities||{})){if(!c.provider)issues.push({type:'missing_provider',capability:id});if(!c.contract)issues.push({type:'missing_contract',capability:id})}
const requiredFiles=['scripts/technology-orchestrator.js','scripts/duplicate-system-review.js','scripts/capture-regressions.js','scripts/world-quality-autopilot.js'];
const existing={}; for(const f of requiredFiles) existing[f]=fs.existsSync(path.join(ROOT,f));
if(!existing['scripts/technology-orchestrator.js'])issues.push({type:'missing_existing_master_orchestrator'});
if(!existing['scripts/duplicate-system-review.js'])issues.push({type:'missing_duplicate_guard'});
let pkg={};try{pkg=JSON.parse(fs.readFileSync(path.join(ROOT,'package.json'),'utf8'))}catch{issues.push({type:'package_json_unreadable'})}
for(const s of ['quality:tech-orchestrator','duplicates:check','regressions:capture','quality:world','release:gate']) if(!(pkg.scripts||{})[s])issues.push({type:'missing_existing_gate',script:s});
const report={schema:'world-server.patch-team-report/v2',generatedAt:new Date().toISOString(),capabilities:Object.keys(cfg.capabilities||{}).length,flows:(cfg.cross_system_flows||[]).length,existing,issues,pass:issues.length===0};
fs.writeFileSync(path.join(ROOT,'PATCH_TEAM_REPORT.json'),JSON.stringify(report,null,2)+'\n');
console.log(`[PATCH_TEAM] ${report.pass?'PASS':'FAIL'} capabilities=${report.capabilities} flows=${report.flows} issues=${issues.length}`);if(!report.pass)process.exit(1);
