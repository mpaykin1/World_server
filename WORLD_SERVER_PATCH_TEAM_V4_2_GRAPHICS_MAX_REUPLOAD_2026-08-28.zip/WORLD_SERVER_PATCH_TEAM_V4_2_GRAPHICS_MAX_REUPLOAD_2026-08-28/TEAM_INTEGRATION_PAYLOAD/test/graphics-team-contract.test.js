#!/usr/bin/env node
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const cfg=JSON.parse(fs.readFileSync(path.join(__dirname,'..','data','graphics-team-contracts.json'),'utf8'));
test('graphics team keeps one control plane',()=>assert.match(cfg.canonical_control_plane,/WorldQualityAutopilot/));
test('dynamic world and golden physics are hard guards',()=>{
  assert.equal(cfg.hard_guards.dynamic_world_id,true);
  assert.equal(cfg.hard_guards.golden_physics,true);
});
test('worker greedy meshing and WQA adapters are P0',()=>{
  for(const x of ['worker_greedy_meshing','worldquality_visibility_adapter','worldquality_material_adapter','worldquality_scene_budget_adapter'])assert.ok(cfg.voxel_p0.includes(x));
});
test('GS360 and panorama share the depth engine',()=>assert.ok(cfg.gs360_pixel_team.includes('share_one_depth_anything_engine')));
