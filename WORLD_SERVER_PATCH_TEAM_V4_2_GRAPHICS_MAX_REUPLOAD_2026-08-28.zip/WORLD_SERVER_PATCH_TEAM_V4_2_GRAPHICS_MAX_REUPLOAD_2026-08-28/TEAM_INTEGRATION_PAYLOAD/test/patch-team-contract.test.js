#!/usr/bin/env node
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const cfg=JSON.parse(fs.readFileSync(path.join(__dirname,'..','data','patch-team-capabilities.json'),'utf8'));
test('capabilities have providers/contracts',()=>{for(const [id,c] of Object.entries(cfg.capabilities)){assert.ok(c.provider,id);assert.ok(c.contract,id)}});
test('flows have goals and 2+ stages',()=>{for(const f of cfg.cross_system_flows){assert.ok(f.id);assert.ok(f.goal);assert.ok(f.chain.length>=2)}});
test('existing technology orchestrator remains master',()=>{assert.equal(cfg.master_orchestrator.existing,'scripts/technology-orchestrator.js');assert.equal(cfg.master_orchestrator.must_not_create_second_master_orchestrator,true)});
test('critical safeguards enabled',()=>{for(const k of ['no_duplicate_provider_for_same_capability','cpu_fallback_required_for_heavy_generation','pwa_cache_version_must_change_when_world_assets_change','vercel_function_budget_gate_required','preview_green_before_prod'])assert.equal(cfg.quality_contracts[k],true,k)});
