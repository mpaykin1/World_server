'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const CHUNK=16;
const mod=(n,d)=>((n%d)+d)%d;
function affected(x,z){
  const out=new Set(['0,0']);
  const lx=mod(x,CHUNK),lz=mod(z,CHUNK);
  if(lx===0)out.add('-1,0');
  if(lx===CHUNK-1)out.add('1,0');
  if(lz===0)out.add('0,-1');
  if(lz===CHUNK-1)out.add('0,1');
  return out;
}
test('interior edit rebuilds one chunk',()=>assert.equal(affected(7,7).size,1));
test('edge edit rebuilds at most two chunks',()=>assert.equal(affected(0,7).size,2));
test('corner edit rebuilds at most three chunks',()=>assert.equal(affected(0,0).size,3));
test('dirty rebuild never scales with loaded world size',()=>{
  for(let i=0;i<1000;i++) assert.ok(affected(i%16,(i*7)%16).size<=3);
});
