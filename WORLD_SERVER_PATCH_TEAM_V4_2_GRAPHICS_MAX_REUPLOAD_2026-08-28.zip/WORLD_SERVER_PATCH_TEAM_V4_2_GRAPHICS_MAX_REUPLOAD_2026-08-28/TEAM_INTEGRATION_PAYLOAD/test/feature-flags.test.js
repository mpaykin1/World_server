#!/usr/bin/env node
'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const flags=require('../shared/feature-flags');
test('default canary flags are safe',async()=>{
  const c=flags.readConfig();
  assert.equal(c.patch_team_v3,true);
  assert.equal(c.world_new_provider_canary,false);
  assert.equal(c.otel_canary,false);
});
test('boolean fallback returns deterministic value',async()=>{
  const v=await flags.getBoolean('patch_team_v3',false);
  assert.equal(v,true);
});
