'use strict';
(function(){
  if(window.WorldVoxelQualityBridge) return;
  function install(bindings={}){
    const W=window.WorldQualityAutopilot;
    if(!W) return {installed:false,reason:'WorldQualityAutopilot_missing'};
    const disposers=[];
    if(typeof W.registerVisibilityAdapter==='function'){
      disposers.push(W.registerVisibilityAdapter({
        setVisibilityHz:v=>bindings.setVisibilityHz?.(v),
        setOcclusionHz:v=>bindings.setOcclusionHz?.(v),
        setDetailRadius:v=>bindings.setDetailRadius?.(v),
        setLodBias:v=>bindings.setLodBias?.(v),
        setTextureBudgetScale:v=>bindings.setTextureBudgetScale?.(v)
      }));
    }
    if(typeof W.registerMaterialAdapter==='function'){
      disposers.push(W.registerMaterialAdapter({
        setPbrQuality:v=>bindings.setPbrQuality?.(v),
        setMaterialBudget:v=>bindings.setMaterialBudget?.(v),
        setTextureBudgetScale:v=>bindings.setTextureBudgetScale?.(v),
        setMaterialDetailScale:v=>bindings.setMaterialDetailScale?.(v)
      }));
    }
    if(typeof W.registerSceneBudgetAdapter==='function'){
      disposers.push(W.registerSceneBudgetAdapter({
        setGeometryBudgetScale:v=>bindings.setGeometryBudgetScale?.(v),
        setEffectBudgetScale:v=>bindings.setEffectBudgetScale?.(v),
        setDynamicLightBudget:v=>bindings.setDynamicLightBudget?.(v),
        setShadowQuality:v=>bindings.setShadowQuality?.(v),
        setParticleScale:v=>bindings.setParticleScale?.(v)
      }));
    }
    return {installed:true,dispose(){for(const d of disposers)try{d?.()}catch{}}};
  }
  window.WorldVoxelQualityBridge={version:'4.0.0',install};
})();