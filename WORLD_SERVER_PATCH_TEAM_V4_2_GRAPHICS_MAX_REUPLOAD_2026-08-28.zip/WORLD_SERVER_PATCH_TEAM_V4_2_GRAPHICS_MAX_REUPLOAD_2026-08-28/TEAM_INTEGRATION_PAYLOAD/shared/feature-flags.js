#!/usr/bin/env node
'use strict';
let sdk=null;
try{sdk=require('@openfeature/server-sdk')}catch{}
let initialized=false;
function normalize(raw){
  const source=raw&&typeof raw==='object'?raw:{};
  const out={};
  for(const [k,v] of Object.entries(source)){
    if(typeof v==='boolean'){
      out[k]={variants:{on:true,off:false},disabled:false,defaultVariant:v?'on':'off'};
    }else if(typeof v==='string'){
      out[k]={variants:{value:v},disabled:false,defaultVariant:'value'};
    }else if(typeof v==='number'){
      out[k]={variants:{value:v},disabled:false,defaultVariant:'value'};
    }
  }
  return out;
}
function readConfig(){
  const defaults={
    patch_team_v3:true,
    world_new_provider_canary:false,
    pwa_auto_update:true,
    otel_canary:false
  };
  try{return {...defaults,...JSON.parse(process.env.WORLD_SERVER_FEATURE_FLAGS_JSON||'{}')}}catch{return defaults}
}
async function init(){
  if(initialized) return;
  initialized=true;
  if(!sdk) return;
  const {OpenFeature,TypedInMemoryProvider}=sdk;
  OpenFeature.setProvider(new TypedInMemoryProvider(normalize(readConfig())));
}
async function getBoolean(key,def=false,ctx={}){
  await init();
  if(!sdk){
    const cfg=readConfig(); return typeof cfg[key]==='boolean'?cfg[key]:def;
  }
  return sdk.OpenFeature.getClient('world-server').getBooleanValue(key,def,ctx);
}
module.exports={init,getBoolean,readConfig};
