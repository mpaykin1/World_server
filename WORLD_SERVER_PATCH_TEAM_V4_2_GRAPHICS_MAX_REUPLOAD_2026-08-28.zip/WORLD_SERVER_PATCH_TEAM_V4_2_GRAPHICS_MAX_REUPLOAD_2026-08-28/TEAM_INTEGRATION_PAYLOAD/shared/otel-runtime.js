#!/usr/bin/env node
'use strict';
let api=null; try{api=require('@opentelemetry/api')}catch{}
let sdk=null; try{sdk=require('@opentelemetry/sdk-node')}catch{}
let started=false;
async function initOtel(){
  if(started) return {started:true};
  const enabled=process.env.WORLD_SERVER_OTEL_ENABLED==='1';
  const endpoint=process.env.OTEL_EXPORTER_OTLP_ENDPOINT||process.env.OTEL_EXPORTER_OTLP_TRACES_ENDPOINT;
  if(!enabled) return {started:false,reason:'feature_disabled'};
  if(!endpoint) return {started:false,reason:'endpoint_missing'};
  if(!sdk) return {started:false,reason:'sdk_missing'};
  const nodeSdk=new sdk.NodeSDK();
  await nodeSdk.start();
  started=true;
  return {started:true};
}
function tracer(name='world-server'){
  return api?api.trace.getTracer(name):{startSpan(){return {setAttribute(){},recordException(){},end(){}}}};
}
module.exports={initOtel,tracer};
