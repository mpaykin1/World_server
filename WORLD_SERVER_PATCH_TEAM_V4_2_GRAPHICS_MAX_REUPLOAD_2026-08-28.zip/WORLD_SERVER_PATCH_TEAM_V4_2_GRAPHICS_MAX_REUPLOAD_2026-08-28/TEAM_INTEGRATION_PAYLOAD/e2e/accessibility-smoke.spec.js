const { test, expect } = require('@playwright/test');
const AxeBuilder = require('@axe-core/playwright').default;

const urls = (process.env.ACCESSIBILITY_URLS || process.env.WORLD_SERVER_E2E_URL || 'http://127.0.0.1:3000/')
  .split(',').map(s=>s.trim()).filter(Boolean);

for (const url of urls) {
  test(`accessibility smoke: ${url}`, async ({ page }) => {
    await page.goto(url, { waitUntil: 'networkidle' });
    const results = await new AxeBuilder({ page }).analyze();
    const serious = results.violations.filter(v => v.impact === 'serious' || v.impact === 'critical');
    expect(serious, JSON.stringify(serious, null, 2)).toEqual([]);
  });
}
