# GRAPHICS ENGINE AUDIT — 2026-08-28

## Что реально работает сейчас
- **Three.js/WebGL voxel-runtime**: процедурный voxel terrain, чанки 16×96×16, Standard materials, fog, directional + hemisphere light, soft shadows.
- **Dynamic World Spec** в PR #12: `?world=<id>`, стабильный seed, narrative theme/height/tree/sky settings, реальный `playUrl`.
- **Golden Physics**: canonical XZ movement + step handling.
- **WorldQualityAutopilot V4** уже измеряет FPS EMA, p95 frame time, GPU timer (если доступен), long tasks, heap/device memory и thermal proxy; у него есть SAFE/BALANCED/HIGH/ULTRA budgets.
- Но voxel runtime сейчас использует далеко не весь этот control plane.

## Главные узкие места
### P0. Main-thread chunk meshing
Текущий runtime сканирует блоки/грани и пересобирает геометрию чанка на main thread; после edit может пересобрать также соседние chunks. Это конкурирует с input/physics/render.

**Решение V4:** выборочно перенести из PR #3 worker-side greedy meshing:
- 1 worker mobile / 1–2 desktop;
- transferable typed arrays;
- greedy rectangles для opaque faces;
- blended water/translucent остаются predictable per-face;
- mesh-job dedup/versioning;
- synchronous fallback при Worker failure;
- neighbor seam remesh.

### P0. Fixed render distance
Текущий runtime имеет фиксированный VIEW (2 mobile / 3 desktop).

**Решение:** adaptive `viewDistance` + hysteresis, управляемые **существующим WorldQualityAutopilot**, а не вторым FPS tuner.

### P0. QualityAutopilot не полностью подключён
Autopilot умеет visibility/material/scene budgets, но voxel runtime в основном использует renderer DPR + shadows.

**Решение:** `shared/voxel-quality-bridge.js` из этого пакета + runtime bindings:
- visibility → view distance / chunk load cadence / HLOD;
- geometry budget → mesh concurrency / far chunk detail;
- material/texture budget → far material detail only;
- scene budget → shadows/effects/lights;
- near-player detail never reduced.

### P0. Three.js r165 + CDN
Свежая ветка всё ещё импортирует Three r165 с unpkg как основной источник.

**Решение:** локальный r185; обновление ступенчато r165→r175→r185 с tests после каждого шага. CDN — только emergency fallback.

## P1
- KTX2/Basis GPU-compressed textures for large static/material assets after benchmark.
- meshoptimizer/glTF-Transform for Hunyuan/static GLB, not for live voxel chunks.
- streamed HLOD/spatial chunks for GS/large meshes.
- shared content-addressed cache for depth/panorama/GS products.
- collision/navmesh proxy independent from GS rendering.
- one Asset Registry: source→depth→views→poses→master→LOD/SPZ/SOG.

## P2
- WebGPU renderer only as **canary**, WebGL remains production fallback.
- Optional Video Depth Anything Small for temporal panorama depth.
- optional RIFE only if pixel-edge visual gate proves no blur.
- backend A/B benchmark selector for depth/trainer/renderer on the actual machine.

## Командная архитектура
`World Spec -> Graphics Router -> {Voxel | Pixel360 | GS360 | Godot mesh}`
then all modes share:
`Device Profile -> WorldQualityAutopilot -> Asset Registry -> PWA -> Evidence/Regression Memory`.

No mode gets its own duplicate depth engine, quality orchestrator, cache, or catalog.
