﻿param(
  [string]$RepoPath = "C:\Users\user\Desktop\World_server"
)
$ErrorActionPreference="Stop"
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$payload=Join-Path $here "TEAM_INTEGRATION_PAYLOAD"
if(!(Test-Path -LiteralPath (Join-Path $RepoPath ".git"))){throw "Not a git repo: $RepoPath"}

Push-Location $RepoPath
try{
  $branch=(git branch --show-current).Trim()
  if($branch -eq "master"){
    $new="ai/desktop/patch-team-v3-max-"+(Get-Date -Format "yyyyMMdd-HHmmss")
    git checkout -b $new
    if($LASTEXITCODE -ne 0){throw "Cannot create safe branch"}
  }
  $backup=Join-Path $RepoPath (".patch-team-backups\v3-"+(Get-Date -Format "yyyyMMdd-HHmmss"))
  New-Item -ItemType Directory -Force -Path $backup | Out-Null

  # First preserve all destinations, then copy payload recursively.
  Get-ChildItem -LiteralPath $payload -File -Recurse | ForEach-Object {
    $rel=$_.FullName.Substring($payload.Length).TrimStart('\','/')
    $dst=Join-Path $RepoPath $rel
    if(Test-Path -LiteralPath $dst){
      $bak=Join-Path $backup $rel
      New-Item -ItemType Directory -Force -Path (Split-Path -Parent $bak) | Out-Null
      Copy-Item -Force -LiteralPath $dst -Destination $bak
    }
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
    Copy-Item -Force -LiteralPath $_.FullName -Destination $dst
  }

  # Promote Renovate config to canonical root only if user has no existing Renovate config.
  $renovateCandidates=@("renovate.json","renovate.json5",".renovaterc",".renovaterc.json")
  $hasRenovate=$false
  foreach($r in $renovateCandidates){if(Test-Path -LiteralPath (Join-Path $RepoPath $r)){$hasRenovate=$true}}
  if(-not $hasRenovate){Copy-Item -Force -LiteralPath (Join-Path $payload "config\renovate.json") -Destination (Join-Path $RepoPath "renovate.json")}

  # Extend existing technology orchestrator instead of creating another one.
  $techPath=Join-Path $RepoPath "data\technology-orchestrator.json"
  if(Test-Path -LiteralPath $techPath){
    Copy-Item -Force -LiteralPath $techPath -Destination (Join-Path $backup "technology-orchestrator.json")
    $tech=Get-Content -Raw -LiteralPath $techPath | ConvertFrom-Json
    if(-not ($tech.engines.PSObject.Properties.Name -contains "trivy")){
      $tech.engines | Add-Member -NotePropertyName "trivy" -NotePropertyValue ([pscustomobject]@{
        kind="binary"; binEnv="TRIVY_BIN"; names=@("trivy"); requires=@()
      })
    }
    if(-not ($tech.engines.PSObject.Properties.Name -contains "osv-scanner")){
      $tech.engines | Add-Member -NotePropertyName "osv-scanner" -NotePropertyValue ([pscustomobject]@{
        kind="binary"; binEnv="OSV_SCANNER_BIN"; names=@("osv-scanner"); requires=@()
      })
    }
    $tech | ConvertTo-Json -Depth 20 | Set-Content -Encoding UTF8 -LiteralPath $techPath
  }

  # Extend package.json in-place.
  $pkgPath=Join-Path $RepoPath "package.json"
  Copy-Item -Force -LiteralPath $pkgPath -Destination (Join-Path $backup "package.json")
  $pkg=Get-Content -Raw -LiteralPath $pkgPath | ConvertFrom-Json
  if(-not $pkg.scripts){$pkg|Add-Member -NotePropertyName scripts -NotePropertyValue ([pscustomobject]@{})}
  $scripts=[ordered]@{
    "patches:team:check"="node scripts/patch-team-gate.js && node --test test/patch-team-contract.test.js test/feature-flags.test.js"
    "security:tools"="node scripts/oss-tool-health.js"
    "security:unified"="node scripts/security-unified-gate.js"
    "quality:bundle-budget"="node scripts/performance-budget-gate.js"
    "quality:bundle-budget:capture"="node scripts/performance-budget-gate.js --capture"
    "quality:accessibility"="playwright test e2e/accessibility-smoke.spec.js"
  }
  foreach($k in $scripts.Keys){
    if($pkg.scripts.PSObject.Properties.Name -contains $k){$pkg.scripts.$k=$scripts[$k]}
    else{$pkg.scripts|Add-Member -NotePropertyName $k -NotePropertyValue $scripts[$k]}
  }
  $extra="npm run security:tools && npm run security:unified && npm run quality:bundle-budget && npm run patches:team:check"
  if($pkg.scripts."release:gate" -and $pkg.scripts."release:gate" -notmatch "security:unified"){
    $pkg.scripts."release:gate"=$pkg.scripts."release:gate"+" && "+$extra
  }
  $pkg | ConvertTo-Json -Depth 30 | Set-Content -Encoding UTF8 -LiteralPath $pkgPath

  Write-Host "[MAX] payload installed. Now run INSTALL_OPEN_SOURCE_STACK.bat before gates."
  Write-Host "[MAX] backup=$backup"
} finally{Pop-Location}
