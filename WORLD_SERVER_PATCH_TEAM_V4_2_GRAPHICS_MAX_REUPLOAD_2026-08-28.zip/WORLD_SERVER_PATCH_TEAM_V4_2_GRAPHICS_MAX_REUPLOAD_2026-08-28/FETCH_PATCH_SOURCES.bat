@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0FETCH_PATCH_SOURCES.ps1"
pause
