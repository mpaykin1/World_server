﻿param(
  [string]$RepoPath = "C:\Users\user\Desktop\World_server"
)
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

if (!(Test-Path -LiteralPath $RepoPath)) { throw "Repo not found: $RepoPath" }
$toolsRoot = Join-Path $RepoPath ".tools"
$binRoot = Join-Path $toolsRoot "bin"
$downloadRoot = Join-Path $toolsRoot "downloads"
New-Item -ItemType Directory -Force -Path $binRoot,$downloadRoot | Out-Null

$report = [ordered]@{
  schema = "world-server.oss-install/v3"
  created_at = (Get-Date).ToString("o")
  repo = $RepoPath
  tools = @()
  npm = @()
  warnings = @()
}

function Invoke-GitHubJson([string]$url) {
  $headers = @{
    "User-Agent" = "WorldServer-DesktopAI"
    "Accept" = "application/vnd.github+json"
    "X-GitHub-Api-Version" = "2022-11-28"
  }
  return Invoke-RestMethod -Uri $url -Headers $headers
}

function Get-LatestRelease([string]$repo) {
  return Invoke-GitHubJson "https://api.github.com/repos/$repo/releases/latest"
}

function Get-ShaFromChecksums($release, [string]$assetName) {
  $checks = @($release.assets | Where-Object { $_.name -match '(?i)checksums?\.txt$|sha256sums?\.txt$' } | Select-Object -First 1)
  if ($checks.Count -eq 0) { return $null }
  $tmp = Join-Path $env:TEMP ("ws-checksums-" + [guid]::NewGuid().ToString("N") + ".txt")
  Invoke-WebRequest -Uri $checks[0].browser_download_url -OutFile $tmp
  try {
    foreach ($line in Get-Content -LiteralPath $tmp) {
      if ($line -match ('^\s*([a-fA-F0-9]{64})\s+\*?' + [regex]::Escape($assetName) + '\s*$')) {
        return $Matches[1].ToLowerInvariant()
      }
    }
  } finally { Remove-Item -Force -ErrorAction SilentlyContinue $tmp }
  return $null
}

function Install-GitHubAsset(
  [string]$Id,
  [string]$Repo,
  [string]$AssetRegex,
  [string]$ExeRegex,
  [string]$DestExe
) {
  $release = Get-LatestRelease $Repo
  $asset = @($release.assets | Where-Object { $_.name -match $AssetRegex } | Select-Object -First 1)
  if ($asset.Count -eq 0) { throw "$Id: no asset matching $AssetRegex in release $($release.tag_name)" }
  $asset = $asset[0]
  $download = Join-Path $downloadRoot $asset.name
  Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $download

  $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $download).Hash.ToLowerInvariant()
  $expected = $null
  if ($asset.PSObject.Properties.Name -contains "digest" -and $asset.digest -match '^sha256:([a-fA-F0-9]{64})$') {
    $expected = $Matches[1].ToLowerInvariant()
  }
  if (-not $expected) { $expected = Get-ShaFromChecksums $release $asset.name }
  if (-not $expected) { throw "$Id: release provides no verifiable SHA-256 for $($asset.name)" }
  if ($actual -ne $expected) { throw "$Id: SHA256 mismatch expected=$expected actual=$actual" }

  $target = Join-Path $binRoot $DestExe
  if ($asset.name -match '\.zip$') {
    $extract = Join-Path $downloadRoot ($Id + "-" + [guid]::NewGuid().ToString("N"))
    Expand-Archive -LiteralPath $download -DestinationPath $extract -Force
    $exe = Get-ChildItem -LiteralPath $extract -File -Recurse | Where-Object { $_.Name -match $ExeRegex } | Select-Object -First 1
    if (-not $exe) { throw "$Id: executable not found after extract" }
    Copy-Item -Force -LiteralPath $exe.FullName -Destination $target
    Remove-Item -Recurse -Force -LiteralPath $extract
  } else {
    Copy-Item -Force -LiteralPath $download -Destination $target
  }

  $entry = [ordered]@{
    id = $Id
    repo = $Repo
    version = $release.tag_name
    asset = $asset.name
    sha256 = $actual
    executable = $target
  }
  $script:report.tools += $entry
  return $target
}

function Npm-Latest([string]$pkg) {
  Push-Location $RepoPath
  try {
    $v = (& npm view $pkg version 2>$null | Select-Object -Last 1).Trim()
    if (-not $v) { throw "npm view failed for $pkg" }
    return $v
  } finally { Pop-Location }
}

function Install-NpmExact([string]$pkg, [string]$mode) {
  $v = Npm-Latest $pkg
  Push-Location $RepoPath
  try {
    if ($mode -eq "dev") {
      & npm install --save-dev "$pkg@$v"
    } elseif ($mode -eq "optional") {
      & npm install --save-optional "$pkg@$v"
    } else {
      & npm install --save "$pkg@$v"
    }
    if ($LASTEXITCODE -ne 0) { throw "npm install failed: $pkg@$v" }
  } finally { Pop-Location }
  $script:report.npm += [ordered]@{ package=$pkg; version=$v; mode=$mode }
}

# Official binaries; latest stable is resolved at install time.
$trivy = Install-GitHubAsset "trivy" "aquasecurity/trivy" '(?i)Windows-64bit\.zip$' '^trivy\.exe$' 'trivy.exe'
$osv = Install-GitHubAsset "osv-scanner" "google/osv-scanner" '(?i)windows.*amd64.*\.exe$' '^osv-scanner.*\.exe$' 'osv-scanner.exe'

$env:TRIVY_BIN = $trivy
$env:OSV_SCANNER_BIN = $osv
[Environment]::SetEnvironmentVariable("TRIVY_BIN", $trivy, "User")
[Environment]::SetEnvironmentVariable("OSV_SCANNER_BIN", $osv, "User")

# Exact latest npm versions at installation time.
Install-NpmExact "@axe-core/playwright" "dev"
Install-NpmExact "size-limit" "dev"
Install-NpmExact "@openfeature/server-sdk" "prod"
Install-NpmExact "@opentelemetry/api" "prod"

# NodeSDK is intentionally optional/canary because the package is experimental.
try {
  Install-NpmExact "@opentelemetry/sdk-node" "optional"
} catch {
  $report.warnings += "OpenTelemetry SDK canary not installed: $($_.Exception.Message)"
}

$reportPath = Join-Path $RepoPath "OSS_INSTALL_REPORT.json"
$report | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 -LiteralPath $reportPath
Write-Host "[OSS] installed. report=$reportPath"
