# PATCH STATUS V4 — 2026-08-28

## New latest versions
- Pixel Panorama 360: **V5** (V4 excluded).
- GS360 CPU Quality: **V7** (V6 excluded).

## New source integration
- PR #12: current dynamic World Spec -> voxel runtime; prefer over older overlapping Home/Vercel implementation.
- PR #3: selective renderer acceleration source only.

## Graphics P0
- Worker greedy meshing: packaged source-fetch + contract/gate; real repo port still required.
- Full WQA visibility/material/scene-budget wiring: bridge packaged; real client binding required.
- Three.js r185 staged migration: automation packaged; real browser verification required.
