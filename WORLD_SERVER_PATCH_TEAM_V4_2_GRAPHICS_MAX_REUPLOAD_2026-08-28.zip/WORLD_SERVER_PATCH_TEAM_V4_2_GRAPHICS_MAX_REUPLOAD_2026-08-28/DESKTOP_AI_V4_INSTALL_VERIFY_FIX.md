# DESKTOP AI — WORLD SERVER PATCH TEAM V4 GRAPHICS MAX
## Find newest -> collect -> compare -> selective merge -> wire as one team -> benchmark -> fix until PASS

Default repo:
`C:\Users\user\Desktop\World_server`

## 0. Non-negotiable
- Never push directly to `master`.
- Preserve other agents' uncommitted/branch work.
- Reuse existing orchestrator, quality control plane, Depth Anything, cache, PWA, catalog, Sentry, Playwright and regression knowledge.
- No duplicate renderer-control plane / depth stack / job DB / catalog.
- Do not reduce near-player graphics or delete working effects to gain FPS.
- CPU fallback mandatory; GPU-only feature optional.
- Root cause + regression test for every real failure.
- 100% Production only after real production E2E.

## 1. Inventory FIRST
Run:
```bat
git status
git branch --show-current
git fetch origin --prune
npm run tech:audit
npm run tech:health
npm run duplicates:check
```
Read:
- `PATCH_MANIFEST.json`
- `NEW_PATCHES_2026-08-28.md`
- `GRAPHICS_ENGINE_ANALYSIS.md`
- `GRAPHICS_TEAM_ARCHITECTURE.md`

## 2. Collect newest ZIPs
Run:
```bat
COLLECT_AND_BUILD.bat
```
V4 MUST prefer:
- `WORLD_SERVER_PIXEL_PANORAMA_360_V5.zip`, never V4;
- `WORLD_SERVER_3DGS_360_CPU_QUALITY_V7.zip`, never V6.

Known Pixel V5 SHA-256 MUST match the manifest.
If GS V7 has no trusted checksum file locally, calculate and record SHA-256 before extraction, but do not invent an expected checksum.

## 3. Fetch current Git patch sources
Run:
```bat
FETCH_PATCH_SOURCES.bat
```
This fetches:
- PR #12 current dynamic World Spec/voxel integration;
- PR #3 acceleration source.

Do NOT merge PR #3 wholesale.
Compare current branch/PR12 first.

## 4. Install V3 base + V4 graphics layer
If V3 MAX was not already installed, use its existing installer first.
Then:
```bat
02_INSTALL_GRAPHICS_TEAM_LAYER.bat
npm run graphics:gap
```
`graphics:gap` is an audit; a FAIL/missing P0 before porting is expected.

## 5. Selective voxel acceleration port — P0
Use PR3 extracted standalone files as source:
- `apps/voxel-world/chunk-worker.js`
- `apps/voxel-world/texture-pack-runtime.js`
- related regression tests.

Merge the **concepts** from the PR3 client diff into the newest current client.

MUST preserve from PR12/current:
- `?world=<id>`;
- every `/api/voxel` call uses the dynamic `worldId`;
- realtime channel uses `voxel:${worldId}`;
- World Spec theme/seed/height/tree/sky settings;
- `GameGoldenPhysics.canonicalXZ`;
- latest movement/step/collision logic.

MUST add:
- Web Worker greedy meshing;
- transferable typed arrays;
- mesh job versioning/dedup;
- worker failure -> sync fallback;
- adaptive view distance with hysteresis;
- authoritative chunk resync;
- no full main-thread mesh rebuild on every routine chunk load;
- mesh ms / triangle / draw-call metrics.

Then:
```bat
node --test test/chunk-worker.test.js
npm run check
npm run graphics:gap
```

## 6. Connect the FULL existing WorldQualityAutopilot
Include `shared/voxel-quality-bridge.js` in voxel runtime and bind it to actual mutable runtime state.

Do NOT create a second FPS tuner.

Bindings:
- `setDetailRadius` -> adaptive view distance / near-far detail;
- `setLodBias` -> HLOD/mesh detail bias;
- `setGeometryBudgetScale` -> mesh concurrency/far geometry only;
- `setTextureBudgetScale` -> far textures/atlas residency only;
- `setMaterialDetailScale` -> far material features;
- `setShadowQuality` -> existing shadow setting;
- `setEffectBudgetScale` -> secondary effects;
- `setVisibilityHz` / `setOcclusionHz` -> visibility work cadence.

Guard: near-player hero area remains maximum currently supported quality.

## 7. Three.js r165 -> r185
Current stable target in this package: r185.

Run first:
```powershell
powershell -ExecutionPolicy Bypass -File .\MIGRATE_THREE_TO_R185.ps1 -RepoPath C:\Users\user\Desktop\World_server
```
That is dry-run.

After branch is clean and reviewed:
```powershell
powershell -ExecutionPolicy Bypass -File .\MIGRATE_THREE_TO_R185.ps1 -RepoPath C:\Users\user\Desktop\World_server -Apply
```
It tests r175 then r185.

After r185:
- switch voxel import to LOCAL vendor first;
- CDN only fallback;
- keep Three MIT license beside vendor;
- run Playwright desktop + mobile WebKit;
- compare screenshots/perceptual baseline;
- check transparency/water/shadows/colors/input.

If any regression: identify exact migration step/API cause; fix or rollback. Do not skip straight across failed tests.

## 8. Graphics OSS tools
Run only after checking duplicates:
```powershell
powershell -ExecutionPolicy Bypass -File .\INSTALL_GRAPHICS_OSS.ps1 -RepoPath C:\Users\user\Desktop\World_server
```
It adds:
- `meshoptimizer`;
- `@gltf-transform/cli`;
- `@playcanvas/splat-transform`.

Use them as:
- meshoptimizer/glTF-Transform -> offline static Hunyuan/GLB optimization with visual/size/load benchmark;
- SplatTransform -> GS V7 derived SPZ/SOG/LOD; never replace/delete the master automatically.

### Basis/KTX2
Optional P1, not blind auto-install. Basis v2.50 is very fresh. Pin a tested commit/release, encode candidate textures, then compare:
- visual SSIM/perceptual;
- GPU upload time;
- RAM/VRAM;
- download size;
- mobile decode/start time.
Only promote if better without visible degradation.

### Video Depth Anything
Optional adapter for Pixel V5 temporal depth.
Prefer **Small** because upstream licenses Small Apache-2.0; Base/Large are non-commercial without separate decision.
Benchmark CPU before enabling. Core Pixel V5 must still work without it.

### RIFE
Optional only. Never interpolate pixel art if crisp-edge gate degrades.

### WebGPU
Canary only. WebGL is production fallback until the exact app passes all visual/mobile/device gates.

## 9. Install Pixel Panorama V5
Use its own V5 Desktop AI instruction.
Important shared-team rules:
- reuse existing DepthAnythingEngine;
- use existing queue/cache/asset registry where compatible;
- multires/device adaptive profiles connect to WorldQualityAutopilot;
- PWA cache only after certification;
- run Storage + metadata integrity checks together.

Required:
```bat
npm run panorama360:contract
npm run panorama360:release:gate
npm run panorama360:e2e
npm run panorama360:e2e:mobile
npm run panorama360:visual
```

## 10. Install GS360 V7
Use its V7 instruction.
Shared rules:
- one Depth Anything adapter/cache with Panorama;
- use SplatTransform from canonical tool stack;
- real trainer + renderer + holdout visual evidence before `accurate ready`;
- CPU budget/plateau stop;
- spatial LOD registered in shared Asset Registry;
- collision/navmesh is a separate proxy, not inferred from splat draw result.

Run all V7 health/system/doctor/visual gates.

## 11. Graphics Router
Build/extend ONE server-side routing contract:
Input:
- world spec;
- source assets;
- desired quality;
- time budget;
- device profile.

Route:
- instant/interactive -> voxel;
- lightweight immersive -> Pixel360;
- strong multi-view/reconstruction source -> GS360;
- high-detail prepared mesh -> existing Godot/mesh path.

Never route a low device to an impossible high-cost renderer without a fallback representation.

## 12. Golden cross-patch E2E
Automate:
1. Questionnaire -> World Spec.
2. Create dynamic voxel world -> unique `playUrl`.
3. Walk/jump/collide/stairs.
4. Worker meshing active, no main-thread stall regression.
5. Quality tier changes actually alter view/geometry budgets.
6. CharacterForge character can use shared motion if present.
7. Build a Pixel V5 candidate from an image/APNG source.
8. Build GS V7 approximate candidate from a valid source.
9. Both use one canonical depth/cache path.
10. Home/catalog sees only certified outputs.
11. PWA update/cache after certification.
12. Desktop Chromium + mobile WebKit.
13. Offline/reconnect/reload.
14. Multi-user public parity.
15. Preview -> only then Production smoke.

## 13. Required gates
Run every applicable existing gate plus:
```bat
npm run graphics:team:test
npm run graphics:gap
npm run graphics:team:gate
npm run patches:team:check
npm run security:tools
npm run security:unified
npm run duplicates:check
npm run contracts:check
npm run tech:audit
npm run tech:health
npm run quality:tech-orchestrator
npm run check
npm run golden:check
npm run quality:regression
npm run quality:perceptual
npm run quality:world:full
npm run quality:bundle-budget
npm run quality:accessibility
npm run release:gate
```

## 14. Performance acceptance — measure, don't guess
Collect per device/profile:
- FPS average + p95/p99 frame time;
- GPU ms when supported;
- long-task ratio;
- JS heap/memory pressure;
- draw calls/triangles;
- average/p95 chunk mesh ms;
- worker queue depth;
- initial interactive time;
- world asset bytes;
- network bytes;
- Pixel panorama first-frame/first-tile;
- GS LOD first-visible time.

Targets are adaptive, but no promotion if the new version is slower AND not measurably better visually.

## 15. Self-healing
For every failure:
`reproduce -> evidence -> root cause -> safe fix -> regression test -> targeted gate -> full applicable gate -> persist knowledge`.

If another AI is actively editing the same files:
- do not overwrite;
- work on a separate branch/staging patch;
- integrate only after comparing both solutions.

## 16. Final report — four separate percentages
- Patch artifact readiness %
- Installed on real repo %
- Cross-patch integration verified %
- Production E2E verified %

Also include:
- exact versions/SHA;
- INSTALLED / SKIP_SUPERSEDED / BLOCKED;
- Three migration step results;
- worker/greedy meshing stats;
- FPS/p95/draw calls/mesh ms before→after;
- desktop/mobile results;
- Pixel V5/GS V7 certification status;
- branch/commit/PR/Preview/Production.
