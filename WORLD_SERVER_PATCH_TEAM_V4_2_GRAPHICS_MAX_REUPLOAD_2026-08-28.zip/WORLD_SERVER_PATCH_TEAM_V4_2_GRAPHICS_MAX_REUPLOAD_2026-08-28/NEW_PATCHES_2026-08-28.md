# NEW PATCHES / SOURCES FOUND SINCE V3

## 1. WORLD_SERVER_PIXEL_PANORAMA_360_V5.zip
- replaces V4;
- known SHA-256: `02d1a34b910122fc7f78406b3da8e8292f628efb7320fa5f4b474588c39bb162`;
- code readiness 99%, local integration 98%, estimated pre-live E2E 96%;
- live Supabase/worker/mobile/Preview/Production still required.

## 2. WORLD_SERVER_3DGS_360_CPU_QUALITY_V7.zip
- replaces V6;
- 13 Python regression + 15 contract checks = 28 PASS;
- live World_server and Windows COLMAP/depth/trainer/renderer certification still required.

## 3. Git source: PR #12
Use as current corrected integration source for:
- World Spec -> dynamic voxel world;
- `worldId`, seed/theme/settings;
- `playUrl`;
- corrected Vercel function consolidation and Home/backend work.
Do not overwrite it with older Vercel/Home patches.

## 4. Git source: PR #3 — selective only
Not new chronologically, but newly identified as the best reusable acceleration source.
Port only:
- worker greedy meshing;
- adaptive view/render scale concepts;
- texture-pack runtime;
- authoritative resync;
- tests/performance HUD.
Never port its old `worldId:'main'` or old physics wholesale.
