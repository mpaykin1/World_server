#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process');
const ROOT=__dirname;
const required=[
  'TEAM_INTEGRATION_PAYLOAD/data/patch-team-capabilities.json',
  'TEAM_INTEGRATION_PAYLOAD/scripts/patch-team-gate.js',
  'TEAM_INTEGRATION_PAYLOAD/scripts/oss-tool-health.js',
  'TEAM_INTEGRATION_PAYLOAD/scripts/security-unified-gate.js',
  'TEAM_INTEGRATION_PAYLOAD/scripts/performance-budget-gate.js',
  'TEAM_INTEGRATION_PAYLOAD/shared/feature-flags.js',
  'TEAM_INTEGRATION_PAYLOAD/shared/otel-runtime.js',
  'TEAM_INTEGRATION_PAYLOAD/e2e/accessibility-smoke.spec.js',
  'TEAM_INTEGRATION_PAYLOAD/test/feature-flags.test.js',
  'INSTALL_OPEN_SOURCE_STACK.ps1',
  '01_INSTALL_MAX_STACK.ps1',
  'DESKTOP_AI_MAX_INSTALL_VERIFY_FIX.md'
];
const missing=required.filter(p=>!fs.existsSync(path.join(ROOT,p)));
const syntax=[];
for(const rel of required.filter(x=>x.endsWith('.js'))){
  const r=cp.spawnSync(process.execPath,['--check',path.join(ROOT,rel)],{encoding:'utf8'});
  if(r.status!==0) syntax.push({file:rel,error:r.stderr});
}
const tests=cp.spawnSync(process.execPath,['--test',
  path.join(ROOT,'TEAM_INTEGRATION_PAYLOAD/test/patch-team-contract.test.js'),
  path.join(ROOT,'TEAM_INTEGRATION_PAYLOAD/test/feature-flags.test.js')
],{encoding:'utf8',cwd:ROOT});
const result={
  pass:missing.length===0&&syntax.length===0&&tests.status===0,
  requiredFiles:required.length,missing,syntax,
  unitTestsExit:tests.status,
  unitTestsStdout:tests.stdout
};
fs.writeFileSync(path.join(ROOT,'MAX_PACKAGE_SELFTEST.json'),JSON.stringify(result,null,2)+'\n');
console.log(`[MAX_PACKAGE] ${result.pass?'PASS':'FAIL'} files=${required.length} unitExit=${tests.status}`);
if(!result.pass) process.exit(1);
