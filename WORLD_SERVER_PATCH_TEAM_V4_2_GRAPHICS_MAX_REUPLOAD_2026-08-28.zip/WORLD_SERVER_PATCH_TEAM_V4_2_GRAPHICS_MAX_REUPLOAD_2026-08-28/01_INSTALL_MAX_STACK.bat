@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp001_INSTALL_MAX_STACK.ps1"
pause
