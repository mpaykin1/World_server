﻿param([string]$RepoPath="C:\Users\user\Desktop\World_server")
$ErrorActionPreference="Stop"
if(!(Test-Path -LiteralPath (Join-Path $RepoPath "package.json"))){throw "package.json missing"}
Push-Location $RepoPath
try{
  function ExactLatest($pkg,$mode="dev"){
    $v=(npm view $pkg version|Select-Object -Last 1).Trim()
    if(!$v){throw "Cannot resolve $pkg"}
    if($mode -eq "prod"){npm install --save-exact ("$pkg@$v")}else{npm install --save-dev --save-exact ("$pkg@$v")}
    if($LASTEXITCODE -ne 0){throw "npm install failed: $pkg@$v"}
    Write-Host "[GRAPHICS_OSS] $pkg@$v"
  }
  # Offline/static mesh optimization. Use only on assets where before/after visual + size/load benchmark passes.
  ExactLatest "meshoptimizer" "prod"
  # CLI for deterministic glTF optimization; never overwrite master asset without rollback.
  ExactLatest "@gltf-transform/cli" "dev"
  # GS360 V7 can use the same canonical SplatTransform instead of another splat converter.
  ExactLatest "@playcanvas/splat-transform" "dev"
  Write-Host "[GRAPHICS_OSS] installed package tools. Basis/KTX2 encoder and Video Depth Anything stay optional and require separate benchmark/license/runtime checks."
} finally {Pop-Location}
