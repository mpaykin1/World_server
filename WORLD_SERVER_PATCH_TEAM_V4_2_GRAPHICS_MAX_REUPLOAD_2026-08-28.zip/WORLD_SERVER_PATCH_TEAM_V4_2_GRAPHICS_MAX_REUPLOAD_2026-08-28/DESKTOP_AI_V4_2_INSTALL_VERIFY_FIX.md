# DESKTOP AI — V4.2 GRAPHICS MAX REUPLOAD

Target repo:
C:\Users\user\Desktop\World_server

## First
1. Read current AGENTS.md / WORK_IN_PROGRESS.md / package.json.
2. git status; never overwrite another AI's dirty work.
3. Work on a separate branch.
4. Current Git code wins over older archive code.

## Collect exact latest child ZIPs
Run COLLECT_AND_BUILD.bat already included in this package.
Search Desktop / Downloads / Documents / OneDrive.
Use ONLY the latest names listed in PATCH_MANIFEST_V4_2_REUPLOAD.json.
Never substitute an older version.

## Integration order
Graphics Superstack V3
-> Open Source Team V4
-> Vercel Budget V5
-> Quality V11 + World Quality V6
-> Mesh AAA V12 + Texture V10 + Procedural V10
-> Motion Team V4 + CharacterForge V3
-> Pixel Animation V3 + APNG V3
-> Ink V4 / DreamFog v2 / Dark Voxel v3
-> Video2Game V5 / Pixel3DGS V6
-> Pixel Panorama V5 + GS360 V7
-> User Reality Gate V1
-> PWA last if latest PWA exists and is not superseded.

## Voxel P0
Preserve:
- dynamic worldId / World Spec
- GameGoldenPhysics
- mobile controls
- current PR/newer branch fixes

Implement/verify:
- Web Worker greedy meshing
- mesh job versioning + stale cancellation
- sync fallback
- dirty-chunk rebuild only
- adaptive view distance through the existing WorldQualityAutopilot
- local Three.js primary, CDN fallback
- full visibility/material/scene budget adapters

Dirty chunk rule:
interior = 1 chunk
edge <= 2
corner <= 3
never rebuild unrelated loaded chunks.

Run:
node --test TEAM_INTEGRATION_PAYLOAD/test/voxel-dirty-chunk-contract.test.js
node TEAM_INTEGRATION_PAYLOAD/scripts/voxel-dirty-rebuild-benchmark.js

## Every error
reproduce -> evidence -> root cause -> smallest safe fix -> regression test -> targeted tests -> release gates.
Do not disable gates or lower near-player visual quality.

## Final gates
Run every applicable existing:
npm run check
npm run release:gate
npm run duplicates:check
npm run contracts:check
npm run tech:audit
npm run tech:health
npm run quality:world:full
npm run quality:perceptual
npm run quality:accessibility
Playwright desktop + mobile WebKit
Lighthouse
security/SBOM
Vercel function budget
Preview then Production smoke.

Report four separate percentages:
artifact / installed / integration verified / production E2E.
Never call the last three 100 without real evidence.
