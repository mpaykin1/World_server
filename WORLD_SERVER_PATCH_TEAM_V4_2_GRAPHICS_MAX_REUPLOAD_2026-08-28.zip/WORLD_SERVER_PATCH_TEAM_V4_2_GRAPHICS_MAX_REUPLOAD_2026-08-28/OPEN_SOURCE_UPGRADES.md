# Бесплатные open-source усиления

## A — внедрить, если отсутствуют
- **Trivy** — https://github.com/aquasecurity/trivy — vulnerabilities, secrets, misconfiguration, licenses, SBOM. Последний stable release, checksum verification.
- **OSV-Scanner** — https://github.com/google/osv-scanner — dependency vulnerability specialist для npm/python/других экосистем.

## B — очень полезно
- **Renovate** — https://github.com/renovatebot/renovate — auto-PR dependency updates; major не auto-merge; любой PR проходит release gates.
- **@axe-core/playwright** — accessibility regression внутри уже существующего Playwright.
- **size-limit** — JS/WASM/PWA/world entry budgets. Не снижать качество графики; оптимизировать splitting/compression/cache/dedup.

## C — только если нет аналога
- **OpenFeature** — https://github.com/open-feature/js-sdk — единый feature-flag API для canary/shadow/rollback.
- **OpenTelemetry JS** — https://github.com/open-telemetry/opentelemetry-js — server-side traces/metrics; дополняет Sentry, не дублирует browser error/replay.

## Новые системные функции
- capability registry + contracts;
- automatic supersession detector;
- compatibility matrix browser/mobile/PWA/CPU;
- shadow/canary provider promotion;
- asset provenance + SHA-256;
- golden E2E: character -> animation -> world -> catalog -> PWA -> Preview -> Production smoke;
- failure quarantine: проблемный provider выключается flag-ом, остальные продолжают работать.


# V4 graphics additions
- **Three.js r185**: production target after staged r165→r175→r185 migration; local primary, CDN fallback only.
- **meshoptimizer**: offline static mesh/meshlet optimization. Use before/after visual+load benchmark.
- **@gltf-transform/cli**: deterministic glTF optimization pipeline; preserve master source + rollback.
- **@playcanvas/splat-transform**: canonical GS derived SPZ/SOG/LOD converter; share with GS360 V7.
- **Basis/KTX2**: P1 candidate only after mobile decode/visual/VRAM benchmark; v2.50 is fresh.
- **Video Depth Anything Small**: optional Pixel V5 temporal-depth adapter; Small is Apache-2.0 upstream.
- **WebGPU**: canary only; WebGL remains mandatory fallback.
