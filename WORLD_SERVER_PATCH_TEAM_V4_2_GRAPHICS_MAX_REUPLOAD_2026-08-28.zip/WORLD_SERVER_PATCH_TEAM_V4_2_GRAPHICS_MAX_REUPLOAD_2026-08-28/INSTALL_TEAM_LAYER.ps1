﻿param([string]$RepoPath="C:\Users\user\Desktop\World_server")
$ErrorActionPreference="Stop"
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$payload=Join-Path $here "TEAM_INTEGRATION_PAYLOAD"
if(!(Test-Path -LiteralPath $RepoPath)){throw "Repo not found: $RepoPath"}
if(!(Test-Path -LiteralPath (Join-Path $RepoPath ".git"))){throw "Not a git repo: $RepoPath"}
Push-Location $RepoPath
try {
  git status --porcelain | Out-Host
  $head=(git rev-parse HEAD).Trim();$branch=(git branch --show-current).Trim();Write-Host "[TEAM] branch=$branch head=$head"
  if($branch -eq "master"){$new="ai/desktop/patch-team-v2-"+(Get-Date -Format "yyyyMMdd-HHmmss");git checkout -b $new;if($LASTEXITCODE -ne 0){throw "Cannot create safe branch"}}
  $backup=Join-Path $RepoPath (".patch-team-backups\"+(Get-Date -Format "yyyyMMdd-HHmmss"));New-Item -ItemType Directory -Force -Path $backup|Out-Null
  $targets=@(@{s="data\patch-team-capabilities.json";d="data\patch-team-capabilities.json"},@{s="scripts\patch-team-gate.js";d="scripts\patch-team-gate.js"},@{s="test\patch-team-contract.test.js";d="test\patch-team-contract.test.js"})
  foreach($t in $targets){$dst=Join-Path $RepoPath $t.d;if(Test-Path $dst){$bak=Join-Path $backup $t.d;New-Item -ItemType Directory -Force -Path (Split-Path -Parent $bak)|Out-Null;Copy-Item -Force $dst $bak};New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst)|Out-Null;Copy-Item -Force (Join-Path $payload $t.s) $dst}
  $pkgPath=Join-Path $RepoPath "package.json";Copy-Item -Force $pkgPath (Join-Path $backup "package.json");$pkg=Get-Content -Raw $pkgPath|ConvertFrom-Json
  if(-not ($pkg.scripts.PSObject.Properties.Name -contains "patches:team:check")){$pkg.scripts|Add-Member -NotePropertyName "patches:team:check" -NotePropertyValue "node scripts/patch-team-gate.js && node --test test/patch-team-contract.test.js"}else{$pkg.scripts."patches:team:check"="node scripts/patch-team-gate.js && node --test test/patch-team-contract.test.js"}
  if($pkg.scripts."release:gate" -and $pkg.scripts."release:gate" -notmatch "patches:team:check"){$pkg.scripts."release:gate"=$pkg.scripts."release:gate"+" && npm run patches:team:check"}
  $pkg|ConvertTo-Json -Depth 30|Set-Content -Encoding UTF8 $pkgPath
  npm run patches:team:check;if($LASTEXITCODE -ne 0){throw "Patch-team gate failed"}
  Write-Host "[TEAM] PASS backup=$backup"
} finally { Pop-Location }
