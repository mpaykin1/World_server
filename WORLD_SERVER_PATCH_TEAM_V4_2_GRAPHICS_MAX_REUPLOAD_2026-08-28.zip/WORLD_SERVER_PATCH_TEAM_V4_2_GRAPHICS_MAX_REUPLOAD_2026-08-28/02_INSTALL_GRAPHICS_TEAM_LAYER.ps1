﻿param([string]$RepoPath="C:\Users\user\Desktop\World_server")
$ErrorActionPreference="Stop"
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$payload=Join-Path $here "TEAM_INTEGRATION_PAYLOAD"
if(!(Test-Path -LiteralPath (Join-Path $RepoPath ".git"))){throw "Not a git repo: $RepoPath"}
Push-Location $RepoPath
try{
  $branch=(git branch --show-current).Trim()
  if($branch -eq "master"){
    $b="ai/desktop/patch-team-v4-graphics-"+(Get-Date -Format "yyyyMMdd-HHmmss")
    git checkout -b $b
    if($LASTEXITCODE -ne 0){throw "branch creation failed"}
  }
  $backup=Join-Path $RepoPath (".patch-team-backups\v4-graphics-"+(Get-Date -Format "yyyyMMdd-HHmmss"))
  New-Item -ItemType Directory -Force -Path $backup|Out-Null

  $copy=@(
    "data\graphics-team-contracts.json",
    "shared\voxel-quality-bridge.js",
    "scripts\graphics-engine-gap-audit.js",
    "scripts\graphics-team-gate.js",
    "test\graphics-team-contract.test.js"
  )
  foreach($rel in $copy){
    $src=Join-Path $payload $rel;$dst=Join-Path $RepoPath $rel
    if(Test-Path -LiteralPath $dst){
      $bak=Join-Path $backup $rel;New-Item -ItemType Directory -Force -Path (Split-Path -Parent $bak)|Out-Null
      Copy-Item -Force $dst $bak
    }
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst)|Out-Null
    Copy-Item -Force $src $dst
  }

  $pkgPath=Join-Path $RepoPath "package.json"
  Copy-Item -Force $pkgPath (Join-Path $backup "package.json")
  $pkg=Get-Content -Raw $pkgPath|ConvertFrom-Json
  if(-not $pkg.scripts){$pkg|Add-Member -NotePropertyName scripts -NotePropertyValue ([pscustomobject]@{})}
  $pairs=[ordered]@{
    "graphics:gap"="node scripts/graphics-engine-gap-audit.js"
    "graphics:team:gate"="node scripts/graphics-team-gate.js"
    "graphics:team:test"="node --test test/graphics-team-contract.test.js"
  }
  foreach($k in $pairs.Keys){
    if($pkg.scripts.PSObject.Properties.Name -contains $k){$pkg.scripts.$k=$pairs[$k]}
    else{$pkg.scripts|Add-Member -NotePropertyName $k -NotePropertyValue $pairs[$k]}
  }
  if($pkg.scripts."release:gate" -and $pkg.scripts."release:gate" -notmatch "graphics:team:gate"){
    $pkg.scripts."release:gate"=$pkg.scripts."release:gate"+" && npm run graphics:team:gate"
  }
  $pkg|ConvertTo-Json -Depth 30|Set-Content -Encoding UTF8 $pkgPath

  npm run graphics:team:test
  if($LASTEXITCODE -ne 0){throw "graphics team contract test failed"}
  npm run graphics:gap
  Write-Host "[V4] layer installed. graphics:gap may report missing P0 until Desktop AI ports/selectively wires acceleration; this is expected before completion."
  Write-Host "[V4] backup=$backup"
} finally {Pop-Location}
