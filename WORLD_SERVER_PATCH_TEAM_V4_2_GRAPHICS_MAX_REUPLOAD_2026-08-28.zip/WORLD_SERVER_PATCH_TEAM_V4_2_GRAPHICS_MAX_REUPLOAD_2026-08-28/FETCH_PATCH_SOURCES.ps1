﻿param(
  [string]$RepoPath="C:\Users\user\Desktop\World_server"
)
$ErrorActionPreference="Stop"
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$out=Join-Path $here "SOURCE_PATCHES\FETCHED"
New-Item -ItemType Directory -Force -Path $out|Out-Null
if(!(Test-Path -LiteralPath (Join-Path $RepoPath ".git"))){throw "Not a git repo: $RepoPath"}
Push-Location $RepoPath
try{
  git fetch origin "+refs/pull/12/head:refs/remotes/origin/ws-source-pr12" "+refs/pull/3/head:refs/remotes/origin/ws-source-pr3"
  if($LASTEXITCODE -ne 0){throw "git fetch patch sources failed"}

  $meta=[ordered]@{
    generated_at=(Get-Date).ToString("o")
    pr12=(git rev-parse refs/remotes/origin/ws-source-pr12).Trim()
    pr3=(git rev-parse refs/remotes/origin/ws-source-pr3).Trim()
  }
  $meta|ConvertTo-Json|Set-Content -Encoding UTF8 (Join-Path $out "SOURCE_HEADS.json")

  # PR12: save focused diff for current dynamic world/runtime integration.
  git diff master...refs/remotes/origin/ws-source-pr12 -- `
    lib/voxel-provisioning.js `
    apps/voxel-world/client.js `
    lib/api-handlers/world.js `
    lib/api-handlers/merge.js `
    apps/improve-world-home/public/app.js `
    vercel.json | Set-Content -Encoding UTF8 (Join-Path $out "PR12_DYNAMIC_WORLD_FOCUSED.diff")

  # PR3: extract only safe standalone acceleration files. Do NOT merge the old client wholesale.
  $paths=@(
    "apps/voxel-world/chunk-worker.js",
    "apps/voxel-world/texture-pack-runtime.js",
    "test/chunk-worker.test.js",
    "test/texture-pack.test.js",
    "test/voxel-hardening.test.js"
  )
  $pr3root=Join-Path $out "PR3_SELECTIVE_ACCELERATION"
  foreach($p in $paths){
    $dst=Join-Path $pr3root $p
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst)|Out-Null
    git show ("refs/remotes/origin/ws-source-pr3:"+$p) | Set-Content -Encoding UTF8 $dst
  }
  git diff master...refs/remotes/origin/ws-source-pr3 -- apps/voxel-world/client.js | Set-Content -Encoding UTF8 (Join-Path $out "PR3_CLIENT_REFERENCE_ONLY_DO_NOT_APPLY_WHOLE.diff")
  Write-Host "[PATCH_SOURCES] fetched PR12 + selective PR3 acceleration sources."
} finally {Pop-Location}
