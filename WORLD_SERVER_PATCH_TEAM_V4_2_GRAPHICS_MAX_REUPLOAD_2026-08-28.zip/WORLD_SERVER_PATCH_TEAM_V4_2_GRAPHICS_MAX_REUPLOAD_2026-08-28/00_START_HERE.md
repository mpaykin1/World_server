# V4.2 GRAPHICS MAX — REUPLOAD

This is a fresh downloadable reupload after the previous interpreter session expired.

Start with:
`DESKTOP_AI_V4_2_INSTALL_VERIFY_FIX.md`

The package contains the V4 graphics/control layer plus restored V4.2 measurable guards and the exact latest-only patch manifest.
It does NOT pretend expired child ZIP bytes are present: `COLLECT_AND_BUILD.bat` finds the exact latest archives on the desktop/download folders and refuses old substitutes.
