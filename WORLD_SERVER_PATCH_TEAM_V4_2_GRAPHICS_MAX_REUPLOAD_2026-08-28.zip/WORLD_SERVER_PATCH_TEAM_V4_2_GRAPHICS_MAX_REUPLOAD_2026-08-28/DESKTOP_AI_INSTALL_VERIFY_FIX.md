# Superseded instruction

Use `DESKTOP_AI_TEAM_INSTALL_VERIFY_FIX.md` for Patch Team V2.
