﻿param(
  [string]$RepoPath="C:\Users\user\Desktop\World_server",
  [switch]$Apply
)
$ErrorActionPreference="Stop"
if(!$Apply){Write-Host "DRY RUN. Re-run with -Apply after Desktop AI has reviewed current changes.";exit 0}
if(!(Test-Path -LiteralPath (Join-Path $RepoPath ".git"))){throw "Not a git repo"}
Push-Location $RepoPath
try{
  $vendor=Join-Path $RepoPath "apps\voxel-world\vendor"
  New-Item -ItemType Directory -Force -Path $vendor|Out-Null
  foreach($v in @("0.175.0","0.185.0")){
    Write-Host "[THREE] testing $v"
    npm install --save-exact ("three@"+$v)
    if($LASTEXITCODE -ne 0){throw "npm install three@$v failed"}
    Copy-Item -Force (Join-Path $RepoPath "node_modules\three\build\three.module.min.js") (Join-Path $vendor "three.module.min.js")
    Copy-Item -Force (Join-Path $RepoPath "node_modules\three\LICENSE") (Join-Path $vendor "THREE_LICENSE")
    npm run check
    if($LASTEXITCODE -ne 0){throw "repo check failed at Three $v"}
    if(Test-Path -LiteralPath (Join-Path $RepoPath "test\control-contract.test.js")){
      node --test test/control-contract.test.js
      if($LASTEXITCODE -ne 0){throw "control contract failed at Three $v"}
    }
  }
  Write-Host "[THREE] r185 vendor prepared. Desktop AI must now switch client import to local-primary/CDN-fallback and run browser visual/mobile gates."
} finally {Pop-Location}
